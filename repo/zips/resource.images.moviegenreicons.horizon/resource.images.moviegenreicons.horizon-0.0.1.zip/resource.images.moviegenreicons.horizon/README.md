Icons from iconmonstr.com and flaticon.com
Check websites for license terms

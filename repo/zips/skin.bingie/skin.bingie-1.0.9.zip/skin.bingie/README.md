```markdown
# 🎬 Kodi Skin: Bingie Light (Netflix Layout)

![Bingie Preview](https://i.imgur.com/NCpIpR5.png)

A **lightweight version** of the popular **Titan Bingie Mod** skin for Kodi — redesigned for **smooth performance** on weaker devices (especially Android TV boxes).
Although lighter, it still packs many of Bingie’s signature features and a modern **Netflix-style interface**.

---

## 📚 Table of Contents
- [✨ Features](#-features)
- [⚙️ Installation](#️-installation)
- [⭐ Ratings Setup](#-ratings-setup)
- [🔗 Additional Features](#-additional-features)
- [🌐 Translations](#-translations)
- [🐞 Bug Reports](#-bug-reports)
- [🖼️ Screenshots](#️-screenshots)

---

## ✨ Features

- Added **Arial** as a secondary skin font
- Introduced a **custom search function**
- Detailed movie & TV show info via **Wikipedia**
- Displays TMDb Helper content when local library is empty
- Recreated **original Bingie startup animation**
- Improved **addon compatibility**
- Increased widget count to **10**
- Added **Music Hub** and **Bingie Music OSD**
- Enhanced **PVR functionality**
- Actor & crew info available from the OSD menu during playback
- Polished **icons, buttons, and animations**

> ⚠️ Note: This skin is primarily optimized for **movies and TV shows**.
> Other Kodi features are available but may behave differently.

---

## ⚙️ Installation

1. **Enable Unknown Sources**
```

Settings > System > Add-ons > Unknown Sources

```

2. **Allow updates from any repositories**
```

Settings > System > Add-ons > Update official add-ons from: Any repositories

```

![Enable Sources](https://i.imgur.com/kUoiPhF.jpeg)

3. **Install the repository**
Choose one of the following methods:

- **ZIP Install:**
  [repository.Gflix-1.0.0.zip](https://G00380316.github.io/Gflix/repository.G00380316-1.0.0.zip)
- **File Manager Source:**
  [https://G00380316.github.io/Gflix/](https://G00380316.github.io/Gflix/)

4. **Install the skin**
```

Bingie Repo > Look and Feel > Skins > Bingie

```

---

## ⭐ Ratings Setup

For ratings (IMDb, RottenTomatoes, Metacritic, etc.), you’ll need personal API keys for **OMDb** and **MDbList**.

### Get Free API Keys
- [OMDb API Key](https://www.omdbapi.com/apikey.aspx)
- [MDbList API Key](https://mdblist.com/preferences)

### Add Keys to TMDb Helper
```

Skin Settings > Supported Addons > TMDb Helper > API Keys > OMDb API Key
Skin Settings > Supported Addons > TMDb Helper > API Keys > MDbList API Key

```

![Ratings Example](https://i.imgur.com/Fg3t5fs.png)

---

## 🔗 Additional Features

Some features require linking your **Trakt** account with **TMDb Helper**:

```

Skin Settings > Supported Addons > TMDb Helper > Trakt > Authenticate Trakt Account

```

![Trakt Example](https://i.imgur.com/CYkZ6Jo.png)

---

## 🌐 Translations

Currently available in **English** only.
To add your language, submit a **Pull Request (PR)** on the [official repository](https://github.com/G00380316/Gflix).

---

## 🐞 Bug Reports

This skin has undergone major internal changes — bugs may exist.
Please report any issues by opening a **new issue** on GitHub:
👉 [Report a Bug](https://github.com/G00380316/Gflix/issues)

---

## 🖼️ Screenshots

### 🎥 Spotlight
![Spotlight](https://i.imgur.com/F0MIiMV.jpeg)

### 🧩 Widgets
![Widgets](https://i.imgur.com/3HRp0gg.jpeg)

### 🗂️ Dialog Video Info
![Dialog Video Info](https://i.imgur.com/s4TzK5v.png)

### 🎮 Video OSD
![Video OSD](https://i.imgur.com/FBAzBeW.jpeg)

---

## ❤️ Credits

- Based on **Titan Bingie Mod** by the Kodi community
- Developed and maintained by [matke-84](https://github.com/matke-84)
- Uses **TMDb Helper** for extended metadata

---

> Enjoy the **Bingie Light** skin — the perfect blend of Netflix-style visuals and Kodi power.


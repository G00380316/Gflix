# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import sys
import xbmc
import xbmcaddon
import urllib.parse
import xbmcgui
import xbmcplugin
import time
import requests
import re

# Import external modules: API for content, navigator for menu logic, control for Kodi utilities.
import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator
import resources.utils.control as control
from resources.utils.watch_history import clear_history
from resources.utils.background_writer import enqueue_write
from resources.lib.proxy_instance import ensure_proxy_running

ADDON = xbmcaddon.Addon()


def open_addon_settings():
    """
    Opens the addon's settings dialog. This is the endpoint for the 'Settings'
    context menu option attached to list items.
    """
    # Use the custom control function to open settings
    control.openSettings()


def is_vod(url):
    u = url.lower()
    return u.endswith(".mkv") or u.endswith(".mp4") or "/movie/" in u or "/series/" in u


def play_stream(url, name):
    is_vod = (
        url.lower().endswith((".mkv", ".mp4"))
        or "vod" in url.lower()
        or "series" in url.lower()
    )

    xbmc.log(f"[IPTV-PLAY] name={name} vod={is_vod} url={url}", xbmc.LOGINFO)

    if is_vod:
        li = xbmcgui.ListItem(path=url)
        li.setLabel(name)
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        li.setProperty("seekable", "true")

        xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, li)
        return

    port = ensure_proxy_running()

    # Kodi plays the proxy, proxy plays the upstream
    proxied = "http://127.0.0.1:{}/stream?u={}".format(
        port, urllib.parse.quote(url, safe="")
    )

    xbmc.log(f"[IPTV-PLAY] proxied_url={proxied}", xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=proxied)
    li.setLabel(name)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)

    # Live TS should not be seekable
    li.setProperty("isLive", "true")
    li.setProperty("seekable", "false")

    # --------------------------------------------------------------------------------
    #  WATCH HISTORY WRITE
    # --------------------------------------------------------------------------------

    # Extract stream ID from URL
    stream_id = url.split("/")[-1].split(".")[0]

    entry = {
        "item_id": stream_id,
        "title": name,
        "stream_type": (
            "live" if "/live/" in url else "vod" if "/movie/" in url else "series"
        ),
        "thumb": "",
        "fanart": "",
        "resume_time": 0,
        "play_url": url,
    }

    enqueue_write(entry)

    # --------------------------------------------------------------------------------
    #  START PLAYBACK
    # --------------------------------------------------------------------------------

    xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, li)

def handle_routing(url_params):
    """
    Central router / dispatcher for the addon.

    Responsibilities:
    - Read URL parameters produced by Kodi
    - Determine the requested 'mode'
    - Dispatch control to the appropriate handler
    - Provide consistent logging for debugging & support
    """

    # ------------------------------------------------------------
    # Extract common parameters
    # Kodi provides params as lists (from parse_qs)
    # ------------------------------------------------------------
    mode = url_params.get("mode", [None])[0]
    search_query = url_params.get("search_query", [None])[0]

    xbmc.log(
        f"[giptv][ROUTER] mode={mode} search_query={search_query} params={list(url_params.keys())}",
        xbmc.LOGINFO,
    )

    # ------------------------------------------------------------
    # Initial addon launch (no mode)
    # ------------------------------------------------------------
    # This occurs when the addon is opened from the Kodi UI root.
    if mode is None:
        xbmc.log("[giptv][ROUTER] Initial launch → root menu", xbmc.LOGINFO)
        navigator.root_menu()
        return

    # ------------------------------------------------------------
    # Content listing: Live TV / Movies
    # ------------------------------------------------------------
    if mode == "list_streams":
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_streams type={stream_type} category={category_id} name={name}",
            xbmc.LOGINFO,
        )

        navigator.list_streams(
            stream_type,
            category_id,
            name,
            search_query,
        )

    # ------------------------------------------------------------
    # TV Series navigation
    # ------------------------------------------------------------
    elif mode == "list_series_streams":
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_streams category={category_id} name={name}",
            xbmc.LOGINFO,
        )

        navigator.list_series_streams(
            stream_type,
            category_id,
            name,
            search_query,
        )

    elif mode == "list_series_seasons":
        series_id = url_params.get("series_id", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_seasons series_id={series_id}",
            xbmc.LOGINFO,
        )

        navigator.list_series_seasons(series_id, series_name)

    elif mode == "list_series_episodes":
        series_id = url_params.get("series_id", [""])[0]
        season_num = url_params.get("season_num", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_episodes series_id={series_id} season={season_num}",
            xbmc.LOGINFO,
        )

        navigator.list_series_episodes(series_id, season_num, series_name)

    # ------------------------------------------------------------
    # Playback
    # ------------------------------------------------------------
    elif mode == "play_stream":
        url = url_params.get("url", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] play_stream name={name} url={url}",
            xbmc.LOGINFO,
        )

        play_stream(url, name)

    # ------------------------------------------------------------
    # Settings & utility actions
    # ------------------------------------------------------------
    elif mode == "open_settings":
        xbmc.log("[giptv][ROUTER] open_settings", xbmc.LOGINFO)
        open_addon_settings()

    elif mode == "recently_watched":
        xbmc.log("[giptv][ROUTER] recently_watched", xbmc.LOGINFO)
        navigator.recently_watched()

    elif mode == "clear_history":
        xbmc.log("[giptv][ROUTER] clear_history", xbmc.LOGINFO)
        clear_history()
        control.notification(
            ADDON.getAddonInfo("name"),
            "Recently Watched Reset Done",
            icon="INFO",
        )
        xbmc.executebuiltin("Container.Refresh")

    # ------------------------------------------------------------
    # Search routing
    # ------------------------------------------------------------
    elif mode == "search":
        mode_to_call = url_params.get("mode_to_call", [None])[0]
        stream_type = url_params.get("stream_type", [None])[0]
        category_id = url_params.get("category_id", [None])[0]

        xbmc.log(
            f"[giptv][ROUTER] search mode_to_call={mode_to_call} type={stream_type}",
            xbmc.LOGINFO,
        )

        navigator.search_menu(mode_to_call, stream_type, category_id)

    elif mode == "global_search":
        xbmc.log("[giptv][ROUTER] global_search", xbmc.LOGINFO)
        navigator.global_search()

    elif mode == "global_vod_search":
        xbmc.log("[giptv][ROUTER] global_vod_search", xbmc.LOGINFO)
        navigator.global_vod_search()

    elif mode == "global_series_search":
        xbmc.log("[giptv][ROUTER] global_series_search", xbmc.LOGINFO)
        navigator.global_series_search()

    elif mode == "global_live_search":
        xbmc.log("[giptv][ROUTER] global_live_search", xbmc.LOGINFO)
        navigator.global_live_search()

    # ------------------------------------------------------------
    # Category navigation (after root menu)
    # ------------------------------------------------------------
    elif mode == "list_categories":
        stream_type = url_params.get("stream_type", [xtream_api.LIVE_TYPE])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_categories type={stream_type}",
            xbmc.LOGINFO,
        )

        navigator.list_categories(stream_type, search_query)

    # ------------------------------------------------------------
    # Failsafe
    # ------------------------------------------------------------
    else:
        xbmc.log(
            f"[giptv][ROUTER] Unknown mode received: {mode}",
            xbmc.LOGERROR,
        )
        control.okDialog(
            ADDON.getAddonInfo("name"),
            f"Unknown mode: {mode}",
        )

from resources.lib.proxy_server import IPTVStreamProxy

_proxy = None
_port = None

def ensure_proxy_running():
    global _proxy, _port
    if _proxy is None:
        _proxy = IPTVStreamProxy(host="127.0.0.1", port=0)  # 0 = pick free port
        _port = _proxy.start()
    return _port

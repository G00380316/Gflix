# -*- coding: utf-8 -*-
import re
import time
import xbmcvfs
import xbmc
from datetime import datetime

# Very lightweight parsing: extracts channel ids + programmes.
# Designed for "now playing" lookups.

_CHANNEL_RE = re.compile(r'<channel\s+id="([^"]+)"', re.IGNORECASE)
_PROG_RE = re.compile(
    r'<programme\s+start="([^"]+)"\s+stop="([^"]+)"\s+channel="([^"]+)".*?>',
    re.IGNORECASE | re.DOTALL,
)
_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
_DESC_RE = re.compile(r"<desc[^>]*>(.*?)</desc>", re.IGNORECASE | re.DOTALL)


def _xml_unescape(s):
    if not s:
        return ""
    return (
        s.replace("&amp;", "&")
         .replace("&lt;", "<")
         .replace("&gt;", ">")
         .replace("&quot;", '"')
         .replace("&apos;", "'")
    )


def _parse_xmltv_dt(dt_str):
    """
    XMLTV format example: 20251218013000 +0000
    Returns unix timestamp (int) or 0
    """
    if not dt_str:
        return 0
    try:
        # strip timezone part if present
        parts = dt_str.strip().split()
        base = parts[0]
        # YYYYMMDDHHMMSS
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
        # treat as UTC if timezone is present, otherwise assume UTC
        return int(dt.replace(tzinfo=None).timestamp())
    except Exception:
        return 0


def load_xmltv_now_index(xmltv_path, max_programmes_per_channel=2000):
    """
    Returns dict:
      channel_id -> list of (start_ts, end_ts, title, desc) sorted by start_ts
    Intended to be cached in memory by navigator.
    """
    if not xmltv_path or not xbmcvfs.exists(xmltv_path):
        return {}

    f = xbmcvfs.File(xmltv_path, "r")
    try:
        data = f.read()
    finally:
        f.close()

    if not data or "<tv" not in data.lower():
        return {}

    programmes = {}
    # iterate programme open tags
    for m in _PROG_RE.finditer(data):
        start_s, stop_s, chan = m.group(1), m.group(2), m.group(3)
        start_ts = _parse_xmltv_dt(start_s)
        stop_ts = _parse_xmltv_dt(stop_s)
        if not chan or not start_ts or not stop_ts:
            continue

        # find title/desc after this tag (simple bounded slice)
        # we scan a small window to avoid huge cost
        window = data[m.end(): m.end() + 4000]
        t = _TITLE_RE.search(window)
        d = _DESC_RE.search(window)

        title = _xml_unescape(t.group(1).strip()) if t else ""
        desc = _xml_unescape(d.group(1).strip()) if d else ""

        programmes.setdefault(chan, []).append((start_ts, stop_ts, title, desc))
        if len(programmes[chan]) > max_programmes_per_channel:
            programmes[chan] = programmes[chan][-max_programmes_per_channel:]

    for chan in programmes:
        programmes[chan].sort(key=lambda x: x[0])

    return programmes


def get_now(programmes_by_channel, channel_id, now_ts=None):
    """
    Returns (title, desc, start_ts, end_ts) or None
    """
    if not programmes_by_channel or not channel_id:
        return None
    now_ts = now_ts or int(time.time())

    progs = programmes_by_channel.get(channel_id)
    if not progs:
        return None

    # linear scan is ok for small lists; later we can binary search.
    for start_ts, end_ts, title, desc in progs:
        if start_ts <= now_ts < end_ts:
            return (title, desc, start_ts, end_ts)

    return None

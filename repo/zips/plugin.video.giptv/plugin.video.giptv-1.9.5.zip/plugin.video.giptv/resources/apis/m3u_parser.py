# -*- coding: utf-8 -*-
"""
Robust M3U / M3U8 parser for IPTV playlists.

Parses:
  - #EXTINF lines (attributes + display name)
  - stream URL lines
  - groups (group-title)
  - logos (tvg-logo)
  - tvg-id / tvg-name
  - fallback parsing when fields are missing

Returns a list of dict entries:
  {
    "name": str,
    "group": str,
    "logo": str,
    "tvg_id": str,
    "tvg_name": str,
    "stream_url": str,
    "stream_id": str,      # best-effort extraction
    "raw_extinf": str,
  }
"""

import re
from urllib.parse import urlparse


_ATTR_RE = re.compile(r'([\w\-]+)\s*=\s*"([^"]*)"')  # key="value"
_EXTINF_RE = re.compile(r"^#EXTINF\s*:\s*([^,]*),(.*)$", re.IGNORECASE)


def _safe_strip(s):
    return (s or "").strip()


def _extract_stream_id(stream_url):
    """
    Best-effort extraction of stream id from common IPTV URL formats.
    Examples:
      http://host/.../1973434
      http://host/.../1973434.ts
      http://host/.../1973434.m3u8
    """
    if not stream_url:
        return ""

    try:
        path = urlparse(stream_url).path or ""
        # remove trailing slash if any
        path = path.rstrip("/")
        if not path:
            return ""

        last = path.split("/")[-1]
        # remove extension (.ts, .mkv, .mp4, .m3u8)
        if "." in last:
            last = last.split(".")[0]
        # ensure it's not empty / not a generic word
        return last or ""
    except Exception:
        return ""


def parse_m3u_text(text):
    """
    Parse M3U string content -> list of entries.
    """
    if not text:
        return []

    lines = [ln.strip() for ln in text.splitlines()]
    entries = []

    current = None  # holds extinf metadata until we hit the URL line

    for ln in lines:
        if not ln:
            continue

        # skip header and comments
        if ln.startswith("#EXTM3U"):
            continue
        if ln.startswith("#") and not ln.upper().startswith("#EXTINF"):
            continue

        # EXTINF line
        if ln.upper().startswith("#EXTINF"):
            current = {
                "name": "",
                "group": "",
                "logo": "",
                "tvg_id": "",
                "tvg_name": "",
                "stream_url": "",
                "stream_id": "",
                "raw_extinf": ln,
            }

            m = _EXTINF_RE.match(ln)
            if m:
                attrs_part = m.group(1) or ""
                display_name = m.group(2) or ""
            else:
                # weird format, still try to parse attributes
                attrs_part = ln
                display_name = ""

            # attributes key="value"
            attrs = dict(_ATTR_RE.findall(attrs_part))

            current["tvg_id"] = _safe_strip(attrs.get("tvg-id"))
            current["tvg_name"] = _safe_strip(attrs.get("tvg-name"))
            current["logo"] = _safe_strip(attrs.get("tvg-logo") or attrs.get("logo"))
            current["group"] = _safe_strip(attrs.get("group-title") or attrs.get("group"))

            # name priority: tvg-name -> display name
            name = current["tvg_name"] or display_name
            current["name"] = _safe_strip(name)

            continue

        # URL line (for the last EXTINF)
        if current and not ln.startswith("#"):
            current["stream_url"] = ln
            current["stream_id"] = _extract_stream_id(ln)

            # final fallback: if name still empty, use stream_id
            if not current["name"]:
                current["name"] = f"Channel {current['stream_id']}" if current["stream_id"] else "Unknown"

            entries.append(current)
            current = None
            continue

        # If we got a URL line without EXTINF (rare playlists)
        if not ln.startswith("#"):
            url = ln
            entries.append(
                {
                    "name": _extract_stream_id(url) or "Unknown",
                    "group": "",
                    "logo": "",
                    "tvg_id": "",
                    "tvg_name": "",
                    "stream_url": url,
                    "stream_id": _extract_stream_id(url),
                    "raw_extinf": "",
                }
            )

    return entries


def parse_m3u_file(m3u_path, xbmcvfs_module=None):
    """
    Parse M3U from disk. Supports Kodi xbmcvfs paths if xbmcvfs_module is passed.

    Usage inside Kodi:
      import xbmcvfs
      entries = parse_m3u_file(path, xbmcvfs_module=xbmcvfs)
    """
    if not m3u_path:
        return []

    try:
        if xbmcvfs_module:
            if not xbmcvfs_module.exists(m3u_path):
                return []
            f = xbmcvfs_module.File(m3u_path, "r")
            try:
                text = f.read()
            finally:
                f.close()
        else:
            with open(m3u_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()

        return parse_m3u_text(text)

    except Exception:
        return []


def group_entries(entries):
    """
    Returns:
      groups: dict[group_name] -> list[entry]
      all_groups_sorted: list[str]
    """
    groups = {}
    for e in entries or []:
        g = e.get("group") or "Other"
        groups.setdefault(g, []).append(e)

    # stable sort groups by name
    all_groups_sorted = sorted(groups.keys(), key=lambda s: (s.lower(), s))
    return groups, all_groups_sorted

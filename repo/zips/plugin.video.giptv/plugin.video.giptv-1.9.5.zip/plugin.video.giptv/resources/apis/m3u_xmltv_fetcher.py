# resources/apis/m3u_xmltv_fetcher.py

import json
import time
import gzip
import io
import urllib.request
import urllib.error

import xbmc
import xbmcvfs

import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator

ADDON_ID = "plugin.video.giptv"


# ============================================================
#  PATH HELPERS
# ============================================================
def profile_path(sub=""):
    base = f"special://profile/addon_data/{ADDON_ID}/"
    return xbmcvfs.translatePath(base + sub)


def ensure_cache_dir():
    path = profile_path("cache")
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def state_path():
    return profile_path("cache/state.json")


# ============================================================
#  STATE HANDLING
# ============================================================
def load_state():
    if not xbmcvfs.exists(state_path()):
        return {}
    try:
        f = xbmcvfs.File(state_path())
        data = json.loads(f.read())
        f.close()
        return data
    except Exception:
        return {}


def save_state(state):
    f = xbmcvfs.File(state_path(), "w")
    f.write(json.dumps(state, indent=2))
    f.close()


# ============================================================
#  HTTP FETCH (gzip aware)
# ============================================================
def fetch_url(url, timeout=30):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Kodi-GIPTV/1.0",
            "Accept-Encoding": "gzip",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        return raw.decode("utf-8", errors="ignore")


# ============================================================
#  URL CANDIDATES
# ============================================================
def candidate_xmltv_urls():
    base = xtream_api.SERVER.rstrip("/")
    u = xtream_api.USERNAME
    p = xtream_api.PASSWORD

    return [
        f"{base}/xmltv.php?username={u}&password={p}",
        f"{base}/xmltv.php?u={u}&p={p}",
        f"{base}/xmltv.xml",
        f"{base}/xmltv.xml.gz",
        f"{base}/epg.xml",
        f"{base}/epg.xml.gz",
    ]


def build_m3u_url():
    return (
        f"{xtream_api.SERVER}/get.php"
        f"?username={xtream_api.USERNAME}"
        f"&password={xtream_api.PASSWORD}"
        f"&type=m3u_plus"
        f"&output=ts"
    )


# ============================================================
#  FETCHERS
# ============================================================
def fetch_m3u(force=False, max_age_hours=24):
    if not navigator.setup_api_config():
        return None

    cache_dir = ensure_cache_dir()
    m3u_path = f"{cache_dir}/playlist.m3u"
    state = load_state()

    last = state.get("m3u_last_fetch", 0)
    age = (time.time() - last) / 3600

    if not force and xbmcvfs.exists(m3u_path) and age < max_age_hours:
        xbmc.log("[giptv] Using cached M3U", xbmc.LOGINFO)
        return m3u_path

    try:
        url = build_m3u_url()
        xbmc.log(f"[giptv] Fetching M3U: {url}", xbmc.LOGINFO)
        data = fetch_url(url)

        if "#EXTM3U" not in data:
            raise ValueError("Invalid M3U")

        f = xbmcvfs.File(m3u_path, "w")
        f.write(data)
        f.close()

        state.update(
            {
                "m3u_last_fetch": time.time(),
                "m3u_ok": True,
            }
        )
        save_state(state)
        return m3u_path

    except Exception as e:
        xbmc.log(f"[giptv] M3U fetch failed: {e}", xbmc.LOGERROR)
        state["m3u_ok"] = False
        save_state(state)
        return None


def fetch_xmltv(force=False, max_age_hours=24):
    if not navigator.setup_api_config():
        return None

    cache_dir = ensure_cache_dir()
    xmltv_path = f"{cache_dir}/xmltv.xml"
    state = load_state()

    last = state.get("xmltv_last_fetch", 0)
    age = (time.time() - last) / 3600

    if not force and xbmcvfs.exists(xmltv_path) and age < max_age_hours:
        xbmc.log("[giptv] Using cached XMLTV", xbmc.LOGINFO)
        return xmltv_path

    for url in candidate_xmltv_urls():
        try:
            xbmc.log(f"[giptv] Trying XMLTV: {url}", xbmc.LOGINFO)
            data = fetch_url(url)

            if "<tv" not in data.lower():
                continue  # not valid XMLTV

            f = xbmcvfs.File(xmltv_path, "w")
            f.write(data)
            f.close()

            state.update(
                {
                    "xmltv_last_fetch": time.time(),
                    "xmltv_ok": True,
                    "epg_mode": "xmltv",
                }
            )
            save_state(state)

            xbmc.log("[giptv] XMLTV fetched successfully", xbmc.LOGINFO)
            return xmltv_path

        except Exception:
            continue

    xbmc.log("[giptv] XMLTV unavailable — will use fallback EPG", xbmc.LOGWARNING)
    state.update({"xmltv_ok": False, "epg_mode": "dynamic"})
    save_state(state)
    return None


def fetch_provider_data(force=False):
    fetch_m3u(force=force)
    fetch_xmltv(force=force)

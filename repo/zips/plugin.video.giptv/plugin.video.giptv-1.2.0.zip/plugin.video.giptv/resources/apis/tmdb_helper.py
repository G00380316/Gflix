import xbmc
import json
import unicodedata
from typing import Optional, Text, Dict, Any, List
# Ensure this utility correctly handles requests/session setup
from resources.utils.kodi_utils import make_session

# --- Constants from the provided scraper code ---
TMDB_API_KEY = 'f090bb54758cabf231fb605d3e3e0468'
TMDB_PARAMS = {'api_key': TMDB_API_KEY}
BASE_URL = 'https://api.themoviedb.org/3/{}'
MOVIE_URL = BASE_URL.format('movie/{}')
TV_URL = BASE_URL.format('tv/{}')
session = make_session('https://api.themoviedb.org/3')

class TMDbHelper:
    """A helper class to fetch rich movie and TV series metadata from TMDb."""

    def __init__(self):
        self.image_base_url = None
        self._get_config()

    def _get_config(self):
        """Fetches TMDb configuration, primarily for image base URL."""
        xbmc.log('TMDbHelper: attempting to set configuration details', xbmc.LOGDEBUG)
        
        try:
            # Fallback to a reliable base URL for images
            self.image_base_url = 'https://image.tmdb.org/t/p/original'
            xbmc.log(f'TMDbHelper: Image Base URL set to {self.image_base_url}', xbmc.LOGDEBUG)
            
        except Exception as e:
            xbmc.log(f'TMDbHelper: Failed to get TMDb configuration: {e}', xbmc.LOGERROR)
            self.image_base_url = 'https://image.tmdb.org/t/p/original'
    
    # --- MOVIE SECTION ---
    def get_movie_details(self, tmdb_id: Text, language: Optional[Text] = 'en') -> Optional[Dict[Text, Any]]:
        """Fetches detailed movie metadata and art."""
        if not tmdb_id:
            return None

        response_data = self.movie_details(tmdb_id, TMDB_API_KEY)

        if not response_data:
            return None

        plot = response_data.get('overview') or response_data.get('tagline') or 'No plot available.'
        fanart_path = response_data.get('backdrop_path')
        poster_path = response_data.get('poster_path')
        
        art = {}
        if poster_path and self.image_base_url:
            art['poster'] = f"{self.image_base_url}{poster_path}"
            art['thumb'] = art['poster']
        
        if fanart_path and self.image_base_url:
            art['fanart'] = f"{self.image_base_url}{fanart_path}" 

        return {
            'title': response_data.get('title'),
            'plot': plot,
            'year': response_data.get('release_date', '')[:4],
            'rating': response_data.get('vote_average'),
            'art': art
        }

    # --- SERIES SECTION ---
    def get_series_details(self, tmdb_id: Text, language: Optional[Text] = 'en') -> Optional[Dict[Text, Any]]:
        """Fetches detailed TV show metadata."""
        if not tmdb_id:
            return None
        
        xbmc.log(f'TMDbHelper: Fetching series details for TMDb ID: {tmdb_id}', xbmc.LOGDEBUG)

        response_data = self.tvshow_details(tmdb_id, TMDB_API_KEY)
        
        if not response_data:
            return None

        # Extracting key details
        plot = response_data.get('overview') or response_data.get('tagline') or 'No plot available.'
        fanart_path = response_data.get('backdrop_path')
        poster_path = response_data.get('poster_path')
        
        # Extract cast (simple example, TMDb returns full list)
        cast = []
        if 'credits' in response_data and 'cast' in response_data['credits']:
            cast = [c.get('name') for c in response_data['credits']['cast'][:5] if c.get('name')] # Top 5 cast members

        # Building Art dictionary
        art = {}
        if poster_path and self.image_base_url:
            art['poster'] = f"{self.image_base_url}{poster_path}"
            art['thumb'] = art['poster']
        
        if fanart_path and self.image_base_url:
            art['fanart'] = f"{self.image_base_url}{fanart_path}"
            
        # Extract Genres
        genres = [g.get('name') for g in response_data.get('genres', []) if g.get('name')]
        
        return {
            'title': response_data.get('name'),
            'plot': plot,
            'year': response_data.get('first_air_date', '')[:4],
            'rating': response_data.get('vote_average'),
            'genre': ', '.join(genres),
            'cast': cast,
            'art': art
        }

    def get_season_details(self, tmdb_id: Text, season_num: Text, language: Optional[Text] = 'en') -> Optional[Dict[Text, Any]]:
        """Fetches season-specific metadata. Not strictly needed for the Kodi list structure, but complete."""
        return None

    # --- MOCK DATA SECTION ---
    def _mock_get_movie_details(self, tmdb_id):
        # ... (Movie mock data as provided in the prompt) ...
        if tmdb_id == '693134':
            return {
                "title": "Dune: Part Two",
                "overview": "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe, he endeavors to prevent a terrible future only he can foresee.",
                "backdrop_path": "/xomrE1S8B3d6A3FfN3Q2H2Zc8O3.jpg",
                "poster_path": "/1pdfLvkbYJ9A0IfYnVaW4GEthzB.jpg",
                "vote_average": 8.4, "release_date": "2024-02-28", "tagline": "Long live the fighters."
            }
        elif tmdb_id == '5955':
            return {
                "title": "The Pledge",
                "overview": "A detective, on the day of his retirement, promises to catch the killer of a young girl...",
                "backdrop_path": "/q9r1K2r2rBqN8uV2X3f5o6zT5Zz.jpg",
                "poster_path": "/w15ZLVjhstpvJESWtb6P4iILjmh.jpg",
                "vote_average": 6.8, "release_date": "2001-01-19", "tagline": "He will find the killer..."
            }
        return None
        
    def _mock_get_series_details(self, tmdb_id):
        """Simulates fetching data for a TV series, replace with network code."""
        # Mock data for The Mandalorian (TMDB 82856)
        if tmdb_id == '82856':
            return {
                "name": "The Mandalorian",
                "overview": "The travels of a lone bounty hunter in the outer reaches of the galaxy, far from the authority of the New Republic.",
                "first_air_date": "2019-11-12",
                "backdrop_path": "/eCgNn5Vz3S9f0oU6M0eGkYw3WnC.jpg",
                "poster_path": "/e1mjopzAS2KNtkp1yKTK9T3lzpt.jpg",
                "vote_average": 8.1,
                "genres": [{"id": 10765, "name": "Sci-Fi & Fantasy"}, {"id": 10759, "name": "Action & Adventure"}],
                "credits": {"cast": [{"name": "Pedro Pascal"}, {"name": "Grogu"}]}
            }
        return None
    
    # --- Network Fetch Functions ---
    def get_tmdb(self, url):
        try:
            response = session.get(url, timeout=20.0)
        except:
            response = None
        return response
    
    def movie_details(self, tmdb_id, api_key):
        try:
            url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,release_dates,alternative_titles,translations,' \
            'images,keywords&include_image_language=en' % (tmdb_id, api_key)
            return self.get_tmdb(url).json()
        except:
            return None
    
    def tvshow_details(self, tmdb_id, api_key):
        try:
            url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,content_ratings,alternative_titles,translations,' \
            'images,keywords&include_image_language=en' % (tmdb_id, api_key)
            return self.get_tmdb(url).json()
        except:
            return None
        
    def season_episodes_details(self, tmdb_id, season_no,api_key):
        try:
            url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en&append_to_response=credits' % (tmdb_id, season_no, api_key)
            return self.get_tmdb(url).json()
        except: return None
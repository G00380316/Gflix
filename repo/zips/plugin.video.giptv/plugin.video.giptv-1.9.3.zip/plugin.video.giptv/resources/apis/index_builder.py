import json
import os
import xbmcvfs
import xbmc
import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator


def _index_dir():
    base = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.giptv/index"
    )
    if not xbmcvfs.exists(base):
        xbmcvfs.mkdirs(base)
    return base


def _write(name, data):
    """
    Writes USERNAME-specific index files:
    USERNAME_vod_index.json
    USERNAME_series_index.json
    USERNAME_live_index.json
    """
    path = os.path.join(_index_dir(), f"{xtream_api.USERNAME}_{name}.json")
    with xbmcvfs.File(path, "w") as f:
        f.write(json.dumps(data, ensure_ascii=False))


def _normalize(title):
    if not title:
        return ""
    return title.lower().strip()


def build_index(monitor):
    """
    Builds optimized search indexes for VOD, SERIES, and LIVE.
    Includes required 'lower' fields for fuzzy search.
    Abort-safe with Kodi monitor.
    """
    xbmc.log("[giptv] Building search index (background)...", xbmc.LOGINFO)

    # -------------------------------------------------------
    # VOD INDEX
    # -------------------------------------------------------
    vod_out = []
    vod_categories = xtream_api.categories("vod") or []

    for cat in vod_categories:
        if monitor.abortRequested():
            return

        cat_id = cat.get("category_id")
        cat_name = cat.get("category_name", "")

        streams = xtream_api.streams_by_category("vod", cat_id) or []
        for m in streams:
            if monitor.abortRequested():
                return

            sid = str(m.get("stream_id"))
            if not sid:
                continue

            title = m.get("name", "")

            vod_out.append(
                {
                    "id": sid,
                    "title": title,
                    "lower": _normalize(title),  # REQUIRED
                    "category_id": cat_id,  # For global search filtering
                    "category_name": cat_name,
                    "thumb": m.get("stream_icon") or m.get("cover", ""),
                    "tmdb": m.get("tmdb") or m.get("tmdb_id"),
                    "ext": m.get("container_extension", "mp4"),
                }
            )

    _write("vod_index", vod_out)

    # -------------------------------------------------------
    # SERIES INDEX
    # -------------------------------------------------------
    series_out = []
    series_categories = xtream_api.categories("series") or []

    for cat in series_categories:
        if monitor.abortRequested():
            return

        cat_id = cat.get("category_id")
        cat_name = cat.get("category_name", "")

        streams = xtream_api.streams_by_category("series", cat_id) or []
        for s in streams:
            if monitor.abortRequested():
                return

            sid = str(s.get("series_id"))
            if not sid:
                continue

            title = s.get("name", "")

            series_out.append(
                {
                    "id": sid,
                    "title": title,
                    "lower": _normalize(title),  # REQUIRED
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": s.get("cover", ""),
                    "tmdb": s.get("tmdb") or s.get("tmdb_id"),
                }
            )

    _write("series_index", series_out)

    # -------------------------------------------------------
    # LIVE INDEX
    # -------------------------------------------------------
    live_out = []
    live_categories = xtream_api.categories("live") or []

    for cat in live_categories:
        if monitor.abortRequested():
            return

        cat_id = cat.get("category_id")
        cat_name = cat.get("category_name", "")

        streams = xtream_api.streams_by_category("live", cat_id) or []
        for c in streams:
            if monitor.abortRequested():
                return

            sid = str(c.get("stream_id"))
            if not sid:
                continue

            title = c.get("name", "")

            live_out.append(
                {
                    "id": sid,
                    "title": title,
                    "lower": _normalize(title),  # REQUIRED
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": c.get("stream_icon") or c.get("tv_logo", ""),
                    "ext": c.get("container_extension", "ts"),
                }
            )

    _write("live_index", live_out)

    xbmc.log("[giptv] Search index build finished ✓", xbmc.LOGINFO)

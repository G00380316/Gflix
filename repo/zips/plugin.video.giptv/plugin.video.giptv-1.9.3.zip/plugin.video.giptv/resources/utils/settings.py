import xbmcgui


def get_api_credentials(ADDON, selectedAccount: str):
    """
    Retrieves the API credentials from the add-on settings.
    """
    suffix = selectedAccount[-1]  # '1', '2' or anything else
    if suffix == "1":
        username_key, password_key = "username1", "password1"
    elif suffix == "2":
        username_key, password_key = "username2", "password2"
    else:
        username_key, password_key = "username", "password"

    server = ADDON.getSetting(selectedAccount).strip()
    username = ADDON.getSetting(username_key).strip()
    password = ADDON.getSetting(password_key).strip()

    if not (server and username and password):
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo("name"),
            "Please configure your IPTV credentials in the add‑on settings.",
        )
        return None, None, None

    return server, username, password


def get_epg_on_off(ADDON):
    on_off = str(ADDON.getSetting("epg"))

    return True if on_off == "0" else False


def get_tmdb_on_off(ADDON):
    on_off = str(ADDON.getSetting("tmdb"))

    return True if on_off == "0" else False


def get_cache_on_off(ADDON):
    on_off = str(ADDON.getSetting("cache"))

    return True if on_off == "0" else False


def get_auto_epg_on_off(ADDON):
    on_off = str(ADDON.getSetting("auto_build_epg"))

    return True if on_off == "0" else False


def get_auto_index_on_off(ADDON):
    on_off = str(ADDON.getSetting("auto_build_index"))

    return True if on_off == "0" else False

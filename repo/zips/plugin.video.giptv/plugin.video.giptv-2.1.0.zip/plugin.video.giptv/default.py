# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import sys
import os
# Add resources path to ensure modules can be imported
sys.path.insert(0, os.getcwd())

import xbmc

# Import the main router logic
import resources.lib.router as router
import resources.utils.giptv as giptv
from resources.lib.manager.index_manager import build_index

# --- Main Execution ---

if __name__ == "__main__":
    # sys.argv[2] contains the URL parameters (the query string)
    # [1:] is used to remove the leading '?'
    params = urlparse.parse_qs(sys.argv[2][1:])

    # Extract action safely as a string
    action = params.get("action", [None])[0]

    if action == "close_settings":
        giptv.close_setting()
    elif action == "donate":
        giptv.donate()
    elif action == "clear_cache":
        giptv.clear_cache()
    elif action == "build_search_index":
        giptv.notification("Building Search Index may take ~2 minutes Initially")
        build_index(notify=True)
    elif action == "build_search_index_refresh":
        xbmc.executebuiltin("Container.refresh")
        build_index(notify=True)
    else:
        router.handle_routing(params)

# -*- coding: utf-8 -*-
import time
import threading
import urllib.parse
import urllib.request

from resources.utils import giptv
import xbmc

try:
    # Py3
    from http.server import BaseHTTPRequestHandler
    from socketserver import ThreadingMixIn
    from http.server import HTTPServer
except ImportError:
    # Kodi nowadays is Py3, but keep fallback
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn


class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class StreamProxyHandler(BaseHTTPRequestHandler):
    """
    GET /stream?u=<url-encoded-upstream-url>
    Streams bytes from upstream to Kodi and reconnects on stall/failure.
    """

    # Tunables (good defaults for IPTV TS)
    CHUNK_SIZE = 64 * 1024  # 64KB
    UPSTREAM_TIMEOUT = 10  # seconds for urlopen timeout
    STALL_SECONDS = 6  # if no bytes for this long -> reconnect
    RECONNECT_DELAY = 0.5  # seconds between reconnect attempts

    HEADER_PROFILES = [
        {
            "User-Agent": "VLC/3.0.20 LibVLC/3.0.20",
            "Accept": "*/*",
            "Connection": "keep-alive",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "identity",
            "Range": "bytes=0-",
        },
        {
            "User-Agent": "mpv/0.35.0",
            "Accept": "*/*",
            "Connection": "keep-alive",
        },
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
        },
        {
            "User-Agent": "Kodi/21.0 (Windows NT 10.0; Win64; x64)",
            "Accept": "*/*",
            "Connection": "keep-alive",
        },
    ]

    server_version = "KodiIPTVProxy/1.0"
    protocol_version = "HTTP/1.1"

    def open_with_rotating_headers(self, url, timeout):
        last_error = None

        for headers in self.HEADER_PROFILES:
            try:
                giptv.log(
                    f"Trying headers: {headers.get('User-Agent')}",
                    xbmc.LOGINFO,
                )
                req = urllib.request.Request(url, headers=headers)
                return urllib.request.urlopen(req, timeout=timeout)

            except Exception as e:
                last_error = e
                giptv.log(
                    f"Header failed: {repr(e)}",
                    xbmc.LOGINFO,
                )

        if last_error:
            raise last_error

        raise RuntimeError("Failed to open stream with all header profiles")

    def log_message(self, fmt, *args):
        # Route HTTP server logs to Kodi log
        giptv.log((fmt % args), xbmc.LOGINFO)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path != "/stream":
            self.send_response(404)
            self.end_headers()
            return

        qs = urllib.parse.parse_qs(parsed.query)
        upstream_list = qs.get("u") or []
        if not upstream_list:
            self.send_response(400)
            self.end_headers()
            return

        upstream_url = urllib.parse.unquote(upstream_list[0])
        giptv.log(f"Start stream -> {upstream_url}", xbmc.LOGINFO)

        # 1. PREPARE THE PROXY RESPONSE
        self.send_response(200)
        self.send_header("Content-Type", "video/MP2T")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "yes")
        self.end_headers()

        monitor = xbmc.Monitor()
        reconnect_attempts = 0

        # INCREASED SETTINGS FOR DISTANT REGIONS
        LATENCY_BUFFER = 512 * 1024  # 512KB Buffer
        STALL_THRESHOLD = 15.0  # Wait up to 15s for high-latency hops

        while not monitor.abortRequested() and reconnect_attempts < 10:
            try:
                headers = self.HEADER_PROFILES[
                    reconnect_attempts % len(self.HEADER_PROFILES)
                ]
                req = urllib.request.Request(upstream_url, headers=headers)

                with urllib.request.urlopen(req, timeout=12) as resp:
                    reconnect_attempts = 0
                    last_active = time.monotonic()

                    while not monitor.abortRequested():
                        # Read larger chunks to smooth out jitter
                        chunk = resp.read(LATENCY_BUFFER)

                        if chunk:
                            try:
                                self.wfile.write(chunk)
                                # We DON'T flush every time; let the OS buffer a bit
                                last_active = time.monotonic()
                            except Exception:
                                giptv.log("Kodi stopped playing.", xbmc.LOGINFO)
                                return
                        else:
                            # If no data, check if we've actually stalled
                            if time.monotonic() - last_active > STALL_THRESHOLD:
                                giptv.log(
                                    "Regional latency timeout. Reconnecting...",
                                    xbmc.LOGWARNING,
                                )
                                break
                            time.sleep(0.1)

            except Exception as e:
                reconnect_attempts += 1
                giptv.log(
                    f"Connection lost ({reconnect_attempts}/10): {e}", xbmc.LOGINFO
                )
                time.sleep(1)  # Wait before retry to let the regional route clear

        giptv.log("Stream session ended.", xbmc.LOGINFO)


class IPTVStreamProxy(object):
    def __init__(self, host="127.0.0.1", port=0):
        self.host = host
        self.port = port
        self._httpd = None
        self._thread = None

    def start(self):
        if self._httpd:
            return self.port

        self._httpd = _ThreadingHTTPServer((self.host, self.port), StreamProxyHandler)
        self.port = self._httpd.server_address[1]

        self._thread = threading.Thread(
            target=self._httpd.serve_forever, name="IPTVStreamProxy"
        )
        self._thread.daemon = True
        self._thread.start()

        giptv.log(f"Listening on http://{self.host}:{self.port}", xbmc.LOGINFO)
        return self.port

    def stop(self):
        if not self._httpd:
            return
        try:
            self._httpd.shutdown()
            self._httpd.server_close()
        except Exception:
            pass
        self._httpd = None
        giptv.log("Stopped", xbmc.LOGINFO)

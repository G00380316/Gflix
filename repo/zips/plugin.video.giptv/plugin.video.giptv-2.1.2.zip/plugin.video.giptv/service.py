# -*- coding: utf-8 -*-
from resources.lib.manager import index_manager
import xbmc
import xbmcaddon
import xbmcvfs
import threading

from resources.utils import giptv
from resources.utils.config import ensure_api_ready
from resources.lib.manager.index_manager import ensure_index
from resources.lib.manager.epg_manager import get_xmltv_index
from resources.lib.cache.history_cache import shutdown_writer
from resources.lib.manager import index_manager as index
from resources.lib.manager import epg_manager as epg

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

SETTINGS_CHANGED = False

# ============================================================
#  SMALL HELPERS
# ============================================================


def get_profile_path(subpath=""):
    """
    Helper: return a path under this addon's profile directory.
    Uses special://profile so it respects portable / profiles.
    """
    base = "special://profile/addon_data/{}/".format(ADDON_ID)
    if subpath:
        base = base + subpath.lstrip("/")

    return xbmcvfs.translatePath(base)


def warm_epg():
    giptv.log("Warming EPG", xbmc.LOGINFO)
    get_xmltv_index()
    giptv.log("EPG warm complete", xbmc.LOGINFO)


# ============================================================
#  SETTINGS MONITOR
# ============================================================
class SettingsMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()

    def onSettingsChanged(self):
        """
        Triggered when addon settings change.
        We:
          - refresh containers
          - request index rebuild
        """
        giptv.log("Settings Changed", xbmc.LOGINFO)

        giptv.return_action()
        giptv.container_refresh()


# ============================================================
#  MAIN SERVICE LOOP
# ============================================================
if __name__ == "__main__":
    monitor = SettingsMonitor()

    # Wait a few seconds for Kodi to initialize
    xbmc.sleep(1)

    # Initial setup
    if ensure_api_ready():
        epg._release_epg_lock()
        index._release_index_lock()
        threading.Thread(target=warm_epg, daemon=True).start()
        ensure_index(monitor)

    # Persistent loop to keep monitor active
    giptv.log("Entering main monitor loop", xbmc.LOGINFO)
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
            # Optional: periodically do maintenance tasks here
    finally:
        shutdown_writer()
        giptv.log("Service shutting down", xbmc.LOGINFO)

import sys

# Python 2/3 compatibility for handling URL encoding/decoding.
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import base64
import datetime
import difflib
import json
import os
import unicodedata

import xbmc  # Necessary for functions like xbmc.sleep() and xbmc.Keyboard().
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import resources.apis.tmdb_helper as TMDbHelper

# Import external modules
import resources.apis.xtream_api as xtream_api
import resources.utils.control as control
import resources.utils.kodi_utils as utils
from resources.utils import settings
from resources.utils.fetchCache import cache_handler
from resources.utils.watch_history import load_history

# Global constants for the Kodi API.
ADDON = xbmcaddon.Addon()
# PLUGIN_HANDLE: The unique identifier Kodi gives to this running addon instance.
# We use this to tell Kodi where to put our list items.
# SAFE plugin handle assignment (service.py will not crash)
if len(sys.argv) > 1 and sys.argv[1].isdigit():
    PLUGIN_HANDLE = int(sys.argv[1])
else:
    PLUGIN_HANDLE = -1  # special value meaning "not in plugin mode"
ADDON_ID = ADDON.getAddonInfo("id")

# --- CONTEXT MENU SETUP ---
# Defines the Kodi built-in command URL that will call our router with the 'open_settings' mode.
SETTINGS_ACTION_URL = "RunPlugin(plugin://{}/?mode=open_settings)".format(ADDON_ID)
INDEX_ACTION_URL = "RunPlugin(plugin://{}/?action=build_search_index)".format(ADDON_ID)
GLOBAL_SEARCH_ACTION_URL = "RunPlugin(plugin://{}/?action=global_search)".format(
    ADDON_ID
)
# SETTINGS_CONTEXT_MENU: The list item we attach to every folder/stream for the
# right-click/long-press menu.
SETTINGS_CONTEXT_MENU = [
    ("Global Search", GLOBAL_SEARCH_ACTION_URL),
    ("Open Settings", SETTINGS_ACTION_URL),
    ("Refresh", "Container.Refresh"),
    ("Rebuild list", f"Container.Update({sys.argv[0]})"),
    ("Build Search Index", INDEX_ACTION_URL),
    ("Reset Recently Watched", f"RunPlugin(plugin://{ADDON_ID}/?mode=clear_history)"),
]

# Initialize helpers
tmdb_helper = TMDbHelper.TMDbHelper()


def root_menu():
    LIVE_TYPE = "live"
    VOD_TYPE = "vod"
    SERIES_TYPE = "series"

    global_search_url = (
        sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_search"})
    )

    global_search_item = xbmcgui.ListItem(
        label="[COLOR yellow]\ue836[/COLOR] [B]Global Search (All Content)[/B]"
    )
    global_search_item.setArt(
        {"icon": "DefaultAddonSearch.png", "thumb": "DefaultAddonSearch.png"}
    )

    # Added "Rebuild Index" in context menu for power users
    global_search_item.addContextMenuItems(
        [
            (
                "Rebuild Search Index",
                f"RunPlugin(plugin://{ADDON_ID}/?action=build_search_index)",
            )
        ]
    )

    xbmcplugin.addDirectoryItem(
        PLUGIN_HANDLE, global_search_url, global_search_item, isFolder=True
    )

    # Recently watched
    recent_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    recent_item = xbmcgui.ListItem("[B][COLOR orange]Recently Watched[/COLOR][/B]")
    recent_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, recent_url, recent_item, isFolder=True)

    menu_items = [
        ("[B]Live TV[/B]", "live", "DefaultVideo.png"),
        ("[B]Movies[/B]", "vod", "DefaultMovies.png"),
        ("[B]TV Series[/B]", "series", "DefaultTVShows.png"),
    ]

    for label, stream_type, thumb in menu_items:
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {"mode": "list_categories", "stream_type": stream_type}
            )
        )

        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": "icon.png", "thumb": thumb})
        item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, item, isFolder=True)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Xtream Content Streams")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- Search Handlers ---
def search_menu(mode_to_call, stream_type=None, category_id=None):
    """
    Prompts the user for a search term using Kodi's keyboard, then updates the
    current directory to show filtered results by recalling the original mode
    with the new 'search_query' parameter.
    """
    # Open Kodi's on-screen keyboard for user input.
    keyboard = xbmc.Keyboard("", "Enter Search Term")
    keyboard.doModal()

    # Check if the user confirmed the search (hit 'OK').
    if keyboard.isConfirmed():
        search_query = keyboard.getText()
        if search_query:
            # 1. Build the base parameters to rerun the previous listing function.
            params = {
                "mode": mode_to_call,  # The function we want to run (e.g., list_categories).
                "search_query": search_query,  # The term the user just entered.
            }
            # 2. Re-add any necessary context parameters (like stream type or category ID).
            if stream_type:
                params["stream_type"] = stream_type
            if category_id:
                params["category_id"] = category_id

            # Construct the final URL with all parameters.
            url = sys.argv[0] + "?" + urlparse.urlencode(params)

            # Update the directory title to clearly show the user they are viewing search results.
            xbmcplugin.setPluginCategory(
                PLUGIN_HANDLE, f"Search Results for: {search_query}"
            )
            xbmcplugin.setContent(
                PLUGIN_HANDLE, "videos"
            )  # Set content type for proper Kodi view.

            # Tell Kodi's interface to refresh immediately with the new URL, replacing the current list.
            xbmc.executebuiltin(f"Container.Update({url})")

    # Always close the directory listing, especially if the user cancels the keyboard.
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- SEARCH INDEX HELPERS ---


def _get_index_dir():
    """
    Returns the path to the local JSON index storage directory:
    special://profile/addon_data/<addon_id>/index
    """
    base = xbmcvfs.translatePath(
        "special://profile/addon_data/{}/index".format(ADDON_ID)
    )
    if not xbmcvfs.exists(base):
        xbmcvfs.mkdirs(base)
    return base


def _read_index(name):
    """
    Reads an index file (vod_index.json, series_index.json, live_index.json)
    and returns a list of entries.
    """
    if not setup_api_config():
        return

    index_dir = _get_index_dir()
    path = os.path.join(index_dir, f"{xtream_api.USERNAME}_{name}_index.json")
    if not xbmcvfs.exists(path):
        return []

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.read()
    finally:
        f.close()

    if not raw:
        return []

    try:
        return json.loads(raw)
    except Exception:
        return []


def _write_index(name, data):
    """
    Writes the given list of entries into name_index.json.
    """
    if not setup_api_config():
        return

    index_dir = _get_index_dir()
    path = os.path.join(index_dir, f"{xtream_api.USERNAME}_{name}_index.json")

    payload = json.dumps(data, ensure_ascii=False)
    f = xbmcvfs.File(path, "w")
    try:
        f.write(payload)
    finally:
        f.close()


def _normalize_title(s):
    if not s:
        return ""
    # strip accents and lowercase
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower().strip()


def _fuzzy_score(query, candidate):
    """
    Returns a similarity score (0.0 - 1.0) between query and candidate.
    1.0 = exact match; uses containment + difflib as a fallback.
    """
    if not query or not candidate:
        return 0.0

    q = _normalize_title(query)
    c = _normalize_title(candidate)

    if not q or not c:
        return 0.0

    if q == c:
        return 1.0

    if q in c:
        return 0.95

    # difflib SequenceMatcher is fast enough for our sizes
    return difflib.SequenceMatcher(None, q, c).ratio()


def build_search_index():
    """
    Scans ALL categories and streams (live, vod, series) and builds local JSON indexes
    for instant global search with fuzzy matching.
    """
    if not setup_api_config():
        return

    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        # --- VOD INDEX ---
        vod_index = {}
        vod_cats = xtream_api.categories(xtream_api.VOD_TYPE) or []
        for cat in vod_cats:
            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            movies = xtream_api.streams_by_category(xtream_api.VOD_TYPE, cat_id) or []
            for m in movies:
                sid = m.get("stream_id")
                if not sid:
                    continue
                sid_str = str(sid)
                title = m.get("name") or m.get("title") or "Unknown"
                entry = {
                    "id": sid_str,
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": m.get("stream_icon") or m.get("cover") or "",
                    "tmdb": m.get("tmdb") or m.get("tmdb_id"),
                    "ext": m.get("container_extension", "mp4"),
                }
                vod_index[sid_str] = entry  # de-dup by ID

        _write_index("vod", list(vod_index.values()))

        # --- SERIES INDEX ---
        series_index = {}
        series_cats = xtream_api.categories(xtream_api.SERIES_TYPE) or []
        for cat in series_cats:
            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            shows = xtream_api.streams_by_category(xtream_api.SERIES_TYPE, cat_id) or []
            for s in shows:
                sid = s.get("series_id")
                if not sid:
                    continue
                sid_str = str(sid)
                title = s.get("name") or "Unknown"
                entry = {
                    "id": sid_str,
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": s.get("cover") or "",
                    "tmdb": s.get("tmdb") or s.get("tmdb_id"),
                }
                series_index[sid_str] = entry

        _write_index("series", list(series_index.values()))

        # --- LIVE INDEX ---
        live_index = {}
        live_cats = xtream_api.categories(xtream_api.LIVE_TYPE) or []
        for cat in live_cats:
            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            chans = xtream_api.streams_by_category(xtream_api.LIVE_TYPE, cat_id) or []
            for c in chans:
                sid = c.get("stream_id")
                if not sid:
                    continue
                sid_str = str(sid)
                title = (
                    c.get("name") or c.get("stream_display_name") or "Unknown Channel"
                )
                entry = {
                    "id": sid_str,
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": c.get("stream_icon") or c.get("tv_logo") or "",
                    "ext": c.get("container_extension", "ts"),
                }
                live_index[sid_str] = entry

        _write_index("live", list(live_index.values()))

        control.notification(
            ADDON.getAddonInfo("name"),
            "Search index rebuilt (Live / Movies / Series)",
            icon="INFO",
        )
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def _timestamp_to_datetime(timestamp_str):
    """
    Converts a Unix timestamp string (like '1678886400') into a Python datetime object.
    Returns None if conversion fails. This assumes the server timestamps are in UTC.
    """
    if not timestamp_str:
        return None
    try:
        # Convert string to integer, then to datetime
        return datetime.datetime.fromtimestamp(int(timestamp_str))
    except (ValueError, TypeError):
        print(f"Warning: Failed to convert timestamp: {timestamp_str}")
        return None


def _decode_base64_epg_field(encoded_string):
    """
    Decodes a Base64 string to a UTF-8 string. Returns original if decoding fails.
    """
    if not encoded_string:
        return ""
    try:
        # The API output usually doesn't need padding, but this is safer.
        return base64.b64decode(encoded_string).decode("utf-8")
    except Exception:
        # Fallback to the original string if it wasn't valid Base64
        return encoded_string


def extract_tmdb_id(data):
    return (
        data.get("tmdb")
        or data.get("tmdb_id")
        or data.get("tmdbId")
        or data.get("tmdbID")
        or data.get("imdb_id")
        or (data.get("info", {}) or {}).get("tmdb")
        or (data.get("info", {}) or {}).get("tmdb_id")
        or None
    )


# --- Configuration Setup ---
def setup_api_config():
    """
    Retrieves the necessary Xtream credentials from Kodi settings and validates them.
    It prepares the `xtream_api` module for subsequent calls.
    """
    try:
        selectedAccount = ADDON.getSetting("account")

        # Determine which server group to pull credentials from based on user setting.
        if selectedAccount == "0":
            selectedAccount = "server"
        elif selectedAccount == "1":
            selectedAccount = "server1"
        elif selectedAccount == "2":
            selectedAccount = "server2"
        else:
            control.notification(
                ADDON.getAddonInfo("name"),
                f"Selected Account {selectedAccount} is not valid.",
                icon="ERROR",
            )
            control.openSettings()
            return False

        server, username, password = settings.get_api_credentials(
            ADDON, selectedAccount
        )

        # Ensure the server URL starts with a protocol for a valid connection.
        if not str(server).startswith("http://") and not str(server).startswith(
            "https://"
        ):
            # 1. Show a clear notification about the configuration error.
            control.notification(
                "Configuration Error",
                "Please configure your IPTV credentials in the add-on settings.",
                time=5000,
                icon="ERROR",
            )

            # 2. Pause the script for 5 seconds to ensure the user reads the warning.
            monitor = xbmc.Monitor()
            monitor.waitForAbort(5)

            # 3. Open the settings window immediately after the pause.
            control.openSettings()
            return False

        # Load the validated credentials into the global API module.
        xtream_api.SERVER = server.rstrip("/")
        xtream_api.USERNAME = username
        xtream_api.PASSWORD = password
        return True
    except Exception as e:
        control.notification(
            ADDON.getAddonInfo("name"), f"Configuration Setup Error: {e}", icon="ERROR"
        )
        control.openSettings()
        return False


def list_categories(stream_type, search_query=None):
    """
    Displays the top-level content categories (e.g., Entertainment, Documentaries)
    for the given stream type (Live, VOD, Series, etc.).
    Includes logic for adding the [ Search Categories... ] option and filtering the results.
    """
    if not setup_api_config():
        return

    if stream_type == "vod":
        # Search ALL Movies
        search_all_url = (
            sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_vod_search"})
        )
        search_all_item = xbmcgui.ListItem(
            label="[COLOR yellow]Search ALL Movies[/COLOR]"
        )
        search_all_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, search_all_url, search_all_item, isFolder=True
        )
    elif stream_type == "series":
        search_all_url = (
            sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_series_search"})
        )
        search_all_item = xbmcgui.ListItem(
            label="[COLOR yellow]Search ALL TV Series[/COLOR]"
        )
        search_all_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, search_all_url, search_all_item, isFolder=True
        )
    elif stream_type == "live":
        search_all_url = (
            sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_live_search"})
        )
        search_all_item = xbmcgui.ListItem(
            label="[COLOR yellow]Search ALL Live TV[/COLOR]"
        )
        search_all_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, search_all_url, search_all_item, isFolder=True
        )

    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    # Add a search entry point unless we are already viewing filtered results.
    if search_query is None:
        # URL sets mode to 'search', which the router intercepts to prompt for input.
        search_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "search",
                    "mode_to_call": "list_categories",  # We want the router to call this function again after the search term is ready.
                    "stream_type": stream_type,
                }
            )
        )

        # Create a dedicated search list item using the Kodi icon font (\ue836 for magnifying glass).
        search_item = xbmcgui.ListItem(
            label="[COLOR yellow]\ue836[/COLOR] [B]Search Categories...[/B]"
        )
        search_item.setArt(
            {"icon": "DefaultAddonSearch.png", "thumb": "DefaultAddonSearch.png"}
        )
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=search_url, listitem=search_item, isFolder=True
        )

    # 1. Authenticate with the server.
    auth_data = xtream_api.authenticate()
    if not auth_data or auth_data.get("user_info", {}).get("auth") != 1:
        error_msg = auth_data.get("user_info", {}).get(
            "message", "Authentication Failed or Account Expired."
        )
        control.notification(ADDON.getAddonInfo("name"), error_msg, icon="ERROR")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # 2. Fetch all categories for the stream type (Live, VOD, etc.).
    category_list = cache_handler.get(
        "categories", f"{xtream_api.USERNAME}_{stream_type}"
    )
    if not category_list:
        if settings.get_cache_on_off(ADDON):
            utils.notification("Category not Cached", icon="INFO")
        category_list = xtream_api.categories(stream_type)

    if not category_list:
        control.notification(
            ADDON.getAddonInfo("name"),
            "Failed to retrieve categories or list is empty.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # 3. Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        # Use a list comprehension to filter results by name containing the query string.
        category_list = [
            c
            for c in category_list
            if search_query in c.get("category_name", "").lower()
        ]
        if not category_list:
            control.notification(
                ADDON.getAddonInfo("name"),
                f"No categories found matching '{search_query}'.",
                icon="INFO",
            )

    for category in category_list:
        name = category.get("category_name", "Unknown Category")
        category_id = category.get("category_id")

        # Determine the next function to call: list_streams for Live/Movies, or list_series_streams for Series.
        if stream_type == "series":
            next_mode = "list_series_streams"
        else:
            next_mode = "list_streams"

        # Build the URL to call the determined mode when the user clicks this folder.
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": next_mode,
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                }
            )
        )

        # Create the Kodi list item.
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})

        # Attach the "Open Settings" context menu.
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True,  # This item opens another folder.
        )

    # Signal to Kodi that we are finished listing items for this directory.
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the individual playable streams (channels, movies) within a selected category,
    now using TMDbHelper to fetch rich metadata for VOD streams.
    """
    if not setup_api_config():
        return

    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    # --- Search entry point logic ---
    if search_query is None:
        search_label_suffix = "Streams"
        if stream_type == "vod":
            search_label_suffix = "Movies"

        search_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "search",
                    "mode_to_call": "list_streams",
                    "stream_type": stream_type,
                    "category_id": category_id,
                }
            )
        )

        search_item = xbmcgui.ListItem(
            label=f"[COLOR yellow]\ue836[/COLOR] [B]Search {search_label_suffix}...[/B]"
        )
        search_item.setArt(
            {"icon": "DefaultAddonSearch.png", "thumb": "DefaultAddonSearch.png"}
        )
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=search_url, listitem=search_item, isFolder=True
        )

    # Fetch all streams for the given category ID from the API.
    stream_list = cache_handler.get(
        stream_type, f"{xtream_api.USERNAME}_{stream_type}_{category_id}"
    )
    if not stream_list:
        if settings.get_cache_on_off(ADDON):
            utils.notification("Stream not Cached", icon="INFO")
        stream_list = xtream_api.streams_by_category(stream_type, category_id)

    if not stream_list:
        control.notification(
            ADDON.getAddonInfo("name"), f"No streams found in {name}.", icon="INFO"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        stream_list = [
            s
            for s in stream_list
            if search_query in s.get("name", "").lower()
            or search_query in s.get("title", "").lower()
        ]
        if not stream_list:
            control.notification(
                ADDON.getAddonInfo("name"),
                f"No streams found matching '{search_query}'.",
                icon="INFO",
            )
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # --------------------------------------------------------------------------------------
    # --- MAIN LOOP ---
    # --------------------------------------------------------------------------------------
    for stream in stream_list:
        # --- INITIALIZE COMMON VARIABLES ---
        stream_id = str(
            stream.get("stream_id")
            or stream.get("movie_id")
            or stream.get("vod_id")
            or ""
        )
        if not stream_id:
            continue

        stream_name = (
            stream.get("name")
            or stream.get("title")
            or stream.get("stream_display_name")
            or "Unknown Stream"
        )
        stream_icon = (
            stream.get("stream_icon")
            or stream.get("cover")
            or stream.get("tv_logo")
            or ""
        )

        list_item = xbmcgui.ListItem(label=stream_name)

        tmdb_id = None
        mediatype = "video"
        info_label = {}
        art_dict = {}

        # --- VOD/MOVIE STREAM HANDLING ---
        if stream_type == "vod":
            stream_type_for_api = "vod"
            ext = stream.get("container_extension", "mp4")
            info_data = stream.get("info", {})
            mediatype = "movie"

            # Extract TMDb ID
            tmdb_id_raw = stream.get("tmdb") or stream.get("tmdb_id")
            if tmdb_id_raw:
                tmdb_id = str(tmdb_id_raw)

            # --- TMDb Lookup and Overwrite ---
            tmdb_details = None
            if tmdb_id and tmdb_flag:
                # CRITICAL: Call the TMDb helper to get rich metadata
                tmdb_details = tmdb_helper.get_movie_details(tmdb_id)
                xbmcplugin.setContent(PLUGIN_HANDLE, "movies")  # Set content type

                if tmdb_details:
                    # Use rich TMDb data

                    # 1. Update info label with rich TMDb data
                    info_label = {
                        "title": tmdb_details.get("title") or stream_name,
                        "plot": tmdb_details.get("plot"),
                        "year": (
                            int(tmdb_details.get("year"))
                            if tmdb_details.get("year")
                            and tmdb_details.get("year").isdigit()
                            else 0
                        ),
                        "rating": (
                            float(tmdb_details.get("rating"))
                            if tmdb_details.get("rating")
                            else 0.0
                        ),
                        "mediatype": mediatype,
                        "director": info_data.get(
                            "director"
                        ),  # Fallback to source for non-TMDb fetched fields
                        "genre": info_data.get("genre"),
                        "duration": info_data.get("duration_secs"),
                    }

                    # 2. Set Art with TMDb/Source data
                    art_dict = tmdb_details.get("art", {})
                    # Ensure poster/thumb is set, prioritizing TMDb, then source icon
                    if not art_dict.get("poster") and stream_icon:
                        art_dict["poster"] = stream_icon
                        art_dict["thumb"] = stream_icon
                    if not art_dict.get("thumb") and art_dict.get("poster"):
                        art_dict["thumb"] = art_dict.get("poster")

                    # 3. Set TMDb properties for Kodi scraper
                    list_item.setProperty("tmdbnumber", tmdb_id)
                    list_item.setProperty(
                        "imdbnumber", tmdb_id
                    )  # Set IMDb property for compatibility

            else:
                # If TMDb lookup failed, fall back to basic source data
                # (but at least include poster/plot from source if possible)

                movie_plot = (
                    stream.get("plot")
                    or info_data.get("plot")
                    or "TMDb lookup failed. No description available."
                )

                info_label = {
                    "title": stream_name,
                    "plot": movie_plot,
                    "mediatype": mediatype,
                }
                if stream_icon:
                    art_dict["thumb"] = stream_icon
                    art_dict["icon"] = stream_icon
                    art_dict["poster"] = stream_icon

        # --- LIVE TV STREAM HANDLING (EPG Logic) ---
        else:
            stream_type_for_api = "live"
            ext = stream.get("container_extension", "ts")
            mediatype = "video"

            # 1. Initialize Fallback Info (This will be used if EPG fails)
            info_label = {
                "title": stream_name,
                "plot": stream_name,
                "mediatype": mediatype,
                "tvshowtitle": stream_name,
            }

            # 2. Set Art (Channel Logo)
            art_dict = {}
            if stream_icon:
                art_dict["thumb"] = stream_icon
                art_dict["icon"] = stream_icon
            else:
                art_dict["icon"] = "DefaultVideo.png"
                art_dict["thumb"] = "DefaultVideo.png"

            # Set the initial list item label to the stream name (fallback)
            list_item.setLabel(stream_name)

            # --- EPG INTEGRATION: FETCH DATA ---
            # Assume stream_id is available from the stream dictionary
            stream_id = stream.get("stream_id")

            decoded_epg_data = []
            # *** CRITICAL CHANGE: Use the decoded API function ***
            epg_data = cache_handler.get(
                "epg_data", f"{xtream_api.USERNAME}_{stream_id}"
            )
            if epg_data:
                for listing in epg_data["epg_listings"]:
                    # Create a mutable copy
                    decoded_listing = listing.copy()

                    # Decode the fields in the copy
                    if "title" in decoded_listing:
                        decoded_listing["title"] = _decode_base64_epg_field(
                            decoded_listing["title"]
                        )

                    if "description" in decoded_listing:
                        decoded_listing["description"] = _decode_base64_epg_field(
                            decoded_listing["description"]
                        )

                    if "start_timestamp" in decoded_listing:
                        # Add a new key for the Python datetime object
                        decoded_listing["start_time_dt"] = _timestamp_to_datetime(
                            decoded_listing["start_timestamp"]
                        )

                    if "stop_timestamp" in decoded_listing:
                        # Add a new key for the Python datetime object
                        decoded_listing["stop_time_dt"] = _timestamp_to_datetime(
                            decoded_listing["stop_timestamp"]
                        )

                    decoded_epg_data.append(decoded_listing)

            else:
                if settings.get_cache_on_off(ADDON):
                    utils.notification("Epg Data not Cached", icon="INFO")
                epg_data = xtream_api.get_decoded_epg_short_by_stream(stream_id)

            epg_data = decoded_epg_data

            if epg_data and isinstance(epg_data, list) and len(epg_data) > 0:
                current_program = epg_data[0]  # SAFELY access the first item now

                # --- Extract EPG Data from DECODED LISTING ---

                # These are already decoded strings (thanks to get_decoded_epg_short_by_stream)
                epg_title = current_program.get("title")
                epg_plot = (
                    current_program.get("description")
                    or f"Currently showing: {epg_title or stream_name}"
                )

                # Get the Python datetime objects for clean formatting and math
                start_dt = current_program.get("start_time_dt")
                stop_dt = current_program.get("stop_time_dt")

                # Keep original timestamps for Kodi properties (they expect strings/ints)
                epg_start_ts = current_program.get("start_timestamp")
                epg_stop_ts = current_program.get("stop_timestamp")

                # --- Format Time for Display Label ---

                # Format the datetime objects (e.g., '21:00' or '09:00 PM')
                # %H:%M is 24-hour format; change to %I:%M %p for 12-hour AM/PM
                start_time_display = start_dt.strftime("%H:%M") if start_dt else "??:??"
                stop_time_display = stop_dt.strftime("%H:%M") if stop_dt else "??:??"

                title = (
                    f"{stream_name}[COLOR yellow] - {epg_title}[/COLOR]"
                    if epg_title
                    else stream_name
                )

                # Update label and info with EPG data
                list_item_label = f"[COLOR green][{start_time_display} - {stop_time_display}][/COLOR]   {title}"
                list_item.setLabel(list_item_label)

                # Calculate duration using the difference between datetime objects
                duration_seconds = 0
                if start_dt and stop_dt:
                    duration_seconds = int((stop_dt - start_dt).total_seconds())

                info_label.update(
                    {
                        "title": epg_title or stream_name,
                        "plot": epg_plot,
                        "endtime": epg_stop_ts,
                        # Use the calculated duration in seconds
                        "duration": duration_seconds,
                    }
                )

                # --- Set Kodi Properties for EPG Progress Bar (Only if we have timestamps) ---
                if epg_start_ts and epg_stop_ts:
                    list_item.setProperty("IsLive", "true")
                    list_item.setProperty(
                        "TotalTime", str(duration_seconds)
                    )  # Use calculated duration
                    list_item.setProperty("StartTime", str(epg_start_ts))
                    list_item.setProperty("channel_id", str(stream_id))

                # 4. Finalize the List Item (This step is critical to always execute)
                list_item.setArt(art_dict)
                list_item.setInfo("video", info_label)

        # --- BUILD PLAY URL AND FINALIZE LIST ITEM ---

        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type=stream_type_for_api,
            container_extension=ext,
        )

        if play_url:
            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {"mode": "play_stream", "url": play_url, "name": stream_name}
                )
            )

            list_item.setProperty("IsPlayable", "true")
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

            # Set collected art and info
            list_item.setArt(art_dict)
            list_item.setInfo("video", info_label)

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=False
            )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- SERIES NAVIGATION FUNCTIONS ---


def list_series_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the list of TV Series titles within a selected category.
    Now prioritizes setting the TMDb ID to allow Kodi's scrapers to fetch
    rich metadata (fanart, plot, cast, trailer, etc.) automatically.
    """
    if not setup_api_config():
        return

    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    # Fetch all series titles for the given category ID.
    series_list = cache_handler.get(
        stream_type, f"{xtream_api.USERNAME}_{stream_type}_{category_id}"
    )
    if not series_list:
        if settings.get_cache_on_off(ADDON):
            utils.notification("Series not Cached", icon="INFO")
        series_list = xtream_api.streams_by_category(stream_type, category_id)

    # Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        series_list = [
            s for s in series_list if search_query in s.get("name", "").lower()
        ]
        if not series_list:
            control.notification(
                ADDON.getAddonInfo("name"),
                f"No series found matching '{search_query}'.",
                icon="INFO",
            )
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    if not series_list:
        control.notification(
            ADDON.getAddonInfo("name"), f"No TV Series found in {name}.", icon="INFO"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    if search_query is None:
        search_label_suffix = "Series"  # Use "Series" since this function lists series

        search_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "search",
                    "mode_to_call": "list_series_streams",  # <-- CORRECTED to call THIS function
                    "stream_type": stream_type,
                    "category_id": category_id,
                }
            )
        )

        search_item = xbmcgui.ListItem(
            label=f"[COLOR yellow]\ue836[/COLOR] [B]Search {search_label_suffix}...[/B]"
        )
        search_item.setArt(
            {"icon": "DefaultAddonSearch.png", "thumb": "DefaultAddonSearch.png"}
        )
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=search_url, listitem=search_item, isFolder=True
        )

    for series in series_list:
        series_name = series.get("name", "Unknown Series")
        series_id = series.get("series_id")

        # --- CORE INFO EXTRACTION ---
        # We extract this core data to ensure *something* shows up,
        # but the TMDb ID will override it.
        plot = series.get("plot", "No description available.")
        rating_str = series.get("rating", "0")
        genre = series.get("genre", "")
        cast_str = series.get("cast", "")
        series_icon = series.get("cover", "")

        year_str = series.get("release_date", "").split("-")[0]
        year = int(year_str) if year_str.isdigit() else 0

        try:
            rating = float(rating_str)
        except (ValueError, TypeError):
            rating = 0.0

        cast_list = [c.strip() for c in cast_str.split(",")] if cast_str else []

        # Get the TMDb ID, which is the key to rich metadata fetching.
        tmdb_id = extract_tmdb_id(series)

        # Get the first backdrop path if available (used as a fallback or initial fanart)
        backdrop_list = series.get("backdrop_path", [])
        fanart_url = backdrop_list[0] if backdrop_list else ""

        # --- BUILD URL AND LIST ITEM ---
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_series_seasons",
                    "series_id": series_id,
                    "series_name": series_name,
                }
            )
        )

        list_item = xbmcgui.ListItem(label=series_name)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # 1. Set Art (Poster and Fanart)
        art_dict = {"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png"}

        if series_icon:
            art_dict["thumb"] = series_icon
            art_dict["icon"] = series_icon
            art_dict["poster"] = series_icon  # Use the cover image as the poster

        if fanart_url:
            art_dict["fanart"] = (
                fanart_url  # Use the direct URL for fanart (backup/initial)
            )

        list_item.setArt(art_dict)

        # 2. Set Info (Required for scraper integration)
        list_item.setInfo(
            "video",
            {
                "title": series_name,
                "plot": plot,
                "year": year,
                "rating": rating,
                "genre": genre,
                "cast": cast_list,
                "mediatype": "tvshow",  # CRUCIAL for TV show views
            },
        )

        # 3. CRITICAL: Set the TMDb ID property for Kodi Scrapers
        if tmdb_id and tmdb_flag:
            # Set the TMDb ID using the 'imdbnumber' property.
            # Kodi skins often look here for external IDs to trigger scraping.
            list_item.setProperty("imdbnumber", str(tmdb_id))
            # Also set the TMDb URL if needed (less common, but sometimes helps)
            list_item.setProperty("tmdbnumber", str(tmdb_id))

            # If the user has a preferred external scraper set, you can ensure
            # it is enabled for this directory:
            xbmcplugin.setContent(PLUGIN_HANDLE, "tvshows")

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_series_seasons(series_id, series_name):
    """
    Displays the season folders for a selected TV Series.
    Ensures series-level poster and fanart are applied to the season folders.
    """
    if not setup_api_config():
        return

    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    # Set the directory title
    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, series_name)
    xbmcplugin.setContent(PLUGIN_HANDLE, "seasons")

    # 1. Fetch detailed information for the series.
    series_info_response = cache_handler.get(
        "series_info", f"{xtream_api.USERNAME}_{series_id}"
    )
    if not series_info_response:
        if settings.get_cache_on_off(ADDON):
            utils.notification("Series info not Cached", icon="INFO")
        series_info_response = xtream_api.series_info_by_id(series_id)

    if not series_info_response or "episodes" not in series_info_response:
        control.notification(
            ADDON.getAddonInfo("name"),
            f"Could not retrieve details or episodes for {series_name}.",
            icon="ERROR",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    episodes_by_season = series_info_response.get("episodes", {})

    if not episodes_by_season:
        control.notification(
            ADDON.getAddonInfo("name"),
            f"No seasons or episodes found for {series_name}.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # --- Extract Series-level Art and ID from detailed response ---
    series_info = series_info_response.get(
        "info", series_info_response.get("series_info", {})
    )

    # Use the 'cover' key for the poster/icon.
    series_poster = series_info_response.get("cover", series_info.get("cover", ""))

    # Get the fanart/backdrop path
    backdrop_paths = series_info_response.get("backdrop_path", [])
    series_fanart = backdrop_paths[0] if backdrop_paths else ""

    # Get the TMDb ID to pass to episodes list for full scraper integration
    tmdb_id = extract_tmdb_id(series_info_response)

    # Loop through the seasons found in the episode dictionary keys.
    for season_num in sorted(episodes_by_season.keys(), key=int):
        # Build the folder name for the season.
        season_title = f"Season {season_num}"

        # 2. Build the internal URL to call the episodes listing function.
        url_params = {
            "mode": "list_series_episodes",
            "series_id": series_id,
            "season_num": season_num,
            "series_name": series_name,
            "series_poster": series_poster,
            "series_fanart": series_fanart,
            "tmdb_id": tmdb_id,
        }
        url = sys.argv[0] + "?" + urlparse.urlencode(url_params)

        # 3. Create list item and set Art/Info
        list_item = xbmcgui.ListItem(label=season_title)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # Use a dictionary to build art, ensuring required keys are present
        art_dict = {"icon": "DefaultSeason.png", "thumb": "DefaultSeason.png"}

        if series_poster:
            art_dict["poster"] = series_poster
            art_dict["thumb"] = series_poster
        if series_fanart:
            art_dict["fanart"] = series_fanart

        list_item.setArt(art_dict)

        list_item.setInfo(
            "video",
            {
                "title": season_title,
                "tvshowtitle": series_name,
                "season": int(season_num),
                "mediatype": "season",
            },
        )

        # Set the TMDb ID property to assist the scraper at the season level
        if tmdb_id and tmdb_flag:
            list_item.setProperty("tmdbnumber", str(tmdb_id))
            # We set the season number property too, for maximum scraper help
            list_item.setProperty("season", season_num)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_series_episodes(
    series_id, season_num, series_name, series_poster="", series_fanart="", tmdb_id=""
):
    if not setup_api_config():
        return

    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    params = dict(urlparse.parse_qsl(sys.argv[2]))
    series_poster = params.get("series_poster", series_poster)
    series_fanart = params.get("series_fanart", series_fanart)
    series_info = xtream_api.series_info_by_id(series_id)
    tmdb_id = params.get("tmdb_id") or extract_tmdb_id(series_info)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"{series_name} - Season {season_num}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "episodes")

    series_info = cache_handler.get("series_info", f"{xtream_api.USERNAME}_{series_id}")
    if not series_info:
        if settings.get_cache_on_off(ADDON):
            utils.notification("Series info not Cached", icon="INFO")
        series_info = xtream_api.series_info_by_id(series_id)

    series_info = xtream_api.series_info_by_id(series_id)
    episodes = series_info.get("episodes", {}).get(season_num, [])

    if not episodes:
        control.notification(
            ADDON.getAddonInfo("name"),
            f"No episodes found for Season {season_num}.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    tmdb_series_details = None
    series_fanart_hd = None

    if tmdb_flag and tmdb_id:
        tmdb_series_details = tmdb_helper.get_series_details(tmdb_id)
        series_fanart_hd = (
            tmdb_series_details["art"].get("fanart") if tmdb_series_details else None
        )

    for episode in episodes:
        episode_data = episode.get("info", {})
        episode_num_str = str(episode.get("episode_num", "1"))

        base_title = episode.get("title", f"Episode {episode_num_str}")
        episode_title = (
            f"S{season_num.zfill(2)}E{episode_num_str.zfill(2)} - {base_title}"
        )

        stream_id = episode.get("id")
        ext = episode.get("container_extension", "mp4")

        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type="series",
            container_extension=ext,
        )

        if play_url:
            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {"mode": "play_stream", "url": play_url, "name": episode_title}
                )
            )

            list_item = xbmcgui.ListItem(label=episode_title)
            list_item.setProperty("IsPlayable", "true")
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

            episode_icon = episode_data.get("movie_image", "") or episode.get(
                "thumbnail", ""
            )

            season_int = int(season_num)
            episode_int = int(episode_num_str)

            art_dict = {"icon": "DefaultVideo.png"}

            tmdb_ep_details = None
            episode_still = None
            episode_fanart = None

            if tmdb_flag and tmdb_id:
                tmdb_ep_details = tmdb_helper.get_episode_details(
                    tmdb_id, season_int, episode_int
                )

            if tmdb_ep_details:
                stills = tmdb_ep_details.get("images", {}).get("stills", [])
                if stills:
                    file_path = stills[0].get("file_path")
                    if file_path:
                        episode_still = (
                            f"https://image.tmdb.org/t/p/original{file_path}"
                        )

            if series_fanart_hd:
                episode_fanart = series_fanart_hd

            if episode_still:
                art_dict["thumb"] = episode_still
            elif episode_icon:
                art_dict["thumb"] = episode_icon
            elif series_poster:
                art_dict["thumb"] = series_poster

            if episode_fanart:
                art_dict["fanart"] = episode_fanart
            elif episode_still:
                art_dict["fanart"] = episode_still
            elif series_fanart:
                art_dict["fanart"] = series_fanart
            elif series_poster:
                art_dict["fanart"] = series_poster

            list_item.setArt(art_dict)

            info_label = {
                "title": base_title,
                "season": season_int,
                "episode": episode_int,
                "tvshowtitle": series_name,
                "mediatype": "episode",
            }

            if tmdb_ep_details:
                info_label["plot"] = tmdb_ep_details.get("overview") or ""
                info_label["rating"] = tmdb_ep_details.get("vote_average") or 0.0
                info_label["aired"] = tmdb_ep_details.get("air_date")
            else:
                info_label["plot"] = episode_data.get("plot", "")

            list_item.setInfo("video", info_label)

            if tmdb_flag and tmdb_id:
                list_item.setProperty("tmdbnumber", str(tmdb_id))
                list_item.setProperty("season", str(season_int))
                list_item.setProperty("episode", str(episode_int))

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE,
                url=url,
                listitem=list_item,
                isFolder=False,
            )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def global_series_search():
    if not setup_api_config():
        return

    keyboard = xbmc.Keyboard("", "Search ALL TV Series")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    index = _read_index("series")
    if not index:
        control.notification(
            "Search",
            "No Series index found. Use 'Rebuild Search Index' from main menu.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"Global Series Search: {query}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "tvshows")

    scored = []
    for entry in index:
        score = _fuzzy_score(query, entry.get("lower") or entry.get("title"))
        if score >= 0.55:
            scored.append((score, entry))

    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        control.notification("Search", "No matching series found.", icon="INFO")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for score, entry in scored:
        series_id = entry["id"]
        name = entry["title"]
        thumb = entry.get("thumb", "")
        tmdb_id = entry.get("tmdb")

        list_item = xbmcgui.ListItem(label=name)
        art = {"thumb": thumb, "poster": thumb} if thumb else {}
        info = {
            "title": name,
            "mediatype": "tvshow",
        }

        if art:
            list_item.setArt(art)
        list_item.setInfo("video", info)

        if tmdb_id and settings.get_tmdb_on_off(ADDON):
            list_item.setProperty("tmdbnumber", str(tmdb_id))
            list_item.setProperty("imdbnumber", str(tmdb_id))

        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_series_seasons",
                    "series_id": series_id,
                    "series_name": name,
                }
            )
        )
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def global_live_search():
    if not setup_api_config():
        return

    keyboard = xbmc.Keyboard("", "Search ALL Live TV")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    index = _read_index("live")
    if not index:
        control.notification(
            "Search",
            "No Live index found. Use 'Rebuild Search Index' from main menu.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"Global Live Search: {query}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    scored = []

    for entry in index:
        stream_id = entry["id"]
        title_lower = entry.get("lower", "")
        score = _fuzzy_score(query, title_lower)

        # --- also check EPG cache for this stream ---
        epg_key = f"{xtream_api.USERNAME}_{stream_id}"
        epg_cached = cache_handler.get("epg_data", epg_key)

        epg_match_boost = 0
        epg_program_title = ""
        epg_program_desc = ""

        if epg_cached and isinstance(epg_cached.get("epg_listings"), list):
            for listing in epg_cached["epg_listings"]:
                ep_title = listing.get("title", "").lower()
                ep_desc = listing.get("description", "").lower()

                if query.lower() in ep_title or query.lower() in ep_desc:
                    epg_match_boost = 0.35  # strong boost
                    epg_program_title = listing.get("title", "")
                    epg_program_desc = listing.get("description", "")
                    break

        total_score = score + epg_match_boost

        if total_score >= 0.55:
            entry["media"] = "live"
            entry["epg_title"] = epg_program_title
            entry["epg_desc"] = epg_program_desc
            entry["score"] = total_score
            scored.append((total_score, entry))

    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        control.notification("Search", "No matching channels found.", icon="INFO")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for score, entry in scored:
        stream_id = entry["id"]
        name = entry["title"]
        thumb = entry.get("thumb", "")
        ext = entry.get("ext", "ts")

        list_item = xbmcgui.ListItem(label=name)
        art = {"thumb": thumb, "icon": thumb} if thumb else {}
        info = {
            "title": name,
            "mediatype": "video",
            "tvshowtitle": name,
        }

        if art:
            list_item.setArt(art)
        list_item.setInfo("video", info)
        list_item.setProperty("IsPlayable", "true")

        play_url = xtream_api.build_stream_url(stream_id, "live", ext)
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode({"mode": "play_stream", "url": play_url, "name": name})
        )
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def global_vod_search():
    if not setup_api_config():
        return

    keyboard = xbmc.Keyboard("", "Search ALL Movies")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    index = _read_index("vod")
    if not index:
        control.notification(
            "Search",
            "No VOD index found. Use 'Rebuild Search Index' from main menu.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"Global Movie Search: {query}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "movies")

    scored = []
    for entry in index:
        score = _fuzzy_score(query, entry.get("lower") or entry.get("title"))
        if score >= 0.55:
            scored.append((score, entry))

    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        control.notification("Search", "No matching movies found.", icon="INFO")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for score, entry in scored:
        stream_id = entry["id"]
        name = entry["title"]
        thumb = entry.get("thumb", "")
        tmdb_id = entry.get("tmdb")
        ext = entry.get("ext", "mp4")

        list_item = xbmcgui.ListItem(label=name)
        art = {"thumb": thumb, "poster": thumb} if thumb else {}
        info = {"title": name, "mediatype": "movie"}

        if tmdb_id:
            try:
                tmdb_details = tmdb_helper.get_movie_details(str(tmdb_id))
            except Exception:
                tmdb_details = None

            if tmdb_details:
                art.update(tmdb_details.get("art", {}) or {})
                info.update(
                    {
                        "plot": tmdb_details.get("plot"),
                        "year": int(tmdb_details.get("year") or 0),
                        "rating": float(tmdb_details.get("rating") or 0),
                    }
                )

        if art:
            list_item.setArt(art)
        list_item.setInfo("video", info)
        list_item.setProperty("IsPlayable", "true")

        play_url = xtream_api.build_stream_url(stream_id, "vod", ext)
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode({"mode": "play_stream", "url": play_url, "name": name})
        )
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def global_search():
    """
    GLOBAL SEARCH:
    Searches Live, Movies (VOD), and TV Series using the prebuilt indexes.
    Returns one combined list of results with fuzzy matching.
    """

    if not setup_api_config():
        return

    # Ask user for search text
    keyboard = xbmc.Keyboard("", "Global Search")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # Load all three indexes
    vod_index = _read_index("vod")
    series_index = _read_index("series")
    live_index = _read_index("live")

    if not (vod_index or series_index or live_index):
        control.notification(
            "Search", "No search index found. Rebuild index first.", icon="ERROR"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"Global Search: {query}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    results = []

    # --- VOD RESULTS ---
    for entry in vod_index:
        score = _fuzzy_score(query, entry.get("lower"))
        if score >= 0.55:
            entry["media"] = "movie"
            results.append((score, entry))

    # --- SERIES RESULTS ---
    for entry in series_index:
        score = _fuzzy_score(query, entry.get("lower"))
        if score >= 0.55:
            entry["media"] = "series"
            results.append((score, entry))

    # --- LIVE TV RESULTS ---
    for entry in live_index:
        stream_id = entry["id"]
        title_lower = entry.get("lower", "")
        score = _fuzzy_score(query, title_lower)

        # --- also check EPG cache for this stream ---
        epg_key = f"{xtream_api.USERNAME}_{stream_id}"
        epg_cached = cache_handler.get("epg_data", epg_key)

        epg_match_boost = 0
        epg_program_title = ""
        epg_program_desc = ""

        if epg_cached and isinstance(epg_cached.get("epg_listings"), list):
            for listing in epg_cached["epg_listings"]:
                ep_title = listing.get("title", "").lower()
                ep_desc = listing.get("description", "").lower()

                if query.lower() in ep_title or query.lower() in ep_desc:
                    epg_match_boost = 0.35  # strong boost
                    epg_program_title = listing.get("title", "")
                    epg_program_desc = listing.get("description", "")
                    break

        total_score = score + epg_match_boost

        if total_score >= 0.55:
            entry["media"] = "live"
            entry["epg_title"] = epg_program_title
            entry["epg_desc"] = epg_program_desc
            entry["score"] = total_score
            results.append((total_score, entry))

        # Sort by score
        results.sort(key=lambda x: x[0], reverse=True)

        if not results:
            control.notification("Search", "No results found.", icon="INFO")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # ------------------------------------------------------------
    # BUILD DIRECTORY ITEMS
    # ------------------------------------------------------------
    for score, entry in results:
        name = entry["title"]
        thumb = entry.get("thumb", "")
        media = entry.get("media")

        list_item = xbmcgui.ListItem(label=name)
        art = {"thumb": thumb, "poster": thumb} if thumb else {}
        list_item.setArt(art)

        # Basic info
        info = {"title": name}

        # -------- MOVIE --------
        if media == "movie":
            info["mediatype"] = "movie"
            list_item.setInfo("video", info)

            ext = entry.get("ext", "mp4")
            play_url = xtream_api.build_stream_url(entry["id"], "vod", ext)
            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {"mode": "play_stream", "url": play_url, "name": name}
                )
            )

            list_item.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, False)

        # -------- TV SERIES --------
        elif media == "series":
            info["mediatype"] = "tvshow"
            list_item.setInfo("video", info)

            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {
                        "mode": "list_series_seasons",
                        "series_id": entry["id"],
                        "series_name": name,
                    }
                )
            )

            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, True)

        # -------- LIVE CHANNEL --------
        elif media == "live":
            info["mediatype"] = "video"
            list_item.setInfo("video", info)
            list_item.setProperty("IsPlayable", "true")

            ext = entry.get("ext", "ts")
            play_url = xtream_api.build_stream_url(entry["id"], "live", ext)
            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {"mode": "play_stream", "url": play_url, "name": name}
                )
            )

            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def recently_watched():
    history = load_history()

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Recently Watched")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    if not history:
        item = xbmcgui.ListItem("No recently watched items.")
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, "", item, isFolder=False)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for entry in history:
        title = entry.get("title", "Unknown")
        thumb = entry.get("thumb", "")
        play_url = entry.get("play_url")  # IMPORTANT — stored full URL
        stream_type = entry.get("type", "vod")
        stream_id = entry.get("id", "")

        # Build plugin call (we do NOT rebuild Xtream URL here)
        plugin_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "play_stream",
                    "url": play_url,  # USE stored URL
                    "id": stream_id,
                    "type": stream_type,
                    "name": title,
                }
            )
        )

        li = xbmcgui.ListItem(label=title)
        if thumb:
            li.setArt({"thumb": thumb, "icon": thumb})

        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        # Context menu
        li.addContextMenuItems(
            [("Clear Recently Watched", f"RunPlugin({sys.argv[0]}?mode=clear_history)")]
        )

        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

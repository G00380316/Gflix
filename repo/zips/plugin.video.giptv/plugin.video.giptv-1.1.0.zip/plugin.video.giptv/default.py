import sys, os
# Python 2/3 compatibility for URL parsing
try:
	import urlparse
except ImportError:
	import urllib.parse as urlparse

# Add resources path to ensure modules can be imported
sys.path.insert(0, os.getcwd())

# Import the main router logic
import resources.lib.router as router

# --- Main Execution ---

if __name__ == '__main__':
	# sys.argv[2] contains the URL parameters (the query string)
	# [1:] is used to remove the leading '?'
	params = urlparse.parse_qs(sys.argv[2][1:])
	router.handle_routing(params)

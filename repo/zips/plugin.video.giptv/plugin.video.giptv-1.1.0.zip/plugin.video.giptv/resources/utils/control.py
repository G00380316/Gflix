from json import dumps as jsdumps, loads as jsloads
import xml.etree.ElementTree as ET
import os.path
import xbmcaddon
import xbmcgui
import xbmcvfs

addon = xbmcaddon.Addon
AddonInstance = xbmcaddon.Addon() # Capture the Addon instance for reuse
AddonID = AddonInstance.getAddonInfo('id')
addonInfo = AddonInstance.getAddonInfo
addonName = addonInfo('name')
getLangString = AddonInstance.getLocalizedString
transPath = xbmcvfs.translatePath

dialog = xbmcgui.Dialog()
homeWindow = xbmcgui.Window(10000)

joinPath = os.path.join
isfilePath = os.path.isfile
absPath = os.path.abspath


SETTINGS_PATH = transPath(joinPath(addonInfo('path'), 'resources', 'settings.xml'))
try: dataPath = transPath(addonInfo('profile')).decode('utf-8')
except: dataPath = transPath(addonInfo('profile'))
settingsFile = joinPath(dataPath, 'settings.xml')

def openSettings():
    """Opens the main settings dialog for the Kodi Addon."""
    return AddonInstance.openSettings()

def setting(id, fallback=None):
    try:
        settings_dict = jsloads(homeWindow.getProperty('giptv_settings'))
    except:
        settings_dict = make_settings_dict()
    if settings_dict is None:
        settings_dict = settings_fallback(id)
    value = settings_dict.get(id, '')
    if fallback is None:
        return value
    if value == '':
        return fallback
    return value

def settings_fallback(id):
    return {id: AddonInstance.getSetting(id)}

def make_settings_dict(): # service runs upon a setting change
    try:
        root = ET.parse(settingsFile).getroot()
        settings_dict = {}
        for item in root:
            dict_item = {}
            setting_id = item.get('id')
            setting_value = item.text
            if setting_value is None:
                setting_value = ''
            dict_item = {setting_id: setting_value}
            settings_dict.update(dict_item)
        homeWindow.setProperty('giptv_settings', jsdumps(settings_dict))
        return settings_dict
    except:
        return None

def lang(language_id):
    return str(getLangString(language_id))

def getzoroVersion():
    return AddonInstance.getAddonInfo('version')

def addonVersion(addon):
    return xbmcaddon.Addon(addon).getAddonInfo('version')

def addonId():
    return addonInfo('id')

def addonName():
    return addonInfo('name')

def addonPath(addon):
    try:
        addonID = xbmcaddon.Addon(addon)
    except:
        addonID = None
    if addonID is None:
        return ''
    else:
        try:
            return transPath(addonID.getAddonInfo('path').decode('utf-8'))
        except:
            return transPath(addonID.getAddonInfo('path'))

def appearance():
    theme = setting('appearance.1').lower()
    return theme

def artPath():
    # Adjusted to use AddonID instead of hardcoded 'plugin.video.giptv'
    theme = appearance()
    return joinPath(xbmcaddon.Addon(AddonID).getAddonInfo('path'), 'resources', 'media', theme)

def addonIcon():
    theme = appearance()
    art = artPath()
    if not (art is None and theme in ('-', '')):
        return joinPath(art, 'icon.png')
    return addonInfo('icon')

# -- Dialog Functions ---
def notification(title=None, message=None, icon=None, time=3000, sound=(setting('notification.sound') == 'true')):
    if title == 'default' or title is None:
        title = addonName()
    if isinstance(title, int):
        heading = lang(title)
    else:
        heading = str(title)
    if isinstance(message, int):
        body = lang(message)
    else:
        body = str(message)
    if not icon or icon == 'default':
        icon = addonIcon()
    elif icon == 'INFO':
        icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING':
        icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR':
        icon = xbmcgui.NOTIFICATION_ERROR
    return dialog.notification(heading, body, icon, time, sound)

def yesnoDialog(line1, line2, line3, heading=addonInfo('name'), nolabel='', yeslabel=''):
    message = '%s[CR]%s[CR]%s' % (line1, line2, line3)
    return dialog.yesno(heading, message, nolabel, yeslabel)

def yesnocustomDialog(line1, line2, line3, heading=addonInfo('name'), customlabel='', nolabel='', yeslabel=''):
    message = '%s[CR]%s[CR]%s' % (line1, line2, line3)
    return dialog.yesnocustom(heading, message, customlabel, nolabel, yeslabel)

def selectDialog(list, heading=addonInfo('name')):
    return dialog.select(heading, list)

def okDialog(title=None, message=None):
    if title == 'default' or title is None:
        title = addonName()
    if isinstance(title, int):
        heading = lang(title)
    else:
        heading = str(title)
    if isinstance(message, int):
        body = lang(message)
    else:
        body = str(message)
    return dialog.ok(heading, body)

def context(items=None, labels=None):
    if items:
        labels = [i[0] for i in items]
        choice = dialog.contextmenu(labels)
        if choice >= 0:
            return items[choice][1]()
        else:
            return False
    else:
        return dialog.contextmenu(labels)

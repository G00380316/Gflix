# resources/lib/router.py

# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import xbmcaddon
import xbmcgui
import xbmcplugin

# Import external modules
import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator
import resources.utils.control as control

ADDON = xbmcaddon.Addon()

def open_addon_settings():
    """Opens the addon settings dialog and shows a notification. (Handler for context menu)"""
    # Use the custom control function to open settings
    control.openSettings()

def play_stream(url, name):
    """
    Plays the final stream URL in Kodi.
    """
    play_item = xbmcgui.ListItem(path=url)
    play_item.setLabel(name)
    play_item.setProperty('IsPlayable', 'true')
    # Use the handle from the navigator context for consistency
    xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, play_item)


def handle_routing(url_params):
    """
    Routes the request based on the 'mode' parameter extracted from the URL.
    """
    # Parameters come in as lists, so we use [0] to get the value
    mode = url_params.get('mode', [None])[0]
    
    if mode == 'list_streams':
        stream_type = url_params.get('stream_type', [''])[0]
        category_id = url_params.get('category_id', [''])[0]
        name = url_params.get('name', [''])[0]
        # Dispatch to navigator
        navigator.list_streams(stream_type, category_id, name)
        
    elif mode == 'play_stream':
        url = url_params.get('url', [''])[0]
        name = url_params.get('name', [''])[0]
        # Dispatch to local play handler
        play_stream(url, name)
        
    elif mode == 'open_settings':
        # Handler for the context menu click
        open_addon_settings()
        
    elif mode is None:
        # Default entry point: Start by listing Live TV categories
        # Dispatch to navigator
        navigator.list_categories(xtream_api.LIVE_TYPE)
        
    else:
        control.okDialog(ADDON.getAddonInfo('name'), f"Unknown mode: {mode}")

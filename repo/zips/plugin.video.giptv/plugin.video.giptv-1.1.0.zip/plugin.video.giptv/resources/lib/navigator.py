# resources/lib/navigator.py

import sys
# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Import external modules
import resources.apis.xtream_api as xtream_api
from resources.utils import settings
import resources.utils.control as control

# Global constants for Kodi API
ADDON = xbmcaddon.Addon()
# We need to rely on the handle passed to the main router,
# but for internal listing functions, we can safely pull it from sys.argv[1]
PLUGIN_HANDLE = int(sys.argv[1])
ADDON_ID = ADDON.getAddonInfo('id')

# --- CONTEXT MENU SETUP ---
# Define the URL that calls the router with mode='open_settings'
SETTINGS_ACTION_URL = 'RunPlugin(plugin://{}/?mode=open_settings)'.format(ADDON_ID)

# Define the Context Menu Item as a tuple: (Label, Action)
SETTINGS_CONTEXT_MENU = [
    ("Open Settings", SETTINGS_ACTION_URL)
]


# --- Configuration Setup ---
def setup_api_config():
    """Sets API credentials from Kodi settings. (Kept here as it's directly tied to listing validity)"""
    try:
        selectedAccount = ADDON.getSetting('account')
        
        if selectedAccount == "0":
            selectedAccount = "server"
        elif selectedAccount == "1":
            selectedAccount = "server1"
        elif selectedAccount == "2":
            selectedAccount = "server2"
        else:
            control.notification(ADDON.getAddonInfo('name'), f"Selected Account {selectedAccount} is not valid.", icon='ERROR')
            xbmc.sleep(1500)
            control.openSettings()
            return False

        server, username, password = settings.get_api_credentials(ADDON, selectedAccount)

        if not str(server).startswith("http://") and not str(server).startswith("https://"):
            control.notification("Configuration Error", "Please configure your IPTV credentials in the add‑on settings.", time=5000, icon='ERROR')
            xbmc.sleep(1500)
            control.openSettings()
            return False
        
        # Set the global variables in the API module
        xtream_api.SERVER = server.rstrip('/')
        xtream_api.USERNAME = username
        xtream_api.PASSWORD = password
        return True
    except Exception as e:
        control.notification(ADDON.getAddonInfo('name'), f"Configuration Setup Error: {e}", icon='ERROR')
        xbmc.sleep(1500)
        control.openSettings()
        return False


def list_categories(stream_type):
    """
    Lists the top-level categories (e.g., Sports, News) for a given stream type.
    """
    if not setup_api_config():
        return

    # 1. Authenticate and check status
    auth_data = xtream_api.authenticate()
    if not auth_data or auth_data.get('user_info', {}).get('auth') != 1:
        error_msg = auth_data.get('user_info', {}).get('message', "Authentication Failed or Account Expired.")
        control.notification(ADDON.getAddonInfo('name'), error_msg, icon='ERROR')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # 2. Get categories
    category_list = xtream_api.categories(stream_type)

    if not category_list:
        control.notification(ADDON.getAddonInfo('name'), "Failed to retrieve categories or list is empty.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for category in category_list:
        name = category.get('category_name', 'Unknown Category')
        category_id = category.get('category_id')
        
        # Build the URL to call list_streams when this item is selected
        url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'list_streams',
            'stream_type': stream_type,
            'category_id': category_id,
            'name': name
        })
        
        # Add the directory item to Kodi
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        
        # --- ADD CONTEXT MENU FOR FOLDERS ---
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True
        )

    # Finish listing
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_streams(stream_type, category_id, name):
    """
    Lists the actual streams (channels, movies, or series) within a selected category.
    """
    if not setup_api_config():
        return

    # Fetch streams for the given category ID
    stream_list = xtream_api.streams_by_category(stream_type, category_id)

    if not stream_list:
        control.notification(ADDON.getAddonInfo('name'), f"No streams found in {name}.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for stream in stream_list:
        stream_name = stream.get('name', 'Unknown Stream')
        stream_id = stream.get('stream_id')
        
        # The API response typically uses 'stream_type' for live, 'movie', or 'series'
        stream_type_key = stream.get('stream_type', stream_type)
        
        # Get the appropriate container extension (usually 'ts' for live)
        ext = stream.get('container_extension', 'ts')
        
        # Build the final playable URL using the API format
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type=stream_type_key,
            container_extension=ext
        )
        
        if play_url:
            # Build the URL for playback
            url = sys.argv[0] + '?' + urlparse.urlencode({
                'mode': 'play_stream',
                'url': play_url,
                'name': stream_name
            })
            
            # Create list item
            list_item = xbmcgui.ListItem(label=stream_name)
            list_item.setProperty('IsPlayable', 'true') # Required to tell Kodi this item is a video
            
            # --- ADD CONTEXT MENU FOR STREAMS ---
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
            
            # Set stream icon/thumbnail
            stream_icon = stream.get('stream_icon', '')
            if stream_icon:
                list_item.setArt({'thumb': stream_icon, 'icon': stream_icon})
            else:
                list_item.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE,
                url=url,
                listitem=list_item,
                isFolder=False # This is a playable item, not a folder
            )
        
    # Finish listing
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

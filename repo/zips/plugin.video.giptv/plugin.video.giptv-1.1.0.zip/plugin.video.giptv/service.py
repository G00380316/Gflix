import xbmc
import xbmcaddon

# Get the ID of the current addon
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')

class SettingsMonitor(xbmc.Monitor):
    # This method is called automatically when settings are changed
    def onSettingsChanged(self):
        # IMPORTANT: When settings are changed, the xbmcaddon.Addon() instance
        # might still be holding the old values. A small sleep can help.
        xbmc.sleep(200) 
        
        # --- Reload Settings if needed ---
        # addon = xbmcaddon.Addon(ADDON_ID)
        # new_setting_value = addon.getSetting('my_setting_key')
        
        # --- Force the refresh of the Kodi GUI Container ---
        # 'Container.Update' works best if you know the exact URL of the content to refresh.
        # This example assumes the add-on's main entry point (home screen) should be refreshed.
        # Replace 'plugin://' part with the actual URL of the container you want to update.
        # NOTE: This only works if that container is currently visible/loaded.
        
        # Try to refresh the currently visible container
        xbmc.executebuiltin('Container.Refresh')
        
        # OR, update a specific path (e.g., the add-on's root folder)
        # xbmc.executebuiltin(f'Container.Update(plugin://{ADDON_ID}/)')


# Create an instance of the monitor (needs to be done only once)
if __name__ == '__main__':
    monitor = SettingsMonitor()
    
    # Keep the monitor alive while Kodi is running (necessary for services)
    while not monitor.abortRequested():
        xbmc.sleep(100)
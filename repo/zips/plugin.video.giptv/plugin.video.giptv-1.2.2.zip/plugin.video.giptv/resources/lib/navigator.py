import sys
# Python 2/3 compatibility for handling URL encoding/decoding.
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc # Necessary for functions like xbmc.sleep() and xbmc.Keyboard().

# Import external modules
import resources.apis.xtream_api as xtream_api
from resources.utils import settings
import resources.utils.control as control
import resources.apis.tmdb_helper as TMDbHelper

# Global constants for the Kodi API.
ADDON = xbmcaddon.Addon()
# PLUGIN_HANDLE: The unique identifier Kodi gives to this running addon instance.
# We use this to tell Kodi where to put our list items.
PLUGIN_HANDLE = int(sys.argv[1])
ADDON_ID = ADDON.getAddonInfo('id')

# --- CONTEXT MENU SETUP ---
# Defines the Kodi built-in command URL that will call our router with the 'open_settings' mode.
SETTINGS_ACTION_URL = 'RunPlugin(plugin://{}/?mode=open_settings)'.format(ADDON_ID)

# SETTINGS_CONTEXT_MENU: The list item we attach to every folder/stream for the
# right-click/long-press menu.
SETTINGS_CONTEXT_MENU = [
    ("Open Settings", SETTINGS_ACTION_URL)
]

#Initialize helpers
tmdb_helper = TMDbHelper.TMDbHelper()

def root_menu():
    """
    The initial menu for the add-on, listing the primary content stream types (Live TV, Movies, Series).
    
    NOTE: The add-on's main router function (usually in default.py or addon.py)
    must be updated to call this function when no parameters are passed.
    """
    # Define the stream type keys that match the Xtream API expectations.
    LIVE_TYPE = 'live'
    VOD_TYPE = 'vod' # Used for Movies
    SERIES_TYPE = 'series'
    
    """Root menu with Live TV, Movies, and TV Series."""
    menu_items = [
        ("[B]Live TV[/B]", 'live', 'DefaultVideo.png'),
        ("[B]Movies[/B]", 'vod', 'DefaultMovies.png'),
        ("[B]TV Series[/B]", 'series', 'DefaultTVShows.png')
    ]

    for label, stream_type, thumb in menu_items:
        url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'list_categories',
            'stream_type': stream_type
        })
        item = xbmcgui.ListItem(label=label)
        item.setArt({'icon': 'icon.png', 'thumb': thumb})
        item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, item, isFolder=True)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, 'Xtream Content Streams')
    xbmcplugin.setContent(PLUGIN_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- Search Handlers ---
def search_menu(mode_to_call, stream_type=None, category_id=None):
    """
    Prompts the user for a search term using Kodi's keyboard, then updates the
    current directory to show filtered results by recalling the original mode
    with the new 'search_query' parameter.
    """
    # Open Kodi's on-screen keyboard for user input.
    keyboard = xbmc.Keyboard('', 'Enter Search Term')
    keyboard.doModal()
    
    # Check if the user confirmed the search (hit 'OK').
    if keyboard.isConfirmed():
        search_query = keyboard.getText()
        if search_query:
            # 1. Build the base parameters to rerun the previous listing function.
            params = {
                'mode': mode_to_call, # The function we want to run (e.g., list_categories).
                'search_query': search_query # The term the user just entered.
            }
            # 2. Re-add any necessary context parameters (like stream type or category ID).
            if stream_type:
                params['stream_type'] = stream_type
            if category_id:
                params['category_id'] = category_id
                
            # Construct the final URL with all parameters.
            url = sys.argv[0] + '?' + urlparse.urlencode(params)
            
            # Update the directory title to clearly show the user they are viewing search results.
            xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"Search Results for: {search_query}")
            xbmcplugin.setContent(PLUGIN_HANDLE, 'videos') # Set content type for proper Kodi view.
            
            # Tell Kodi's interface to refresh immediately with the new URL, replacing the current list.
            xbmc.executebuiltin('Container.Update(%s, replace)' % url)
            
    # Always close the directory listing, especially if the user cancels the keyboard.
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- Configuration Setup ---
def setup_api_config():
    """
    Retrieves the necessary Xtream credentials from Kodi settings and validates them.
    It prepares the `xtream_api` module for subsequent calls.
    """
    try:
        selectedAccount = ADDON.getSetting('account')
        
        # Determine which server group to pull credentials from based on user setting.
        if selectedAccount == "0":
            selectedAccount = "server"
        elif selectedAccount == "1":
            selectedAccount = "server1"
        elif selectedAccount == "2":
            selectedAccount = "server2"
        else:
            control.notification(ADDON.getAddonInfo('name'), f"Selected Account {selectedAccount} is not valid.", icon='ERROR')
            control.openSettings()
            return False

        server, username, password = settings.get_api_credentials(ADDON, selectedAccount)

        # Ensure the server URL starts with a protocol for a valid connection.
        if not str(server).startswith("http://") and not str(server).startswith("https://"):
            # 1. Show a clear notification about the configuration error.
            control.notification("Configuration Error", "Please configure your IPTV credentials in the add-on settings.", time=5000, icon='ERROR')
            
            # 2. Pause the script for 5 seconds to ensure the user reads the warning.
            xbmc.sleep(5000)
            
            # 3. Open the settings window immediately after the pause.
            control.openSettings()
            return False
        
        # Load the validated credentials into the global API module.
        xtream_api.SERVER = server.rstrip('/')
        xtream_api.USERNAME = username
        xtream_api.PASSWORD = password
        return True
    except Exception as e:
        control.notification(ADDON.getAddonInfo('name'), f"Configuration Setup Error: {e}", icon='ERROR')
        control.openSettings()
        return False


def list_categories(stream_type, search_query=None):
    """
    Displays the top-level content categories (e.g., Entertainment, Documentaries)
    for the given stream type (Live, VOD, Series, etc.).
    Includes logic for adding the [ Search Categories... ] option and filtering the results.
    """
    if not setup_api_config():
        return
    
    # Add a search entry point unless we are already viewing filtered results.
    if search_query is None:
        # URL sets mode to 'search', which the router intercepts to prompt for input.
        search_url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'search',
            'mode_to_call': 'list_categories', # We want the router to call this function again after the search term is ready.
            'stream_type': stream_type
        })
        
        # Create a dedicated search list item using the Kodi icon font (\ue836 for magnifying glass).
        search_item = xbmcgui.ListItem(label='[COLOR yellow]\ue836[/COLOR] [B]Search Categories...[/B]')
        search_item.setArt({'icon': 'DefaultAddonSearch.png', 'thumb': 'DefaultAddonSearch.png'})
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=search_url,
            listitem=search_item,
            isFolder=True
        )

    # 1. Authenticate with the server.
    auth_data = xtream_api.authenticate()
    if not auth_data or auth_data.get('user_info', {}).get('auth') != 1:
        error_msg = auth_data.get('user_info', {}).get('message', "Authentication Failed or Account Expired.")
        control.notification(ADDON.getAddonInfo('name'), error_msg, icon='ERROR')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # 2. Fetch all categories for the stream type (Live, VOD, etc.).
    category_list = xtream_api.categories(stream_type)

    if not category_list:
        control.notification(ADDON.getAddonInfo('name'), "Failed to retrieve categories or list is empty.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return
        
    # 3. Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        # Use a list comprehension to filter results by name containing the query string.
        category_list = [
            c for c in category_list
            if search_query in c.get('category_name', '').lower()
        ]
        if not category_list:
            control.notification(ADDON.getAddonInfo('name'), f"No categories found matching '{search_query}'.", icon='INFO')


    for category in category_list:
        name = category.get('category_name', 'Unknown Category')
        category_id = category.get('category_id')
        
        # Determine the next function to call: list_streams for Live/Movies, or list_series_streams for Series.
        if stream_type == 'series':
            next_mode = 'list_series_streams'
        else:
            next_mode = 'list_streams'
            
        # Build the URL to call the determined mode when the user clicks this folder.
        url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': next_mode,
            'stream_type': stream_type,
            'category_id': category_id,
            'name': name
        })
        
        # Create the Kodi list item.
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        
        # Attach the "Open Settings" context menu.
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True # This item opens another folder.
        )

    # Signal to Kodi that we are finished listing items for this directory.
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the individual playable streams (channels, movies) within a selected category,
    now using TMDbHelper to fetch rich metadata for VOD streams.
    """
    if not setup_api_config():
        return
    
    epg_flag = settings.get_epg_on_off(ADDON)
    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    # --- Search entry point logic ---
    if search_query is None:
        search_label_suffix = "Streams"
        if stream_type == 'vod':
            search_label_suffix = "Movies"
            
        search_url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'search',
            'mode_to_call': 'list_streams',
            'stream_type': stream_type,
            'category_id': category_id
        })
        
        search_item = xbmcgui.ListItem(label=f'[COLOR yellow]\ue836[/COLOR] [B]Search {search_label_suffix}...[/B]')
        search_item.setArt({'icon': 'DefaultAddonSearch.png', 'thumb': 'DefaultAddonSearch.png'})
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=search_url,
            listitem=search_item,
            isFolder=True
        )


    # Fetch all streams for the given category ID from the API.
    stream_list = xtream_api.streams_by_category(stream_type, category_id)

    if not stream_list:
        control.notification(ADDON.getAddonInfo('name'), f"No streams found in {name}.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        stream_list = [
            s for s in stream_list
            if search_query in s.get('name', '').lower() or search_query in s.get('title', '').lower()
        ]
        if not stream_list:
            control.notification(ADDON.getAddonInfo('name'), f"No streams found matching '{search_query}'.", icon='INFO')
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

# --------------------------------------------------------------------------------------
# --- MAIN LOOP ---
# --------------------------------------------------------------------------------------
    for stream in stream_list:
        
        # --- INITIALIZE COMMON VARIABLES ---
        stream_id = str(stream.get('stream_id') or stream.get('movie_id') or stream.get('vod_id') or '')
        if not stream_id:
            continue
            
        stream_name = stream.get('name') or stream.get('title') or stream.get('stream_display_name') or 'Unknown Stream'
        stream_icon = stream.get('stream_icon') or stream.get('cover') or stream.get('tv_logo') or ''
        
        list_item = xbmcgui.ListItem(label=stream_name)
        
        tmdb_id = None
        mediatype = 'video'
        info_label = {}
        art_dict = {}

        # --- VOD/MOVIE STREAM HANDLING ---
        if stream_type == 'vod':
            stream_type_for_api = 'vod'
            ext = stream.get('container_extension', 'mp4')
            info_data = stream.get('info', {})
            mediatype = 'movie'
            
            # Extract TMDb ID
            tmdb_id_raw = stream.get('tmdb') or stream.get('tmdb_id')
            if tmdb_id_raw:
                tmdb_id = str(tmdb_id_raw)
            
            # --- TMDb Lookup and Overwrite ---
            tmdb_details = None
            if tmdb_id and tmdb_flag:
                # CRITICAL: Call the TMDb helper to get rich metadata
                tmdb_details = tmdb_helper.get_movie_details(tmdb_id)
                xbmcplugin.setContent(PLUGIN_HANDLE, 'movies') # Set content type

                if tmdb_details:
                    # Use rich TMDb data
                    
                    # 1. Update info label with rich TMDb data
                    info_label = {
                        'title': tmdb_details.get('title') or stream_name,
                        'plot': tmdb_details.get('plot'),
                        'year': int(tmdb_details.get('year')) if tmdb_details.get('year') and tmdb_details.get('year').isdigit() else 0,
                        'rating': float(tmdb_details.get('rating')) if tmdb_details.get('rating') else 0.0,
                        'mediatype': mediatype,
                        'director': info_data.get('director'), # Fallback to source for non-TMDb fetched fields
                        'genre': info_data.get('genre'),
                        'duration': info_data.get('duration_secs'),
                    }
                    
                    # 2. Set Art with TMDb/Source data
                    art_dict = tmdb_details.get('art', {})
                    # Ensure poster/thumb is set, prioritizing TMDb, then source icon
                    if not art_dict.get('poster') and stream_icon:
                        art_dict['poster'] = stream_icon
                        art_dict['thumb'] = stream_icon
                    if not art_dict.get('thumb') and art_dict.get('poster'):
                        art_dict['thumb'] = art_dict.get('poster')
                    
                    # 3. Set TMDb properties for Kodi scraper
                    list_item.setProperty('tmdbnumber', tmdb_id)
                    list_item.setProperty('imdbnumber', tmdb_id) # Set IMDb property for compatibility
                    
            else:
                # If TMDb lookup failed, fall back to basic source data
                # (but at least include poster/plot from source if possible)
                
                movie_plot = stream.get('plot') or info_data.get('plot') or 'TMDb lookup failed. No description available.'
                
                info_label = {
                    'title': stream_name,
                    'plot': movie_plot,
                    'mediatype': mediatype
                }
                if stream_icon:
                    art_dict['thumb'] = stream_icon
                    art_dict['icon'] = stream_icon
                    art_dict['poster'] = stream_icon


        # --- LIVE TV STREAM HANDLING (EPG Logic) ---
        else:
            stream_type_for_api = 'live'
            ext = stream.get('container_extension', 'ts')
            mediatype = 'video'
            
            # 1. Initialize Fallback Info (This will be used if EPG fails)
            info_label = {
                'title': stream_name,
                'plot': stream_name,
                'mediatype': mediatype,
                'tvshowtitle': stream_name,
            }
            
            # 2. Set Art (Channel Logo)
            art_dict = {}
            if stream_icon:
                art_dict['thumb'] = stream_icon
                art_dict['icon'] = stream_icon
            else:
                art_dict['icon'] = 'DefaultVideo.png'
                art_dict['thumb'] = 'DefaultVideo.png'

            # Set the initial list item label to the stream name (fallback)
            list_item.setLabel(stream_name)

            # --- EPG INTEGRATION: FETCH DATA ---
            # Assume stream_id is available from the stream dictionary
            stream_id = stream.get('stream_id')
            
            # *** CRITICAL CHANGE: Use the decoded API function ***
            #control.notification(f'EPG Flag {epg_flag}', xbmc.LOGDEBUG)
            if epg_flag:
                epg_data = xtream_api.get_decoded_epg_short_by_stream(stream_id)
            
                # Remove the debug notification here, as it can be noisy:
                # control.notification(f'EPG Data for Stream ID {stream_id}: {epg_data}', xbmc.LOGDEBUG)
                
                if epg_data and isinstance(epg_data, list) and len(epg_data) > 0:
                    
                    current_program = epg_data[0] # SAFELY access the first item now
                    
                    # --- Extract EPG Data from DECODED LISTING ---
                    
                    # These are already decoded strings (thanks to get_decoded_epg_short_by_stream)
                    epg_title = current_program.get('title')
                    epg_plot = current_program.get('description') or f"Currently showing: {epg_title or stream_name}"
                    
                    # Get the Python datetime objects for clean formatting and math
                    start_dt = current_program.get('start_time_dt')
                    stop_dt = current_program.get('stop_time_dt')
                    
                    # Keep original timestamps for Kodi properties (they expect strings/ints)
                    epg_start_ts = current_program.get('start_timestamp')
                    epg_stop_ts = current_program.get('stop_timestamp')
                    
                    # --- Format Time for Display Label ---
                    
                    # Format the datetime objects (e.g., '21:00' or '09:00 PM')
                    # %H:%M is 24-hour format; change to %I:%M %p for 12-hour AM/PM
                    start_time_display = start_dt.strftime('%H:%M') if start_dt else '??:??'
                    stop_time_display = stop_dt.strftime('%H:%M') if stop_dt else '??:??'
                    
                    title = f"{stream_name}[COLOR yellow] - {epg_title}[/COLOR]" if epg_title else stream_name
                    
                    # Update label and info with EPG data
                    list_item_label = f"[COLOR green][{start_time_display} - {stop_time_display}][/COLOR]   {title}"
                    list_item.setLabel(list_item_label)

                    # Calculate duration using the difference between datetime objects
                    duration_seconds = 0
                    if start_dt and stop_dt:
                        duration_seconds = int((stop_dt - start_dt).total_seconds())

                    info_label.update({
                        'title': epg_title or stream_name,
                        'plot': epg_plot,
                        'endtime': epg_stop_ts,
                        # Use the calculated duration in seconds
                        'duration': duration_seconds
                    })
                    
                    # --- Set Kodi Properties for EPG Progress Bar (Only if we have timestamps) ---
                    if epg_start_ts and epg_stop_ts:
                        list_item.setProperty('IsLive', 'true')
                        list_item.setProperty('TotalTime', str(duration_seconds)) # Use calculated duration
                        list_item.setProperty('StartTime', str(epg_start_ts))
                        list_item.setProperty('channel_id', str(stream_id))
                
                    # 4. Finalize the List Item (This step is critical to always execute)
                    list_item.setArt(art_dict)
                    list_item.setInfo('video', info_label)


        # --- BUILD PLAY URL AND FINALIZE LIST ITEM ---
        
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type=stream_type_for_api,
            container_extension=ext
        )
        
        if play_url:
            url = sys.argv[0] + '?' + urlparse.urlencode({
                'mode': 'play_stream',
                'url': play_url,
                'name': stream_name
            })
            
            list_item.setProperty('IsPlayable', 'true')
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
            
            # Set collected art and info
            list_item.setArt(art_dict)
            list_item.setInfo('video', info_label)

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE,
                url=url,
                listitem=list_item,
                isFolder=False
            )
        
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- SERIES NAVIGATION FUNCTIONS ---

def list_series_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the list of TV Series titles within a selected category.
    Now prioritizes setting the TMDb ID to allow Kodi's scrapers to fetch
    rich metadata (fanart, plot, cast, trailer, etc.) automatically.
    """
    if not setup_api_config():
        return
    
    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    # Fetch all series titles for the given category ID.
    series_list = xtream_api.streams_by_category(stream_type, category_id)
    
    # Filter the list if a search query was provided.
    if search_query:
        search_query = search_query.lower()
        series_list = [
            s for s in series_list
            if search_query in s.get('name', '').lower()
        ]
        if not series_list:
            control.notification(ADDON.getAddonInfo('name'), f"No series found matching '{search_query}'.", icon='INFO')
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    if not series_list:
        control.notification(ADDON.getAddonInfo('name'), f"No TV Series found in {name}.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    if search_query is None:
        search_label_suffix = "Series" # Use "Series" since this function lists series
            
        search_url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'search',
            'mode_to_call': 'list_series_streams', # <-- CORRECTED to call THIS function
            'stream_type': stream_type,
            'category_id': category_id
        })
        
        search_item = xbmcgui.ListItem(label=f'[COLOR yellow]\ue836[/COLOR] [B]Search {search_label_suffix}...[/B]')
        search_item.setArt({'icon': 'DefaultAddonSearch.png', 'thumb': 'DefaultAddonSearch.png'})
        search_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=search_url,
            listitem=search_item,
            isFolder=True
        )

    for series in series_list:
        series_name = series.get('name', 'Unknown Series')
        series_id = series.get('series_id')
        
        # --- CORE INFO EXTRACTION ---
        # We extract this core data to ensure *something* shows up,
        # but the TMDb ID will override it.
        plot = series.get('plot', 'No description available.')
        rating_str = series.get('rating', '0')
        genre = series.get('genre', '')
        cast_str = series.get('cast', '')
        series_icon = series.get('cover', '')

        year_str = series.get('release_date', '').split('-')[0]
        year = int(year_str) if year_str.isdigit() else 0
        
        try:
            rating = float(rating_str)
        except (ValueError, TypeError):
            rating = 0.0

        cast_list = [c.strip() for c in cast_str.split(',')] if cast_str else []
        
        # Get the TMDb ID, which is the key to rich metadata fetching.
        tmdb_id = series.get('tmdb')
        
        # Get the first backdrop path if available (used as a fallback or initial fanart)
        backdrop_list = series.get('backdrop_path', [])
        fanart_url = backdrop_list[0] if backdrop_list else ''
        
        # --- BUILD URL AND LIST ITEM ---
        url = sys.argv[0] + '?' + urlparse.urlencode({
            'mode': 'list_series_seasons',
            'series_id': series_id,
            'series_name': series_name
        })
        
        list_item = xbmcgui.ListItem(label=series_name)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # 1. Set Art (Poster and Fanart)
        art_dict = {'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'}

        if series_icon:
            art_dict['thumb'] = series_icon
            art_dict['icon'] = series_icon
            art_dict['poster'] = series_icon # Use the cover image as the poster

        if fanart_url:
            art_dict['fanart'] = fanart_url # Use the direct URL for fanart (backup/initial)
            
        list_item.setArt(art_dict)
        
        # 2. Set Info (Required for scraper integration)
        list_item.setInfo('video', {
            'title': series_name,
            'plot': plot,
            'year': year,
            'rating': rating,
            'genre': genre,
            'cast': cast_list,
            'mediatype': 'tvshow' # CRUCIAL for TV show views
        })
        
        # 3. CRITICAL: Set the TMDb ID property for Kodi Scrapers
        if tmdb_id and tmdb_flag:
            # Set the TMDb ID using the 'imdbnumber' property. 
            # Kodi skins often look here for external IDs to trigger scraping.
            list_item.setProperty('imdbnumber', str(tmdb_id))
            # Also set the TMDb URL if needed (less common, but sometimes helps)
            list_item.setProperty('tmdbnumber', str(tmdb_id))
            
            # If the user has a preferred external scraper set, you can ensure 
            # it is enabled for this directory:
            xbmcplugin.setContent(PLUGIN_HANDLE, 'tvshows') 
            
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True
        )
        
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_series_seasons(series_id, series_name):
    """
    Displays the season folders for a selected TV Series.
    Ensures series-level poster and fanart are applied to the season folders.
    """
    if not setup_api_config():
        return
        
    tmdb_flag = settings.get_tmdb_on_off(ADDON)
    
    # Set the directory title
    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, series_name)
    xbmcplugin.setContent(PLUGIN_HANDLE, 'seasons')
    
    # 1. Fetch detailed information for the series.
    series_info_response = xtream_api.series_info_by_id(series_id)

    if not series_info_response or 'episodes' not in series_info_response:
        control.notification(ADDON.getAddonInfo('name'), f"Could not retrieve details or episodes for {series_name}.", icon='ERROR')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return
        
    episodes_by_season = series_info_response.get('episodes', {})

    if not episodes_by_season:
        control.notification(ADDON.getAddonInfo('name'), f"No seasons or episodes found for {series_name}.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # --- Extract Series-level Art and ID from detailed response ---
    series_info = series_info_response.get('info', series_info_response.get('series_info', {}))
    
    # Use the 'cover' key for the poster/icon.
    series_poster = series_info_response.get('cover', series_info.get('cover', '')) 

    # Get the fanart/backdrop path
    backdrop_paths = series_info_response.get('backdrop_path', [])
    series_fanart = backdrop_paths[0] if backdrop_paths else ''

    # Get the TMDb ID to pass to episodes list for full scraper integration
    tmdb_id = series_info_response.get('tmdb', series_info.get('tmdb_id'))

    # Loop through the seasons found in the episode dictionary keys.
    for season_num in sorted(episodes_by_season.keys(), key=int):
        
        # Build the folder name for the season.
        season_title = f"Season {season_num}"

        # 2. Build the internal URL to call the episodes listing function.
        url_params = {
            'mode': 'list_series_episodes',
            'series_id': series_id,
            'season_num': season_num,
            'series_name': series_name,
            'series_poster': series_poster,
            'series_fanart': series_fanart,
            'tmdb_id': tmdb_id
        }
        url = sys.argv[0] + '?' + urlparse.urlencode(url_params)
        
        # 3. Create list item and set Art/Info
        list_item = xbmcgui.ListItem(label=season_title)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        
        # Use a dictionary to build art, ensuring required keys are present
        art_dict = {'icon': 'DefaultSeason.png', 'thumb': 'DefaultSeason.png'}
        
        if series_poster:
            art_dict['poster'] = series_poster
            art_dict['thumb'] = series_poster
        if series_fanart:
            art_dict['fanart'] = series_fanart

        list_item.setArt(art_dict)
        
        list_item.setInfo('video', {
            'title': season_title,
            'tvshowtitle': series_name,
            'season': int(season_num),
            'mediatype': 'season'
        })
        
        # Set the TMDb ID property to assist the scraper at the season level
        if tmdb_id and tmdb_flag:
            list_item.setProperty('tmdbnumber', str(tmdb_id))
            # We set the season number property too, for maximum scraper help
            list_item.setProperty('season', season_num)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=url,
            listitem=list_item,
            isFolder=True
        )
        
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def list_series_episodes(series_id, season_num, series_name, series_poster='', series_fanart='', tmdb_id=''):
    """
    Displays the individual playable episodes within a selected season.
    
    Updated to include rich info labels for Episodes, and to utilize
    passed-down series art and TMDb ID for scraping.
    """
    if not setup_api_config():
        return
    
    tmdb_flag = settings.get_tmdb_on_off(ADDON)

    # We must parse the arguments here as they were passed in the URL
    params = dict(urlparse.parse_qsl(sys.argv[2]))
    series_poster = params.get('series_poster', series_poster)
    series_fanart = params.get('series_fanart', series_fanart)
    tmdb_id = params.get('tmdb_id', tmdb_id)
        
    # Set the directory title
    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"{series_name} - Season {season_num}")
    xbmcplugin.setContent(PLUGIN_HANDLE, 'episodes')

    # Fetch detailed information for the series again
    series_info = xtream_api.series_info_by_id(series_id)
    episodes = series_info.get('episodes', {}).get(season_num, [])

    if not episodes:
        control.notification(ADDON.getAddonInfo('name'), f"No episodes found for Season {season_num}.", icon='INFO')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for episode in episodes:
        episode_data = episode.get('info', {})
        episode_num_str = str(episode.get('episode_num', '1'))
        
        base_title = episode.get('title', f"Episode {episode_num_str}")
        # Standard Kodi episode naming SXXEYY
        episode_title = f"S{season_num.zfill(2)}E{episode_num_str.zfill(2)} - {base_title}"
        
        stream_id = episode.get('id')
        
        # The API path for series streams is typically 'series'
        ext = episode.get('container_extension', 'mp4')
        
        # Build the final, direct URL for video playback via the API.
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type='series', # Explicitly use 'series' path segment
            container_extension=ext
        )
        
        if play_url:
            # Build the internal URL that the router will use to initiate playback using 'play_stream'.
            url = sys.argv[0] + '?' + urlparse.urlencode({
                'mode': 'play_stream',
                'url': play_url,
                'name': episode_title
            })
            
            # Create list item.
            list_item = xbmcgui.ListItem(label=episode_title)
            list_item.setProperty('IsPlayable', 'true')
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
            
            # Use episode thumbnail if available, otherwise use series poster/fanart.
            episode_icon = episode_data.get('movie_image', '') or episode.get('thumbnail', '')
            
            art_dict = {'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'}
            
            if episode_icon:
                art_dict['thumb'] = episode_icon
            elif series_poster:
                # Fallback to the series poster/cover art for episode thumbnail
                art_dict['thumb'] = series_poster
                
            # Apply series fanart to the background
            if series_fanart:
                art_dict['fanart'] = series_fanart

            list_item.setArt(art_dict)

            # Set rich episode info for Kodi
            info_label = {
                'title': base_title,
                'plot': episode_data.get('plot', ''),
                'season': int(season_num),
                'episode': int(episode_num_str),
                'tvshowtitle': series_name, # Critical: Tell Kodi the parent show name
                'aired': episode_data.get('air_date'),
                # The 'rating' from episode data might be IMDb-specific, use it if available
                'rating': float(episode_data.get('imdb_rating')) if episode_data.get('imdb_rating') else 0.0,
                'mediatype': 'episode'
            }
            list_item.setInfo('video', info_label)

            if tmdb_id and tmdb_flag:
                # By setting the TMDb ID, season, and episode numbers,
                # Kodi's scrapers can do a full episode-level data lookup.
                list_item.setProperty('tmdbnumber', str(tmdb_id))
                list_item.setProperty('tvshow.id', str(tmdb_id)) # Alternative property for show ID
            
            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE,
                url=url,
                listitem=list_item,
                isFolder=False # It's a playable file.
            )
        
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
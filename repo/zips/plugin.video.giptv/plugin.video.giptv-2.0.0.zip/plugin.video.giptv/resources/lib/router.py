# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import urllib.request
import xbmc
import xbmcaddon
import urllib.parse
import xbmcgui
import xbmcplugin

# Import external modules: API for content, navigator for menu logic, giptv for Kodi utilities.
from resources.lib.manager import history_manager
import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator
import resources.utils.giptv as giptv
from resources.lib.manager.history_manager import clear_history
from resources.lib.cache.history_cache import enqueue_write
from resources.lib.proxy.proxy_instance import ensure_proxy_running
import resources.lib.manager.search_manager as search

ADDON = xbmcaddon.Addon()


def open_addon_settings():
    """
    Opens the addon's settings dialog. This is the endpoint for the 'Settings'
    context menu option attached to list items.
    """
    # Use the custom giptv function to open settings
    giptv.open_settings()


def build_stream_fallbacks(url):
    fallbacks = [url]

    if url.endswith(".ts"):
        fallbacks.append(url[:-3] + ".m3u8")

    # Try without extension
    base = url.rsplit(".", 1)[0]
    fallbacks.append(base)

    # Deduplicate while preserving order
    seen = set()
    out = []
    for u in fallbacks:
        if u not in seen:
            out.append(u)
            seen.add(u)

    return out


def stream_responds(url, timeout=4):
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Kodi-GIPTV/1.0"},
            method="HEAD",
        )
        with urllib.request.urlopen(req, timeout=timeout):
            return True
    except Exception:
        return False


def is_vod(url):
    u = url.lower()
    return u.endswith(".mkv") or u.endswith(".mp4") or "/movie/" in u or "/series/" in u


def play_stream(url, name):
    is_vod = (
        url.lower().endswith((".mkv", ".mp4"))
        or "vod" in url.lower()
        or "series" in url.lower()
    )

    xbmc.log(f"[IPTV-PLAY] name={name} vod={is_vod} url={url}", xbmc.LOGINFO)

    if is_vod:
        li = xbmcgui.ListItem(path=url)
        li.setLabel(name)
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        li.setProperty("seekable", "true")
        xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, li)
        return

    port = ensure_proxy_running()

    # ------------------------------------------------------------
    # STREAM FALLBACK LOGIC
    # ------------------------------------------------------------
    candidates = build_stream_fallbacks(url)
    working = None

    for candidate in candidates:
        xbmc.log(f"[IPTV-PLAY] Trying stream: {candidate}", xbmc.LOGINFO)
        if stream_responds(candidate):
            working = candidate
            xbmc.log(f"[IPTV-PLAY] Stream OK: {candidate}", xbmc.LOGINFO)
            break

    if not working:
        xbmcgui.Dialog().notification(
            "Playback failed",
            "Stream unavailable (TS / HLS)",
            xbmcgui.NOTIFICATION_ERROR,
            5000,
        )
        return

    proxied = "http://127.0.0.1:{}/stream?u={}".format(
        port, urllib.parse.quote(working, safe="")
    )

    xbmc.log(f"[IPTV-PLAY] Using proxied stream: {proxied}", xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=proxied)
    li.setLabel(name)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setProperty("isLive", "true")
    li.setProperty("seekable", "false")

    stream_id = url.split("/")[-1].split(".")[0]
    entry = {
        "item_id": stream_id,
        "title": name,
        "stream_type": (
            "live" if "/live/" in url else "vod" if "/movie/" in url else "series"
        ),
        "thumb": "",
        "fanart": "",
        "resume_time": 0,
        "play_url": url,
    }
    enqueue_write(entry)

    xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, li)

    monitor = xbmc.Monitor()
    player = xbmc.Player()

    xbmc.log("[IPTV-PLAY] Entering playback keep-alive loop", xbmc.LOGINFO)

    while not monitor.abortRequested():
        if player.isPlaying():
            xbmc.sleep(500)
        else:
            break

    xbmc.log("[IPTV-PLAY] Playback ended, exiting loop", xbmc.LOGINFO)


def handle_routing(url_params):
    """
    Central router / dispatcher for the addon.

    Responsibilities:
    - Read URL parameters produced by Kodi
    - Determine the requested 'mode'
    - Dispatch control to the appropriate handler
    - Provide consistent logging for debugging & support
    """

    # ------------------------------------------------------------
    # Extract common parameters
    # Kodi provides params as lists (from parse_qs)
    # ------------------------------------------------------------
    mode = url_params.get("mode", [None])[0]
    search_query = url_params.get("search_query", [None])[0]

    xbmc.log(
        f"[giptv][ROUTER] mode={mode} search_query={search_query} params={list(url_params.keys())}",
        xbmc.LOGINFO,
    )

    # ------------------------------------------------------------
    # Initial addon launch (no mode)
    # ------------------------------------------------------------
    # This occurs when the addon is opened from the Kodi UI root.
    if mode is None:
        xbmc.log("[giptv][ROUTER] Initial launch → root menu", xbmc.LOGINFO)
        navigator.root_menu()
        return

    # ------------------------------------------------------------
    # Content listing: Live TV / Movies
    # ------------------------------------------------------------
    if mode == "list_streams":
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_streams type={stream_type} category={category_id} name={name}",
            xbmc.LOGINFO,
        )
        navigator.list_streams(
            stream_type,
            category_id,
            name,
            search_query,
        )

    # ------------------------------------------------------------
    # TV Series navigation
    # ------------------------------------------------------------
    elif mode == "list_series_streams":
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_streams category={category_id} name={name}",
            xbmc.LOGINFO,
        )

        navigator.list_series_streams(
            stream_type,
            category_id,
            name,
            search_query,
        )

    elif mode == "list_series_seasons":
        series_id = url_params.get("series_id", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_seasons series_id={series_id}",
            xbmc.LOGINFO,
        )

        navigator.list_series_seasons(series_id, series_name)

    elif mode == "list_series_episodes":
        series_id = url_params.get("series_id", [""])[0]
        season_num = url_params.get("season_num", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_series_episodes series_id={series_id} season={season_num}",
            xbmc.LOGINFO,
        )

        navigator.list_series_episodes(series_id, season_num, series_name)

    # ------------------------------------------------------------
    # Playback
    # ------------------------------------------------------------
    elif mode == "play_stream":
        url = url_params.get("url", [""])[0]
        name = url_params.get("name", [""])[0]

        xbmc.log(
            f"[giptv][ROUTER] play_stream name={name} url={url}",
            xbmc.LOGINFO,
        )

        play_stream(url, name)

    # ------------------------------------------------------------
    # Settings & utility actions
    # ------------------------------------------------------------
    elif mode == "open_settings":
        xbmc.log("[giptv][ROUTER] open_settings", xbmc.LOGINFO)
        open_addon_settings()

    elif mode == "recently_watched":
        xbmc.log("[giptv][ROUTER] recently_watched", xbmc.LOGINFO)
        history_manager.recently_watched()

    elif mode == "clear_history":
        xbmc.log("[giptv][ROUTER] clear_history", xbmc.LOGINFO)
        clear_history()
        giptv.notification(
            ADDON.getAddonInfo("name"),
            "Recently Watched Reset Done",
            icon="INFO",
        )
        xbmc.executebuiltin("Container.Refresh")

    # ------------------------------------------------------------
    # Search routing
    # ------------------------------------------------------------
    elif mode == "search":
        stream_type = url_params.get("stream_type", [None])[0]
        category_id = url_params.get("category_id", [None])[0]

        # Retrieve the current items from navigator (you may need to store them in memory per session)
        current_items = navigator.get_current_items(stream_type, category_id)

        search.dynamic_filter_search(items=current_items)

    elif mode == "global_search":
        xbmc.log("[giptv][ROUTER] global_search", xbmc.LOGINFO)
        search.global_search()

    elif mode == "global_vod_search":
        xbmc.log("[giptv][ROUTER] global_vod_search", xbmc.LOGINFO)
        search.global_vod_search()

    elif mode == "global_series_search":
        xbmc.log("[giptv][ROUTER] global_series_search", xbmc.LOGINFO)
        search.global_series_search()

    elif mode == "global_live_search":
        xbmc.log("[giptv][ROUTER] global_live_search", xbmc.LOGINFO)
        search.global_live_search()

    # ------------------------------------------------------------
    # Category navigation (after root menu)
    # ------------------------------------------------------------
    elif mode == "list_categories":
        stream_type = url_params.get("stream_type", [xtream_api.LIVE_TYPE])[0]

        xbmc.log(
            f"[giptv][ROUTER] list_categories type={stream_type}",
            xbmc.LOGINFO,
        )
        navigator.list_categories(stream_type, search_query)

    # ------------------------------------------------------------
    # Failsafe
    # ------------------------------------------------------------
    else:
        xbmc.log(
            f"[giptv][ROUTER] Unknown mode received: {mode}",
            xbmc.LOGERROR,
        )
        giptv.ok_dialog(
            ADDON.getAddonInfo("name"),
            f"Unknown mode: {mode}",
        )

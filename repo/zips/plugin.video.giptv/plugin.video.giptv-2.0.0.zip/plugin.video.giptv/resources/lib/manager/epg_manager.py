import json
import os
import threading
import time
from resources.utils.xtream import STATE
import xbmc
import xbmcvfs
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta

from resources.apis.xmltv_fetcher import fetch_xmltv

ADDON_ID = "plugin.video.giptv"


EPG_LOCK_FILENAME = ".epg.lock"
EPG_LOCK_TTL = 30 * 60  # 30 minutes safety
EPG_TTL_SECONDS = 4 * 60 * 60  # 4 hours
# EPG_TTL_SECONDS = 2 * 60 * 60  # 2 hours
CACHE_FILENAME = "epg_index.json"

_XMLTV_INDEX = None
_LAST_LOADED = 0
_LOCK = threading.Lock()


def _epg_lock_path():
    return os.path.join(_cache_dir(), EPG_LOCK_FILENAME)


def _acquire_epg_lock():
    path = _epg_lock_path()

    if xbmcvfs.exists(path):
        try:
            stat = xbmcvfs.Stat(path)
            if time.time() - stat.st_mtime() < EPG_LOCK_TTL:
                log("EPG warm already running — skipping")
                return False
        except Exception:
            pass  # stale lock → override

    f = xbmcvfs.File(path, "w")
    try:
        f.write(str(int(time.time())))
    finally:
        f.close()

    return True


def _release_epg_lock():
    path = _epg_lock_path()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


def _cache_dir():
    base = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/cache")
    if not xbmcvfs.exists(base):
        xbmcvfs.mkdirs(base)
    return base


def _cache_path():
    # return os.path.join(_cache_dir(), CACHE_FILENAME)
    return os.path.join(_cache_dir(), _cache_filename())


def _cache_filename():
    user = STATE.username or "default"
    server = STATE.server or "server"

    safe_user = user.replace("/", "_").replace(":", "_")
    safe_server = server.replace("/", "_").replace(":", "_")

    return f"epg_index_{safe_user}_{safe_server}.json"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[giptv][epg] {msg}", level)


def _norm(s):
    return str(s).strip().upper().replace(" ", "_").replace("-", "_")


def _parse_xmltv_time(t):
    """
    XMLTV time formats:
    - YYYYMMDDHHMMSS
    - YYYYMMDDHHMMSS +0000
    - YYYYMMDDHHMMSS +0100
    """

    t = t.strip()

    # With timezone offset
    if " " in t:
        dt_part, tz_part = t.split(" ", 1)

        dt = datetime.strptime(dt_part, "%Y%m%d%H%M%S")

        # Parse offset like +0100 / -0200
        sign = 1 if tz_part.startswith("+") else -1
        hours = int(tz_part[1:3])
        minutes = int(tz_part[3:5])

        offset = timedelta(
            hours=hours * sign,
            minutes=minutes * sign,
        )

        dt = dt.replace(tzinfo=timezone(offset))
        return int(dt.timestamp())

    # No timezone → assume UTC (XMLTV spec)
    dt = datetime.strptime(t, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _build_epg_index(xmltv_path):
    """
    Returns:
    {
      CHANNEL_ID: {
        "now": (title, desc, start_ts, end_ts),
        "next": (title, desc, start_ts, end_ts) | None
      }
    }
    """
    log("Parsing XMLTV… (this may take a moment)")
    start_time = time.time()

    tree = ET.parse(xmltv_path)
    root = tree.getroot()

    now_ts = int(time.time())
    index = {}

    for prog in root.findall("programme"):
        channel = prog.get("channel")
        if not channel:
            continue

        channel = _norm(channel)

        start = prog.get("start")
        stop = prog.get("stop")
        if not start or not stop:
            continue

        start_ts = _parse_xmltv_time(start)
        end_ts = _parse_xmltv_time(stop)

        title_el = prog.find("title")
        desc_el = prog.find("desc")

        title = title_el.text if title_el is not None else ""
        desc = desc_el.text if desc_el is not None else ""

        index.setdefault(channel, []).append((start_ts, end_ts, title, desc))

    log(f"XMLTV parsed: {len(index)} channels in {time.time() - start_time:.2f}s")
    return index


def _load_cache():
    path = _cache_path()
    if not xbmcvfs.exists(path):
        return None, 0

    try:
        f = xbmcvfs.File(path, "r")
        raw = f.read()
        f.close()

        data = json.loads(raw)
        return data.get("index"), data.get("timestamp", 0)
    except Exception as e:
        log(f"Failed to load EPG cache: {e}", xbmc.LOGWARNING)
        return None, 0


def _save_cache(index):
    path = _cache_path()
    payload = {
        "timestamp": int(time.time()),
        "index": index,
    }

    try:
        f = xbmcvfs.File(path, "w")
        f.write(json.dumps(payload))
        f.close()
    except Exception as e:
        log(f"Failed to save EPG cache: {e}", xbmc.LOGWARNING)


def _warm_epg():
    global _XMLTV_INDEX, _LAST_LOADED

    if not _acquire_epg_lock():
        return

    try:
        # Snapshot STATE once
        username = STATE.username or "default"
        server = STATE.server or "server"

        log(f"EPG warm-up started for {username} / {server}")

        xmltv_path = fetch_xmltv()
        if not xmltv_path:
            log("XMLTV fetch failed during warm-up", xbmc.LOGERROR)
            return

        index = _build_epg_index(xmltv_path)
        _save_cache(index)

        with _LOCK:
            _XMLTV_INDEX = index
            _LAST_LOADED = int(time.time())

        log("EPG warm-up complete")

    finally:
        _release_epg_lock()


def get_xmltv_index():
    """
    Fast, non-blocking:
    - returns cached index immediately if available
    - refreshes in background if stale
    """
    global _XMLTV_INDEX, _LAST_LOADED

    with _LOCK:
        if _XMLTV_INDEX is not None:
            if time.time() - _LAST_LOADED > EPG_TTL_SECONDS:
                threading.Thread(target=_warm_epg, daemon=True).start()
            return _XMLTV_INDEX

    # No in-memory index yet → try disk
    index, ts = _load_cache()
    if index:
        with _LOCK:
            _XMLTV_INDEX = index
            _LAST_LOADED = ts

        if time.time() - ts > EPG_TTL_SECONDS:
            threading.Thread(target=_warm_epg, daemon=True).start()

        log("Loaded EPG index from disk cache")
        return index

    # Nothing cached → warm in background, return empty
    threading.Thread(target=_warm_epg, daemon=True).start()
    log("EPG index warming in background")
    return {}


def get_now(xmltv_index, channel_id):
    if not xmltv_index or not channel_id:
        return None

    cid = _norm(channel_id)
    progs = xmltv_index.get(cid)

    if not progs:
        return None

    now_ts = int(time.time())

    for start_ts, end_ts, title, desc in progs:
        if start_ts <= now_ts < end_ts:
            return (title, desc, start_ts, end_ts)

    return None


def get_now_next(xmltv_index, channel_id):
    if not xmltv_index or not channel_id:
        return None

    cid = _norm(channel_id)
    programmes = xmltv_index.get(cid)

    if not programmes:
        return None

    now_ts = int(time.time())
    now_prog = None
    next_prog = None

    for start_ts, end_ts, title, desc in programmes:
        if start_ts <= now_ts < end_ts:
            now_prog = (title, desc, start_ts, end_ts)
        elif start_ts > now_ts:
            next_prog = (title, desc, start_ts, end_ts)
            break

    return {
        "now": now_prog,
        "next": next_prog,
    }


def resolve_xmltv_channel_id(stream):
    cid = stream.get("epg_channel_id") or stream.get("tvg_id")

    if not cid:
        return None

    return str(cid).strip().upper().replace(" ", "_").replace("-", "_")

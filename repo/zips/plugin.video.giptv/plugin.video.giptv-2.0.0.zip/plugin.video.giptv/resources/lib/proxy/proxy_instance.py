import threading
import xbmc

from resources.lib.proxy.proxy_server import IPTVStreamProxy

_proxy = None
_port = None
_lock = threading.Lock()


def ensure_proxy_running():
    global _proxy, _port

    with _lock:
        if _proxy is None:
            _proxy = IPTVStreamProxy(host="127.0.0.1", port=0)
            _port = _proxy.start()
            xbmc.log(
                f"[IPTV-PROXY] Singleton proxy started on port {_port}", xbmc.LOGINFO
            )

    return _port

import requests
import base64  # Needed for decoding title and description
import datetime # Import for time handling
# IMPORT Kodi modules needed for cache file access
import xbmc
try:
    # Python 3
    import urllib.request as urllib
    import json
except ImportError:
    # Python 2 fallback (if your Kodi version is old)
    import urllib2 as urllib
    import json

from resources.utils.fetchCache import cache_handler

# --- Global Configuration (Set by the main Kodi script) ---
# These variables will hold the credentials read from config.py.
SERVER = ""
USERNAME = ""
PASSWORD = ""

LIVE_TYPE = "live"    # Standard API key for Live TV
VOD_TYPE = "vod"      # Standard API key for Movies
SERIES_TYPE = "series"  # Standard API key for Series

# Required User-Agent to mimic a browser, avoiding server blocks
HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/44.0.2403.89 Safari/537.36'
    )
}

# --- Helper function for fetching data ---

def _fetch_url(url, debug_name="API Request"):
    """
    INTERNAL FUNCTION: Downloads and attempts to parse JSON content from a URL.
    """
    try:
        # 1. Perform the HTTP request to DOWNLOAD the content
        response = urllib.urlopen(url)
        content = response.read().decode('utf-8') # Decode as EPG is usually UTF-8
        
        # 2. Attempt to parse the content as JSON
        data = json.loads(content)
        
        return data
        
    except urllib.HTTPError as e:
        # Handle HTTP errors (e.g., 404, 500)
        print(f"{debug_name} HTTP Error: {e.code} for URL: {url}")
        return None
        
    except Exception as e:
        # Handle connection or JSON parsing errors
        print(f"{debug_name} Failed to fetch or parse content: {e}")
        return None

def _decode_base64_epg_field(encoded_string):
    """
    Decodes a Base64 string to a UTF-8 string. Returns original if decoding fails.
    """
    if not encoded_string:
        return ""
    try:
        # The API output usually doesn't need padding, but this is safer.
        return base64.b64decode(encoded_string).decode('utf-8')
    except Exception:
        # Fallback to the original string if it wasn't valid Base64
        return encoded_string

def _timestamp_to_datetime(timestamp_str):
    """
    Converts a Unix timestamp string (like '1678886400') into a Python datetime object.
    Returns None if conversion fails. This assumes the server timestamps are in UTC.
    """
    if not timestamp_str:
        return None
    try:
        # Convert string to integer, then to datetime
        return datetime.datetime.fromtimestamp(int(timestamp_str))
    except (ValueError, TypeError):
        print(f"Warning: Failed to convert timestamp: {timestamp_str}")
        return None

# --- Core API Calls ---

def authenticate():
    """Authenticates user credentials and returns the JSON response."""
    url = get_authenticate_URL()
    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()  # Raise exception for bad status codes (4xx or 5xx)
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Xtream API Authentication Error: {e}")
        return None


def categories(streamType):
    """Fetches categories for Live, VOD, or Series streams."""
    if streamType == LIVE_TYPE:
        url = get_live_categories_URL()
    elif streamType == VOD_TYPE:
        url = get_vod_cat_URL()
    elif streamType == SERIES_TYPE:
        url = get_series_cat_URL()
    else:
        return None

    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()
        cache_handler.set('categories', f"{USERNAME}_{streamType}", response.json())

        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Xtream API Category Fetch Error for {streamType}: {e}")
        return None


def streams_by_category(streamType, category_id):
    """Fetches streams within a specific category."""
    if streamType == LIVE_TYPE:
        url = get_live_streams_URL_by_category(category_id)
    elif streamType == VOD_TYPE:
        url = get_vod_streams_URL_by_category(category_id)
    elif streamType == SERIES_TYPE:
        url = get_series_URL_by_category(category_id)
    else:
        return None

    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()

        cache_handler.set(streamType, f"{USERNAME}_{streamType}_{category_id}", response.json())

        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Xtream API Stream Fetch Error for {streamType}: {e}")
        return None


def series_info_by_id(series_id):
    """Fetches detailed information, including episodes, for a specific TV series ID."""
    url = get_series_info_URL_by_ID(series_id)
    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()

        cache_handler.set('series_info', f"{USERNAME}_{series_id}", response.json())

        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Xtream API Series Info Fetch Error for ID {series_id}: {e}")
        return None

def epg_short_by_stream(stream_id):
    """
    Fetches short EPG data (currently airing + next few programs) for a specific Live stream ID.
    This uses the 'get_short_epg' action.
    """
    url = get_live_epg_URL_by_stream(stream_id)
    return _fetch_url(url, f"Short EPG Fetch for stream {stream_id}")

def get_decoded_epg_short_by_stream(stream_id):
    """
    Fetches short EPG data and DECODES the Base64 title/description fields.
    Returns a list of decoded EPG listings (dict), or an empty list on failure.
    """
    raw_data = epg_short_by_stream(stream_id)
    
    if not raw_data or 'epg_listings' not in raw_data:
        return []
        
    decoded_listings = []
    
    for listing in raw_data['epg_listings']:
        # Create a mutable copy
        decoded_listing = listing.copy()
        
        # Decode the fields in the copy
        if 'title' in decoded_listing:
            decoded_listing['title'] = _decode_base64_epg_field(decoded_listing['title'])
            
        if 'description' in decoded_listing:
            decoded_listing['description'] = _decode_base64_epg_field(decoded_listing['description'])
        
        if 'start_timestamp' in decoded_listing:
            # Add a new key for the Python datetime object
            decoded_listing['start_time_dt'] = _timestamp_to_datetime(decoded_listing['start_timestamp'])

        if 'stop_timestamp' in decoded_listing:
            # Add a new key for the Python datetime object
            decoded_listing['stop_time_dt'] = _timestamp_to_datetime(decoded_listing['stop_timestamp'])
            
        decoded_listings.append(decoded_listing)
        
    cache_handler.set('epg_data', f"{USERNAME}_{stream_id}" , raw_data)

    return decoded_listings

# --- Stream URL Builder ---

def build_stream_url(stream_id, stream_type, container_extension="ts"):
    """
    Builds the final playable URL for a stream based on the Xtream Codes format.
    Example: http://server/live/username/password/streamID.ts
    """
    api_path_map = {
        'live': 'live',
        'vod': 'movie',   # VOD uses 'movie' in the direct stream URL
        'series': 'series'
    }
    api_path = api_path_map.get(stream_type.lower())

    if not api_path:
        return None

    full_url = '{}/{}/{}/{}/{}.{}'.format(
        SERVER.rstrip('/'),
        api_path,
        USERNAME,
        PASSWORD,
        stream_id,
        container_extension
    )
    return full_url


# --- URL-builder methods (using /player_api.php) ---

def get_authenticate_URL():
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}"


def get_live_categories_URL():
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_live_categories"


def get_live_streams_URL_by_category(category_id):
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_live_streams&category_id={category_id}"


def get_vod_cat_URL():
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_vod_categories"


def get_vod_streams_URL_by_category(category_id):
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_vod_streams&category_id={category_id}"


def get_series_cat_URL():
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_series_categories"


def get_series_URL_by_category(category_id):
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_series&category_id={category_id}"


def get_series_info_URL_by_ID(series_id):
    """URL for fetching detailed series information."""
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_series_info&series_id={series_id}"


def get_live_epg_URL_by_stream(stream_id):
    return f"{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_short_epg&stream_id={stream_id}"

def get_live_streams():
    """
    Fetches the list of live streams from the Xtream API.
    Handles network errors and API authentication errors.
    """
    # Note: Use f-string for clarity, but keep the URL structure
    URL = f'{SERVER}/player_api.php?username={USERNAME}&password={PASSWORD}&action=get_live_streams'
    
    # Log the URL (redacting credentials for security, if possible, but logging structure)
    redacted_url = f'{SERVER}/player_api.php?username=XXX&password=XXX&action=get_live_streams'
    xbmc.log(f"Xtream API: Attempting to fetch live streams from {redacted_url}", xbmc.LOGDEBUG)

    try:
        response = requests.get(url=URL, headers=HEADERS, timeout=15)
        response.raise_for_status() # Raises HTTPError for bad status codes (4xx or 5xx)

        data = response.json()

        # --- Xtream API Error Check (Crucial step) ---
        # Xtream APIs often return JSON with error details instead of streams if auth fails.
        if isinstance(data, dict) and data.get('user_info', {}).get('auth') == 0:
            error_message = data.get('user_info', {}).get('message', 'Authentication failed.')
            xbmc.log(f"Xtream API Authentication Failed: {error_message}", xbmc.LOGERROR)
            return [] # Return empty list on known auth failure

        # Some Xtream errors return a 'message' key at the top level on failure
        if isinstance(data, dict) and 'message' in data:
            xbmc.log(f"Xtream API Response Error: {data['message']}", xbmc.LOGERROR)
            return []

        # Assuming successful response is a list of streams
        if isinstance(data, list):
            original_count = len(data)

            xbmc.log(f"Xtream API: Successfully fetched {len(data)} live streams.", xbmc.LOGINFO)
            # CRITICAL FILTER: Keep streams where 'epg_channel_id' is present and has a value
            filtered_streams = [
                stream for stream in data
                if stream.get('epg_channel_id')
            ]
            filtered_count = len(filtered_streams)
            skipped_count = original_count - filtered_count
            
            xbmc.log(f"Xtream API: Successfully fetched {original_count} live streams. Filtered out {skipped_count} streams without epg_channel_id.", xbmc.LOGINFO)
            return filtered_streams
        else:
            # Handle unexpected successful response (e.g., API structure changed)
            xbmc.log(f"Xtream API: Unexpected successful response format (not a list). Data starts with: {str(data)[:100]}", xbmc.LOGERROR)
            return []

    except requests.exceptions.RequestException as e:
        # This catches all network errors (timeouts, connection issues, DNS)
        xbmc.log(f"Xtream API Network Error for {SERVER}: {e}", xbmc.LOGERROR)
        return None # Returning None leads to the "No streams found" message in service.py

    except json.JSONDecodeError as e:
        # This catches errors if the response body isn't valid JSON
        xbmc.log(f"Xtream API JSON Decode Error for {SERVER}: {e}. Response text: {response.text[:200]}", xbmc.LOGERROR)
        return None

    except Exception as e:
        # Catch any other unexpected error during processing
        xbmc.log(f"Xtream API Unexpected Error: {e}", xbmc.LOGERROR)
        return None

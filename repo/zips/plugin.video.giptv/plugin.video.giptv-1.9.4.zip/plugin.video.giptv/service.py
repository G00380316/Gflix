# -*- coding: utf-8 -*-
import os
import time
import base64

import xbmc
import xbmcaddon
import xbmcvfs

from datetime import datetime, timezone

from resources.apis.index_builder import build_index
import resources.apis.xtream_api as xtream_api
from resources.utils.fetchCache import cache_handler
import resources.utils.settings as settings
import resources.lib.navigator as navigator
from resources.utils.background_writer import shutdown_writer

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# ============================================================
#  SMALL HELPERS
# ============================================================
def xml_escape(text):
    if not text:
        return ""
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def get_profile_path(subpath=""):
    """
    Helper: return a path under this addon's profile directory.
    Uses special://profile so it respects portable / profiles.
    """
    base = "special://profile/addon_data/{}/".format(ADDON_ID)
    if subpath:
        base = base + subpath.lstrip("/")

    return xbmcvfs.translatePath(base)


def get_pvr_instance_settings_path():
    """
    Location of IPTV Simple instance-settings-1.xml.
    """
    return xbmcvfs.translatePath(
        "special://userdata/addon_data/pvr.iptvsimple/instance-settings-1.xml"
    )


def pvr_profile_m3u_special():
    """
    The *Kodi special:// path* that IPTV Simple should use for the playlist.
    This is what we will inject into instance-settings-1.xml.
    """
    return "special://profile/addon_data/{}/iptv/playlist.m3u".format(ADDON_ID)


def pvr_profile_epg_special():
    """
    The *Kodi special:// path* that IPTV Simple should use for the XMLTV file.
    (User-chosen filename: guide.xmltv)
    """
    return "special://profile/addon_data/{}/iptv/guide.xmltv".format(ADDON_ID)


def _decode_base64_epg_field(encoded_string):
    """
    Decodes a Base64 string to a UTF-8 string. Returns original if decoding fails.
    """
    if not encoded_string:
        return ""
    try:
        return base64.b64decode(encoded_string).decode("utf-8")
    except Exception:
        # Fallback to the original string if it wasn't valid Base64
        return encoded_string


def _timestamp_to_datetime(timestamp_str):
    """
    Converts a Unix timestamp string (like '1678886400') into a Python datetime object.
    Returns None if conversion fails. Assumes timestamps are in UTC.
    """
    if not timestamp_str:
        return None
    try:
        return datetime.fromtimestamp(int(timestamp_str), tz=timezone.utc)
    except Exception:
        return None


# ============================================================
#  SETTINGS MONITOR
# ============================================================
class SettingsMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.rebuild_now = False
        self.rebuild_iptv_files = False

    def onSettingsChanged(self):
        """
        Triggered when addon settings change.
        We:
          - refresh containers
          - request index rebuild
          - request IPTV playlist/xml rebuild
        """
        xbmc.sleep(300)
        xbmc.executebuiltin("Container.Refresh")
        self.rebuild_now = True
        self.rebuild_iptv_files = True


# ============================================================
#  INDEX HELPERS
# ============================================================
def get_index_dir():
    return get_profile_path("index")


def index_is_missing_or_empty():
    index_dir = get_index_dir()
    if not navigator.setup_api_config():
        return

    if not xbmcvfs.exists(index_dir):
        return True

    required_files = [
        f"{xtream_api.USERNAME}_vod_index.json",
        f"{xtream_api.USERNAME}_series_index.json",
        f"{xtream_api.USERNAME}_live_index.json",
    ]

    for filename in required_files:
        path = os.path.join(index_dir, filename)
        if not xbmcvfs.exists(path):
            return True
        stat = xbmcvfs.Stat(path)
        if stat.st_size() < 16:
            return True

    return False


def auto_rebuild_index(monitor):
    """
    Rebuild index only if enabled + needed.
    Passes monitor down so build_index() can abort cleanly.
    """
    if not settings.get_auto_index_on_off(ADDON):
        xbmc.log(f"[{ADDON_ID}] Auto index rebuild disabled.", xbmc.LOGINFO)
        return

    if index_is_missing_or_empty():
        xbmc.log("[giptv] Index missing, rebuilding...", xbmc.LOGINFO)
        build_index(monitor)


# ============================================================
#  IPTV LOCAL DIR + REBUILD SCHEDULING
# ============================================================
def ensure_iptv_dir():
    """
    Make sure addon_data/.../iptv directory exists.
    """
    iptv_dir = get_profile_path("iptv")
    if not xbmcvfs.exists(iptv_dir):
        try:
            xbmcvfs.mkdirs(iptv_dir)
            xbmc.log(f"[giptv] Created IPTV dir: {iptv_dir}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(
                f"[giptv] Failed to create IPTV dir {iptv_dir}: {e}", xbmc.LOGERROR
            )
    return iptv_dir


def playlist_needs_rebuild(iptv_dir, max_age_days=30):
    """
    Check if playlist.m3u needs rebuilding:
      - if file missing -> True
      - if timestamp missing -> True
      - if older than max_age_days -> True
    """
    playlist_path = os.path.join(iptv_dir, "playlist.m3u")
    ts_path = os.path.join(iptv_dir, "playlist.timestamp")

    if not xbmcvfs.exists(playlist_path):
        return True

    if not xbmcvfs.exists(ts_path):
        return True

    try:
        f = xbmcvfs.File(ts_path, "r")
        data = f.read()
        f.close()
        last_ts = float(data.strip() or "0")
    except Exception:
        return True

    age_days = (time.time() - last_ts) / 86400.0
    return age_days >= max_age_days


def update_playlist_timestamp(iptv_dir):
    """
    Update timestamp file for playlist rebuild scheduling.
    """
    ts_path = os.path.join(iptv_dir, "playlist.timestamp")
    try:
        f = xbmcvfs.File(ts_path, "w")
        f.write(str(time.time()))
        f.close()
    except Exception as e:
        xbmc.log(f"[giptv] Failed to update playlist timestamp: {e}", xbmc.LOGERROR)


# ============================================================
#  LOCAL M3U BUILDER
# ============================================================
def build_local_m3u(iptv_dir):
    """
    Build a full M3U playlist from Xtream API and save to:
      <profile>/addon_data/plugin.video.giptv/iptv/playlist.m3u
    """
    if not navigator.setup_api_config():
        xbmc.log("[giptv] API not configured, skipping M3U build.", xbmc.LOGERROR)
        return None

    playlist_path = os.path.join(iptv_dir, "playlist.m3u")

    try:
        lines = ["#EXTM3U"]
        live_cats = xtream_api.categories("live") or []

        for cat in live_cats:
            cat_id = cat.get("category_id")
            group = cat.get("category_name", "")
            streams = xtream_api.streams_by_category("live", cat_id) or []

            for s in streams:
                stream_id = s.get("stream_id")
                if not stream_id:
                    continue

                name = (
                    s.get("name")
                    or s.get("stream_display_name")
                    or "Channel {}".format(stream_id)
                )
                tvg_name = name
                logo = s.get("stream_icon") or s.get("tv_logo") or ""
                ext = s.get("container_extension", "ts")

                # Use real Xtream URL for playback
                stream_url = xtream_api.build_stream_url(stream_id, "live", ext)

                meta = (
                    '#EXTINF:-1 tvg-id="" tvg-name="{tvg}" group-title="{grp}"'.format(
                        tvg=xml_escape(tvg_name),
                        grp=xml_escape(group),
                    )
                )
                if logo:
                    meta += ' tvg-logo="{}"'.format(xml_escape(logo))
                meta += ",{}".format(name)

                lines.append(meta)
                lines.append(stream_url)

        data = "\n".join(lines) + "\n"

        f = xbmcvfs.File(playlist_path, "w")
        f.write(data)
        f.close()

        update_playlist_timestamp(iptv_dir)

        xbmc.log(f"[giptv] Wrote M3U playlist: {playlist_path}", xbmc.LOGINFO)
        return playlist_path

    except Exception as e:
        xbmc.log(f"[giptv] Error building M3U playlist: {e}", xbmc.LOGERROR)
        return None


# ============================================================
#  LOCAL XMLTV BUILDER (DECODED FROM CACHE)
# ============================================================
def build_local_xmltv_from_cache(iptv_dir):
    """
    Build an XMLTV file using ONLY cached EPG data
    (cache_handler.get('epg_data', f'{USERNAME}_{stream_id}')),
    decoding Base64 title/description, and save to:
      <profile>/addon_data/plugin.video.giptv/iptv/guide.xmltv

    If no usable cache exists, writes a minimal empty XMLTV root so
    IPTV Simple won't choke on missing EPG file.
    """
    if not navigator.setup_api_config():
        xbmc.log("[giptv] API not configured, skipping XMLTV build.", xbmc.LOGERROR)
        return None

    xml_path = os.path.join(iptv_dir, "guide.xmltv")
    channel_xml = []
    programme_xml = []
    seen_channels = set()

    try:
        live_cats = xtream_api.categories("live") or []
        for cat in live_cats:
            cat_id = cat.get("category_id")
            streams = xtream_api.streams_by_category("live", cat_id) or []

            for s in streams:
                stream_id = s.get("stream_id")
                if not stream_id:
                    continue

                channel_id = str(stream_id)
                name = (
                    s.get("name")
                    or s.get("stream_display_name")
                    or f"Channel {channel_id}"
                )
                logo = s.get("stream_icon") or s.get("tv_logo") or ""

                # Channel block (only once per stream_id)
                if channel_id not in seen_channels:
                    seen_channels.add(channel_id)
                    ch = (
                        f'<channel id="{xml_escape(channel_id)}">'
                        f"<display-name>{xml_escape(name)}</display-name>"
                    )
                    if logo:
                        ch += f'<icon src="{xml_escape(logo)}" />'
                    ch += "</channel>"
                    channel_xml.append(ch)

                # EPG data from cache
                cache_key = f"{xtream_api.USERNAME}_{stream_id}"
                epg_pack = cache_handler.get("epg_data", cache_key)

                if not epg_pack or not isinstance(epg_pack.get("epg_listings"), list):
                    continue

                decoded_epg_data = []
                for listing in epg_pack["epg_listings"]:
                    # Create a mutable copy
                    decoded_listing = dict(listing)

                    # Decode fields
                    if "title" in decoded_listing:
                        decoded_listing["title"] = _decode_base64_epg_field(
                            decoded_listing["title"]
                        )

                    if "description" in decoded_listing:
                        decoded_listing["description"] = _decode_base64_epg_field(
                            decoded_listing["description"]
                        )

                    # Optional datetime objects (not strictly needed for XMLTV)
                    if "start_timestamp" in decoded_listing:
                        decoded_listing["start_time_dt"] = _timestamp_to_datetime(
                            decoded_listing["start_timestamp"]
                        )

                    if "stop_timestamp" in decoded_listing:
                        decoded_listing["stop_time_dt"] = _timestamp_to_datetime(
                            decoded_listing["stop_timestamp"]
                        )

                    decoded_epg_data.append(decoded_listing)

                # Emit XMLTV <programme> entries
                for entry in decoded_epg_data:
                    try:
                        title = xml_escape(entry.get("title", name))
                        desc = xml_escape(
                            entry.get("description") or f"Programme on {name}"
                        )
                        start_ts = int(entry.get("start_timestamp") or 0)
                        stop_ts = int(entry.get("stop_timestamp") or 0)
                        if not start_ts or not stop_ts:
                            continue

                        start_dt = datetime.fromtimestamp(start_ts, tz=timezone.utc)
                        stop_dt = datetime.fromtimestamp(stop_ts, tz=timezone.utc)

                        start_str = start_dt.strftime("%Y%m%d%H%M%S +0000")
                        stop_str = stop_dt.strftime("%Y%m%d%H%M%S +0000")

                        prog = (
                            f'<programme start="{start_str}" stop="{stop_str}" '
                            f'channel="{xml_escape(channel_id)}">'
                            f'<title lang="en">{title}</title>'
                            f'<desc lang="en">{desc}</desc>'
                            f"</programme>"
                        )
                        programme_xml.append(prog)
                    except Exception:
                        continue

        # Build final XMLTV doc
        xml_parts = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<tv generator-info-name="giptv">',
        ]
        xml_parts.extend(channel_xml)
        xml_parts.extend(programme_xml)
        xml_parts.append("</tv>")

        data = "\n".join(xml_parts) + "\n"

        f = xbmcvfs.File(xml_path, "w")
        f.write(data)
        f.close()

        xbmc.log(
            f"[giptv] Wrote XMLTV guide.xmltv with {len(channel_xml)} channels and {len(programme_xml)} programmes: {xml_path}",
            xbmc.LOGINFO,
        )
        return xml_path

    except Exception as e:
        xbmc.log(f"[giptv] Error building XMLTV file: {e}", xbmc.LOGERROR)

        # Fallback: minimal stub so PVR doesn't choke
        try:
            data = '<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="giptv"/>\n'
            f = xbmcvfs.File(xml_path, "w")
            f.write(data)
            f.close()
            xbmc.log(f"[giptv] Wrote minimal XMLTV stub: {xml_path}", xbmc.LOGINFO)
            return xml_path
        except Exception as e2:
            xbmc.log(f"[giptv] Failed to write minimal XMLTV stub: {e2}", xbmc.LOGERROR)
            return None


# ============================================================
#  IPTV SIMPLE INSTANCE SETTINGS FILE
# ============================================================
PVR_INSTANCE_TEMPLATE = """<settings version=\\"2\\">
    <setting id=\\"kodi_addon_instance_name\\">Migrated Add-on Config</setting>
    <setting id=\\"kodi_addon_instance_enabled\\" default=\\"true\\">true</setting>
    <setting id=\\"m3uPathType\\">{M3U_PATH_TYPE}</setting>
    <setting id=\\"m3uPath\\">{M3U_PATH}</setting>
    <setting id=\\"m3uUrl\\" default=\\"true\\" />
    <setting id=\\"m3uCache\\" default=\\"true\\">true</setting>
    <setting id=\\"startNum\\" default=\\"true\\">1</setting>
    <setting id=\\"numberByOrder\\" default=\\"true\\">false</setting>
    <setting id=\\"m3uRefreshMode\\" default=\\"true\\">0</setting>
    <setting id=\\"m3uRefreshIntervalMins\\" default=\\"true\\">60</setting>
    <setting id=\\"m3uRefreshHour\\" default=\\"true\\">4</setting>
    <setting id=\\"connectioncheckinterval\\" default=\\"true\\">10</setting>
    <setting id=\\"connectionchecktimeout\\" default=\\"true\\">20</setting>
    <setting id=\\"defaultProviderName\\" default=\\"true\\" />
    <setting id=\\"enableProviderMappings\\" default=\\"true\\">false</setting>
    <setting id=\\"providerMappingFile\\" default=\\"true\\">special://userdata/addon_data/pvr.iptvsimple/providers/providerMappings.xml</setting>
    <setting id=\\"tvGroupMode\\" default=\\"true\\">0</setting>
    <setting id=\\"numTvGroups\\" default=\\"true\\">1</setting>
    <setting id=\\"oneTvGroup\\" default=\\"true\\" />
    <setting id=\\"twoTvGroup\\" default=\\"true\\" />
    <setting id=\\"threeTvGroup\\" default=\\"true\\" />
    <setting id=\\"fourTvGroup\\" default=\\"true\\" />
    <setting id=\\"fiveTvGroup\\" default=\\"true\\" />
    <setting id=\\"customTvGroupsFile\\" default=\\"true\\">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customTVGroups-example.xml</setting>
    <setting id=\\"tvChannelGroupsOnly\\" default=\\"true\\">false</setting>
    <setting id=\\"radioGroupMode\\" default=\\"true\\">0</setting>
    <setting id=\\"numRadioGroups\\" default=\\"true\\">1</setting>
    <setting id=\\"oneRadioGroup\\" default=\\"true\\" />
    <setting id=\\"twoRadioGroup\\" default=\\"true\\" />
    <setting id=\\"threeRadioGroup\\" default=\\"true\\" />
    <setting id=\\"fourRadioGroup\\" default=\\"true\\" />
    <setting id=\\"fiveRadioGroup\\" default=\\"true\\" />
    <setting id=\\"customRadioGroupsFile\\" default=\\"true\\">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customRadioGroups-example.xml</setting>
    <setting id=\\"radioChannelGroupsOnly\\" default=\\"true\\">false</setting>
    <setting id=\\"epgPathType\\" default=\\"true\\">{EPG_PATH_TYPE}</setting>
    <setting id=\\"epgPath\\" default=\\"true\\">{EPG_PATH}</setting>
    <setting id=\\"epgUrl\\" default=\\"true\\" />
    <setting id=\\"epgCache\\" default=\\"true\\">true</setting>
    <setting id=\\"epgTimeShift\\" default=\\"true\\">0</setting>
    <setting id=\\"epgTSOverride\\" default=\\"true\\">false</setting>
    <setting id=\\"epgIgnoreCaseForChannelIds\\" default=\\"true\\">true</setting>
    <setting id=\\"useEpgGenreText\\" default=\\"true\\">false</setting>
    <setting id=\\"genresPathType\\" default=\\"true\\">0</setting>
    <setting id=\\"genresPath\\" default=\\"true\\">special://userdata/addon_data/pvr.iptvsimple/genres/genreTextMappings/genres.xml</setting>
    <setting id=\\"genresUrl\\" default=\\"true\\" />
    <setting id=\\"logoPathType\\" default=\\"true\\">1</setting>
    <setting id=\\"logoPath\\" default=\\"true\\" />
    <setting id=\\"logoBaseUrl\\" default=\\"true\\" />
    <setting id=\\"useLogosLocalPathOnly\\" default=\\"true\\">false</setting>
    <setting id=\\"logoFromEpg\\" default=\\"true\\">1</setting>
    <setting id=\\"mediaEnabled\\" default=\\"true\\">true</setting>
    <setting id=\\"mediaGroupByTitle\\" default=\\"true\\">true</setting>
    <setting id=\\"mediaGroupBySeason\\" default=\\"true\\">true</setting>
    <setting id=\\"mediaTitleSeasonEpisode\\" default=\\"true\\">false</setting>
    <setting id=\\"mediaM3UGroupPath\\" default=\\"true\\">2</setting>
    <setting id=\\"mediaForcePlaylist\\" default=\\"true\\">false</setting>
    <setting id=\\"mediaVODAsRecordings\\" default=\\"true\\">true</setting>
    <setting id=\\"timeshiftEnabled\\" default=\\"true\\">false</setting>
    <setting id=\\"timeshiftEnabledAll\\" default=\\"true\\">true</setting>
    <setting id=\\"timeshiftEnabledHttp\\" default=\\"true\\">true</setting>
    <setting id=\\"timeshiftEnabledUdp\\" default=\\"true\\">true</setting>
    <setting id=\\"timeshiftEnabledCustom\\" default=\\"true\\">false</setting>
    <setting id=\\"catchupEnabled\\" default=\\"true\\">false</setting>
    <setting id=\\"catchupQueryFormat\\" default=\\"true\\" />
    <setting id=\\"catchupDays\\" default=\\"true\\">5</setting>
    <setting id=\\"allChannelsCatchupMode\\" default=\\"true\\">0</setting>
    <setting id=\\"catchupOverrideMode\\" default=\\"true\\">0</setting>
    <setting id=\\"catchupCorrection\\" default=\\"true\\">0</setting>
    <setting id=\\"catchupPlayEpgAsLive\\" default=\\"true\\">false</setting>
    <setting id=\\"catchupWatchEpgBeginBufferMins\\" default=\\"true\\">5</setting>
    <setting id=\\"catchupWatchEpgEndBufferMins\\" default=\\"true\\">15</setting>
    <setting id=\\"catchupOnlyOnFinishedProgrammes\\" default=\\"true\\">false</setting>
    <setting id=\\"transformMulticastStreamUrls\\" default=\\"true\\">false</setting>
    <setting id=\\"udpxyHost\\" default=\\"true\\">127.0.0.1</setting>
    <setting id=\\"udpxyPort\\" default=\\"true\\">4022</setting>
    <setting id=\\"useFFmpegReconnect\\" default=\\"true\\">true</setting>
    <setting id=\\"useInputstreamAdaptiveforHls\\" default=\\"true\\">false</setting>
    <setting id=\\"defaultUserAgent\\" default=\\"true\\" />
    <setting id=\\"defaultInputstream\\" default=\\"true\\" />
    <setting id=\\"defaultMimeType\\" default=\\"true\\" />
    <setting id=\\"providerName\\" default=\\"true\\">GIPTV</setting>
</settings>
"""


def write_pvr_instance_settings(m3u_special, epg_special):
    """
    Write pvr.iptvsimple/instance-settings-1.xml using a known-good template,
    only swapping in our local M3U + XMLTV paths and the correct path types.
    """
    path = get_pvr_instance_settings_path()
    try:
        xml_text = PVR_INSTANCE_TEMPLATE.format(
            M3U_PATH_TYPE="0",  # 0 = local file
            M3U_PATH=m3u_special,
            EPG_PATH_TYPE="0",  # 0 = local file
            EPG_PATH=epg_special,
        )

        # Template uses escaped quotes (\") so unescape before writing
        xml_text = xml_text.replace('\\"', '"')

        f = xbmcvfs.File(path, "w")
        f.write(xml_text)
        f.close()

        xbmc.log(f"[giptv] Wrote IPTV Simple instance config: {path}", xbmc.LOGINFO)
        xbmc.executebuiltin("RestartPVRManager")
        xbmc.log(
            "[giptv] Requested RestartPVRManager after updating IPTV Simple config",
            xbmc.LOGINFO,
        )
    except Exception as e:
        xbmc.log(
            f"[giptv] Failed to write IPTV Simple instance settings ({path}): {e}",
            xbmc.LOGERROR,
        )


def rebuild_iptv_files_and_pvr_config(force_playlist=False):
    """
    Full refresh:
      - ensure iptv dir exists
      - build local M3U (always if force_playlist=True, else monthly)
      - build local XMLTV (from cache, always)
      - write IPTV Simple instance-settings-1.xml pointing to those files
    Called on Kodi startup and whenever addon settings change.
    """
    if not navigator.setup_api_config():
        xbmc.log(
            "[giptv] No API connection — skipping IPTV file rebuild.", xbmc.LOGERROR
        )
        return

    iptv_dir = ensure_iptv_dir()

    # Playlist: only rebuild if missing/old, unless forced
    m3u_fs_path = None
    if force_playlist or playlist_needs_rebuild(iptv_dir):
        m3u_fs_path = build_local_m3u(iptv_dir)
    else:
        m3u_fs_path = os.path.join(iptv_dir, "playlist.m3u")
        if not xbmcvfs.exists(m3u_fs_path):
            m3u_fs_path = build_local_m3u(iptv_dir)

    # XMLTV: always rebuild from cache when called
    epg_fs_path = build_local_xmltv_from_cache(iptv_dir)

    if not m3u_fs_path:
        xbmc.log("[giptv] M3U build failed, not updating PVR config.", xbmc.LOGERROR)
        return

    m3u_special = pvr_profile_m3u_special()
    epg_special = pvr_profile_epg_special() if epg_fs_path else ""

    write_pvr_instance_settings(m3u_special, epg_special)


# ============================================================
#  EPG BACKGROUND REFRESH
# ============================================================
def build_epg_cache_gradually(monitor):
    """
    Builds the EPG cache for ALL live streams gradually.
    Runs in background without freezing UI and respects shutdown.
    After finishing, rebuilds XMLTV from cache so epg stays in sync.
    """
    if monitor.abortRequested():
        return

    if not navigator.setup_api_config():
        return

    if not settings.get_auto_epg_on_off(ADDON):
        xbmc.log("[giptv] EPG background refresh disabled.", xbmc.LOGINFO)
        return

    xbmc.log("[giptv] Starting gradual EPG cache builder...", xbmc.LOGINFO)

    try:
        categories = xtream_api.categories("live") or []
        if not categories:
            xbmc.log("[giptv] No live categories found!", xbmc.LOGWARNING)
            return

        for cat in categories:
            if monitor.abortRequested():
                xbmc.log("[giptv] EPG builder aborted (category loop).", xbmc.LOGINFO)
                return

            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name")
            xbmc.log(
                f"[giptv] Fetching EPG streams for category {cat_name} ({cat_id})",
                xbmc.LOGINFO,
            )

            stream_list = xtream_api.streams_by_category("live", cat_id) or []
            if not stream_list:
                continue

            for stream in stream_list:
                if monitor.abortRequested():
                    xbmc.log("[giptv] EPG builder aborted (stream loop).", xbmc.LOGINFO)
                    return

                stream_id = stream.get("stream_id")
                if not stream_id:
                    continue

                cache_key = f"{xtream_api.USERNAME}_{stream_id}"

                if cache_handler.get("epg_data", cache_key):
                    continue

                xbmc.log(f"[giptv] Fetching EPG for stream {stream_id}", xbmc.LOGDEBUG)

                epg = xtream_api.get_decoded_epg_short_by_stream(stream_id)
                if epg:
                    cache_handler.set("epg_data", cache_key, {"epg_listings": epg})

                if monitor.waitForAbort(0.05):
                    xbmc.log(
                        "[giptv] EPG builder aborted by system shutdown",
                        xbmc.LOGINFO,
                    )
                    return

    except Exception as e:
        xbmc.log(f"[giptv] EPG Cache Builder Error: {e}", xbmc.LOGERROR)
        return

    xbmc.log("[giptv] Finished building EPG cache.", xbmc.LOGINFO)

    # After EPG cache is fully built, immediately rebuild XMLTV from cache
    try:
        iptv_dir = ensure_iptv_dir()
        build_local_xmltv_from_cache(iptv_dir)
    except Exception as e:
        xbmc.log(f"[giptv] Error rebuilding XMLTV after EPG build: {e}", xbmc.LOGERROR)


# ============================================================
#  MAIN SERVICE LOOP
# ============================================================
if __name__ == "__main__":
    monitor = SettingsMonitor()

    # Wait for Kodi to fully initialize (5 seconds)
    if monitor.waitForAbort(5):
        shutdown_writer()
        raise SystemExit

    if navigator.setup_api_config():
        # Initial index build
        auto_rebuild_index(monitor)
        # On every Kodi startup:
        #  - ensure PVR instance file exists
        #  - ensure playlist (rebuild if older than 30 days)
        #  - ensure XMLTV exists (stub at first, real after EPG build)
        rebuild_iptv_files_and_pvr_config(force_playlist=False)
    else:
        xbmc.log("[giptv] No API connection — aborting service start.", xbmc.LOGERROR)

    # Next time to run EPG builder
    next_epg_build = time.time() + 5  # start 5 seconds after boot

    while not monitor.abortRequested():
        # Settings changed: rebuild index
        if monitor.rebuild_now:
            monitor.rebuild_now = False
            if navigator.setup_api_config():
                xbmc.log(
                    f"[giptv] Rebuilding index for: {xtream_api.USERNAME}",
                    xbmc.LOGINFO,
                )
                auto_rebuild_index(monitor)

        # Settings changed: rebuild IPTV local files + PVR config
        if monitor.rebuild_iptv_files:
            monitor.rebuild_iptv_files = False
            rebuild_iptv_files_and_pvr_config(force_playlist=False)

        # Time to run EPG builder?
        if time.time() >= next_epg_build:
            build_epg_cache_gradually(monitor)
            next_epg_build = time.time() + (60 * 30)  # 30 minutes

        # 0.5 second tick, but abort-aware
        if monitor.waitForAbort(0.5):
            break

    # Clean shutdown
    shutdown_writer()

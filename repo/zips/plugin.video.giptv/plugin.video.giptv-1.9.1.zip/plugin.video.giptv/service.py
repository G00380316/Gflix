import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import time

from resources.apis.index_builder import build_index
import resources.apis.xtream_api as xtream_api
from resources.utils.fetchCache import cache_handler
import resources.utils.settings as settings
import resources.lib.navigator as navigator
from resources.utils.background_writer import shutdown_writer
import resources.utils.control as control

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# ============================================================
#  player viewmode monitor
# ============================================================
class GIPTVPlayer(xbmc.Player):
    def onAVStarted(self):
        xbmc.log("[giptv] AV started – waiting for video readiness...", xbmc.LOGINFO)

        # Wait for actual video start (up to 3s)
        for i in range(30):
            if self.isPlayingVideo():
                width = self.getVideoInfoTag().getWidth()
                height = self.getVideoInfoTag().getHeight()

                if width > 0 and height > 0:
                    xbmc.log(f"[giptv] Video ready ({width}x{height})", xbmc.LOGINFO)
                    break

            xbmc.sleep(100)

        win = xbmcgui.Window(10000)
        stream_type = win.getProperty("giptv.last_stream_type")

        if not stream_type:
            xbmc.log("[giptv] No stream_type property found!", xbmc.LOGINFO)
            return

        # Choose view mode
        if stream_type == "live":
            mode = 3  # Stretch 16:9
        else:
            mode = 1  # Zoom

        xbmc.sleep(200)  # small final delay before applying

        xbmc.executebuiltin(f"PlayerControl(SetViewMode({mode}))")
        xbmc.log(f"[giptv] Applied ViewMode {mode} for {stream_type}", xbmc.LOGINFO)

# ============================================================
#  SETTINGS MONITOR
# ============================================================
class SettingsMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.rebuild_now = False

    def onSettingsChanged(self):
        xbmc.sleep(300)
        xbmc.executebuiltin("Container.Refresh")
        self.rebuild_now = True


# ============================================================
#  INDEX HELPERS
# ============================================================
def get_index_dir():
    return xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/index")


def index_is_missing_or_empty():
    index_dir = get_index_dir()
    if not navigator.setup_api_config():
        return

    if not xbmcvfs.exists(index_dir):
        return True

    # account-specific index files
    required_files = [
        f"{xtream_api.USERNAME}_vod_index.json",
        f"{xtream_api.USERNAME}_series_index.json",
        f"{xtream_api.USERNAME}_live_index.json",
    ]

    for filename in required_files:
        path = os.path.join(index_dir, filename)
        if not xbmcvfs.exists(path):
            return True
        stat = xbmcvfs.Stat(path)
        # If file exists but empty
        if stat.st_size() < 16:
            return True

    return False


# ============================================================
#  AUTO INDEX REBUILD
# ============================================================
def auto_rebuild_index(monitor):
    """
    Rebuild index only if enabled + needed.
    Passes monitor down so build_index() can abort cleanly.
    """
    if not settings.get_auto_index_on_off(ADDON):
        xbmc.log(f"[{ADDON_ID}] Auto index rebuild disabled.", xbmc.LOGINFO)
        return

    if index_is_missing_or_empty():
        xbmc.log("[giptv] Index missing, rebuilding...", xbmc.LOGINFO)
        # build_index is expected to accept `monitor` and check monitor.abortRequested()
        build_index(monitor)


# ============================================================
#  EPG BACKGROUND REFRESH
# ============================================================
def build_epg_cache_gradually(monitor):
    """
    Builds the EPG cache for ALL live streams gradually.
    Runs in background without freezing UI and respects shutdown.
    """

    # Early abort if Kodi is shutting down
    if monitor.abortRequested():
        return

    if not navigator.setup_api_config():
        return

    if not settings.get_auto_epg_on_off(ADDON):
        xbmc.log("[giptv] EPG background refresh disabled.", xbmc.LOGINFO)
        return

    xbmc.log("[giptv] Starting gradual EPG cache builder...", xbmc.LOGINFO)

    try:
        # 1. Get all Live categories
        categories = xtream_api.categories("live") or []
        if not categories:
            xbmc.log("[giptv] No live categories found!", xbmc.LOGWARNING)
            return

        for cat in categories:
            if monitor.abortRequested():
                xbmc.log("[giptv] EPG builder aborted (category loop).", xbmc.LOGINFO)
                return

            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name")
            xbmc.log(
                f"[giptv] Fetching streams for category {cat_name} ({cat_id})",
                xbmc.LOGINFO,
            )

            # 2. Get all live streams for this category
            stream_list = xtream_api.streams_by_category("live", cat_id) or []
            if not stream_list:
                continue

            for stream in stream_list:
                if monitor.abortRequested():
                    xbmc.log("[giptv] EPG builder aborted (stream loop).", xbmc.LOGINFO)
                    return

                stream_id = stream.get("stream_id")
                if not stream_id:
                    continue

                cache_key = f"{xtream_api.USERNAME}_{stream_id}"

                # Skip if already cached
                if cache_handler.get("epg_data", cache_key):
                    continue

                xbmc.log(f"[giptv] Fetching EPG for stream {stream_id}", xbmc.LOGDEBUG)

                # 3. Fetch & decode EPG
                epg = xtream_api.get_decoded_epg_short_by_stream(stream_id)

                # 4. Save EPG into local addon cache
                if epg:
                    cache_handler.set("epg_data", cache_key, {"epg_listings": epg})

                # --- GRADUAL BUILDER ---
                # Yield to Kodi and allow abort; replaces xbmc.sleep(30)
                if monitor.waitForAbort(0.05):
                    xbmc.log(
                        "[giptv] EPG builder aborted by system shutdown",
                        xbmc.LOGINFO,
                    )
                    return

    except Exception as e:
        xbmc.log(f"[giptv] EPG Cache Builder Error: {str(e)}", xbmc.LOGERROR)

    xbmc.log("[giptv] Finished building EPG cache.", xbmc.LOGINFO)


# ============================================================
#  MAIN SERVICE LOOP
# ============================================================
if __name__ == "__main__":
    # 1) Player monitor (must be created BEFORE everything)
    player = GIPTVPlayer()
    xbmc.log("[giptv] Player viewmode monitor initialized.", xbmc.LOGINFO)

    monitor = SettingsMonitor()

    # Wait for Kodi to fully initialize (5 seconds)
    if monitor.waitForAbort(5):
        shutdown_writer()
        quit()

    if not navigator.setup_api_config():
        xbmc.log("[giptv] No API connection — aborting service start.", xbmc.LOGERROR)
    else:
        # Run index build if needed (passes monitor for abort-awareness)
        auto_rebuild_index(monitor)

    next_epg_build = time.time() + 5  # start 5 seconds after boot

    while not monitor.abortRequested():
        if monitor.rebuild_now:
            monitor.rebuild_now = False
            if navigator.setup_api_config():
                xbmc.log(
                    f"[giptv] Rebuilding index for: {xtream_api.USERNAME}", xbmc.LOGINFO
                )
                auto_rebuild_index(monitor)

        # Time to run EPG builder?
        # if time.time() >= next_epg_build:
        build_epg_cache_gradually(monitor)
        # next_epg_build = time.time() + (60 * 30)  # 30 minutes

        # 0.5 second tick, but abort-aware
        if monitor.waitForAbort(0.5):
            break

    # Clean shutdown for background_writer
    shutdown_writer()

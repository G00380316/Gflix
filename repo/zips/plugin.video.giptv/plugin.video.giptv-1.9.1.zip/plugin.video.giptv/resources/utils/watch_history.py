import xbmcvfs
import json
import os
import time
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

HISTORY_PATH = xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}/watch_history.json"
)


# ------------------------------
# Helpers
# ------------------------------
def _read():
    if not xbmcvfs.exists(HISTORY_PATH):
        return []

    try:
        f = xbmcvfs.File(HISTORY_PATH, "r")
        data = json.loads(f.read())
        f.close()
    except Exception:
        return []

    # --- AUTO CLEAN ON READ ---
    cleaned = _autoclean(data)

    if cleaned != data:
        _write(cleaned)

    return cleaned


def _write(data):
    try:
        f = xbmcvfs.File(HISTORY_PATH, "w")
        f.write(json.dumps(data))
        f.close()
    except Exception:
        pass


# ------------------------------
# PUBLIC API
# ------------------------------
def add_item(
    item_id, title, stream_type, thumb="", fanart="", resume_time=0, play_url=""
):
    """
    Adds or updates a watched item.
    """
    data = _read()

    # Remove duplicates by id
    data = [i for i in data if i.get("id") != item_id]

    payload = {
        "id": item_id,
        "title": title,
        "type": stream_type,  # live / vod / series
        "thumb": thumb,
        "fanart": fanart,
        "resume": resume_time,
        "timestamp": time.time(),
        "play_url": play_url,  # IMPORTANT
        "played_at": int(time.time()),
    }

    data.insert(0, payload)  # Most recent first

    # Limit list length
    if len(data) > 10:
        data = data[:10]

    _write(data)


def load_history():
    return sorted(_read(), key=lambda x: x.get("timestamp", 0), reverse=True)


def clear_history():
    _write([])


def store_watch_event(play_url, title, stream_id=None, thumb="", fanart=""):
    try:
        if stream_id:
            item_id = str(stream_id)
        else:
            item_id = play_url.split("/")[-1].split(".")[0]

        if "/live/" in play_url:
            stream_type = "live"
        elif "/movie/" in play_url:
            stream_type = "vod"
        elif "/series/" in play_url:
            stream_type = "series"
        else:
            stream_type = "unknown"

        add_item(
            item_id=item_id,
            title=title,
            stream_type=stream_type,
            thumb="",
            fanart="",
            play_url=play_url,
            resume_time=0,
        )
    except:  # noqa: E722
        pass


def _autoclean(data):
    """
    Remove entries with missing/invalid play URLs or IDs.
    Does NOT remove valid streams even if the API is down.
    """

    cleaned = []

    for item in data:
        item_id = item.get("id")
        play_url = item.get("play_url")

        # Must have an ID
        if not item_id or item_id == "":
            continue

        # Must have a proper plugin:// or http(s):// URL
        if not play_url or "." not in play_url:
            continue

        # The URL must not be empty or contain malformed paths
        if "None" in play_url or play_url.endswith("/") or play_url.endswith(".."):
            continue

        cleaned.append(item)

    return cleaned

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import time

from resources.apis.index_builder import build_index
import resources.apis.xtream_api as xtream_api
from resources.utils.fetchCache import cache_handler
import resources.utils.settings as settings
import resources.lib.navigator as navigator

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# ============================================================
#  SETTINGS MONITOR
# ============================================================
class SettingsMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        xbmc.sleep(150)
        xbmc.executebuiltin("Container.Refresh")


# ============================================================
#  INDEX HELPERS
# ============================================================
def get_index_dir():
    return xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/index")


def index_is_missing_or_empty():
    index_dir = get_index_dir()
    if not xbmcvfs.exists(index_dir):
        return True

    required_files = ["vod_index.json", "series_index.json", "live_index.json"]

    for filename in required_files:
        path = os.path.join(index_dir, filename)
        if not xbmcvfs.exists(path):
            return True
        stat = xbmcvfs.Stat(path)
        # If file exists but empty
        if stat.st_size() < 16:
            return True

    return False


# ============================================================
#  AUTO INDEX REBUILD
# ============================================================
def auto_rebuild_index():
    """Rebuild index only if enabled + needed."""
    if not settings.get_auto_index_on_off(ADDON):
        xbmc.log(f"[{ADDON_ID}] Auto index rebuild disabled.", xbmc.LOGINFO)
        return

    if index_is_missing_or_empty():
        xbmc.log("[giptv] Index missing, rebuilding...", xbmc.LOGINFO)
        build_index()


# ============================================================
#  EPG BACKGROUND REFRESH
# ============================================================
def build_epg_cache_gradually():
    """
    Builds the EPG cache for ALL live streams gradually.
    Runs in background without freezing UI.
    """

    if not navigator.setup_api_config():
        return

    if not settings.get_auto_epg_on_off(ADDON):
        xbmc.log("[giptv] EPG background refresh disabled.", xbmc.LOGINFO)
        return

    xbmc.log("[giptv] Starting gradual EPG cache builder...", xbmc.LOGINFO)

    try:
        # 1. Get all Live categories
        categories = xtream_api.categories("live") or []
        if not categories:
            xbmc.log("[giptv] No live categories found!", xbmc.LOGWARNING)
            return

        for cat in categories:
            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name")
            xbmc.log(
                f"[giptv] Fetching streams for category {cat_name} ({cat_id})",
                xbmc.LOGINFO,
            )

            # 2. Get all live streams for this category
            stream_list = xtream_api.streams_by_category("live", cat_id) or []
            if not stream_list:
                continue

            for stream in stream_list:
                stream_id = stream.get("stream_id")
                if not stream_id:
                    continue

                cache_key = f"{xtream_api.USERNAME}_{stream_id}"

                # Skip if already cached
                if cache_handler.get("epg_data", cache_key):
                    continue

                xbmc.log(f"[giptv] Fetching EPG for stream {stream_id}", xbmc.LOGDEBUG)

                # 3. Fetch & decode EPG
                epg = xtream_api.get_decoded_epg_short_by_stream(stream_id)

                # 4. Save EPG into local addon cache
                if epg:
                    cache_handler.set("epg_data", cache_key, {"epg_listings": epg})

                # --- GRADUAL BUILDER ---
                # Sleep to avoid freezing or hammering server
                xbmc.sleep(30)

    except Exception as e:
        xbmc.log(f"[giptv] EPG Cache Builder Error: {str(e)}", xbmc.LOGERROR)

    xbmc.log("[giptv] Finished building EPG cache.", xbmc.LOGINFO)


# ============================================================
#  MAIN SERVICE LOOP
# ============================================================
if __name__ == "__main__":
    # Wait for Kodi to fully initialize
    time.sleep(5)

    if not navigator.setup_api_config():
        xbmc.log("[giptv] No API connection — aborting service start.", xbmc.LOGERROR)
    else:
        # Run index build if needed
        auto_rebuild_index()

    monitor = SettingsMonitor()

    next_epg_build = time.time() + 10  # start 10 seconds after boot

    while not monitor.abortRequested():
        if time.time() >= next_epg_build:
            build_epg_cache_gradually()
            next_epg_build = time.time() + (60 * 30)  # rebuild every 30 minutes

        xbmc.sleep(500)

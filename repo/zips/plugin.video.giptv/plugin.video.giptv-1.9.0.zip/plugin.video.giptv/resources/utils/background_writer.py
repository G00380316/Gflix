
import threading
import queue
import time
from resources.utils.watch_history import add_item

# A thread-safe queue for write tasks
_write_queue = queue.Queue()

def _writer_loop():
    """Background loop that processes write tasks safely."""
    while True:
        try:
            task = _write_queue.get()   # Wait for next task
            if task is None:
                break  # stop signal

            add_item(**task)

        except Exception:
            pass

        time.sleep(0.05)   # small delay to avoid hammering disk


# Start background thread only once
_writer_thread = threading.Thread(target=_writer_loop, daemon=True)
_writer_thread.start()


def enqueue_write(task_dict):
    """Public function to add tasks to the background writer."""
    _write_queue.put(task_dict)

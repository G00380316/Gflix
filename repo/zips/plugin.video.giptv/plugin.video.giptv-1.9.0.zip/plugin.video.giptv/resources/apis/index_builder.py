import json
import os
import xbmcvfs
import xbmc
import resources.apis.xtream_api as xtream_api


def _index_dir():
    base = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.giptv/index"
    )
    if not xbmcvfs.exists(base):
        xbmcvfs.mkdirs(base)
    return base


def _write(name, data):
    path = os.path.join(_index_dir(), f"{name}.json")
    with xbmcvfs.File(path, "w") as f:
        f.write(json.dumps(data, ensure_ascii=False))


def build_index():
    xbmc.log("[giptv] Building search index (background)...", xbmc.LOGINFO)

    # ---------------- VOD ----------------
    vod_out = []
    for cat in xtream_api.categories("vod") or []:
        for m in xtream_api.streams_by_category("vod", cat["category_id"]) or []:
            sid = str(m.get("stream_id"))
            if not sid:
                continue

            vod_out.append(
                {
                    "id": sid,
                    "title": m.get("name", ""),
                    "thumb": m.get("stream_icon") or m.get("cover", ""),
                    "tmdb": m.get("tmdb") or m.get("tmdb_id"),
                    "ext": m.get("container_extension", "mp4"),
                }
            )
    _write("vod_index", vod_out)

    # ---------------- SERIES ----------------
    series_out = []
    for cat in xtream_api.categories("series") or []:
        for s in xtream_api.streams_by_category("series", cat["category_id"]) or []:
            sid = str(s.get("series_id"))
            if not sid:
                continue

            series_out.append(
                {
                    "id": sid,
                    "title": s.get("name", ""),
                    "thumb": s.get("cover", ""),
                    "tmdb": s.get("tmdb") or s.get("tmdb_id"),
                }
            )
    _write("series_index", series_out)

    # ---------------- LIVE ----------------
    live_out = []
    for cat in xtream_api.categories("live") or []:
        for c in xtream_api.streams_by_category("live", cat["category_id"]) or []:
            sid = str(c.get("stream_id"))
            if not sid:
                continue

            live_out.append(
                {
                    "id": sid,
                    "title": c.get("name", ""),
                    "thumb": c.get("stream_icon") or c.get("tv_logo", ""),
                    "ext": c.get("container_extension", "ts"),
                }
            )
    _write("live_index", live_out)

    xbmc.log("[giptv] Search index build finished.", xbmc.LOGINFO)

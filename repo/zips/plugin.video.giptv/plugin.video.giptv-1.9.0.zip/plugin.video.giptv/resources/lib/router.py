# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import time
import threading

# Import external modules: API for content, navigator for menu logic, control for Kodi utilities.
import resources.apis.xtream_api as xtream_api
import resources.lib.navigator as navigator
import resources.utils.control as control
from resources.utils.watch_history import clear_history
from resources.utils.background_writer import enqueue_write

ADDON = xbmcaddon.Addon()


def open_addon_settings():
    """
    Opens the addon's settings dialog. This is the endpoint for the 'Settings'
    context menu option attached to list items.
    """
    # Use the custom control function to open settings
    control.openSettings()


def play_stream(url, name):
    play_item = xbmcgui.ListItem(path=url)
    play_item.setLabel(name)
    play_item.setProperty("IsPlayable", "true")

    xbmc.executebuiltin("DisableAddon(script.black.bars.never)")

    # Extract stream id
    stream_id = url.split("/")[-1].split(".")[0]

    # Prepare a safe entry
    entry = {
        "item_id": stream_id,
        "title": name,
        "stream_type": (
            "live" if "/live/" in url else "vod" if "/movie/" in url else "series"
        ),
        "thumb": "",
        "fanart": "",
        "resume_time": 0,
        "play_url": url,
    }

    # Push to background queue
    enqueue_write(entry)

    xbmcplugin.setResolvedUrl(navigator.PLUGIN_HANDLE, True, play_item)


def handle_routing(url_params):
    """
    The central dispatcher for the entire addon.
    It reads the 'mode' from the URL parameters and sends the request to the correct function.
    """
    # Parameters come in as lists (from urlparse.parse_qs), so we grab the first item [0].
    mode = url_params.get("mode", [None])[0]

    # We check for a search query here, as it can be present on any listing URL.
    search_query = url_params.get("search_query", [None])[0]

    # --- Check for initial launch (Mode is None) ---

    # If mode is None, it means the add-on was launched from the main screen.
    if mode is None:
        # We call the top-level menu that lists Live TV, Movies, and TV Series.
        navigator.root_menu()
        return  # Exit the function, as we've handled the request.

    # --- Content Listing Modes (Live TV / Movies) ---

    if mode == "list_streams":
        # Handles clicks on specific categories (e.g., 'Sports', 'News').
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        # Pass the search_query to the listing function for filtering.
        navigator.list_streams(stream_type, category_id, name, search_query)

    # --- TV Series Listing Modes ---

    elif mode == "list_series_streams":
        # Handles clicks on TV Series categories to list series titles.
        stream_type = url_params.get("stream_type", [""])[0]
        category_id = url_params.get("category_id", [""])[0]
        name = url_params.get("name", [""])[0]

        # Pass the search_query to the listing function for filtering.
        navigator.list_series_streams(stream_type, category_id, name, search_query)

    elif mode == "list_series_seasons":
        # Handles clicks on a specific TV Series title to list its seasons.
        series_id = url_params.get("series_id", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        navigator.list_series_seasons(series_id, series_name)

    elif mode == "list_series_episodes":
        # Handles clicks on a specific Season to list playable episodes.
        series_id = url_params.get("series_id", [""])[0]
        season_num = url_params.get("season_num", [""])[0]
        series_name = url_params.get("series_name", [""])[0]

        navigator.list_series_episodes(series_id, season_num, series_name)

    # --- Playback and Utility Modes ---

    elif mode == "play_stream":
        # Handles clicks on individual video streams (e.g., channel, movie title, episode).
        url = url_params.get("url", [""])[0]
        name = url_params.get("name", [""])[0]
        # Dispatch to the local playback handler.
        play_stream(url, name)

    elif mode == "open_settings":
        # Handles the 'Open Settings' context menu click.
        open_addon_settings()

    # --- Search and Initial Navigation Modes ---

    elif mode == "search":
        # Handles the click on the initial [ Search... ] folder item.
        mode_to_call = url_params.get("mode_to_call", [None])[0]
        stream_type = url_params.get("stream_type", [None])[0]
        category_id = url_params.get("category_id", [None])[0]

        # Dispatch to the navigator to handle the user prompt.
        navigator.search_menu(mode_to_call, stream_type, category_id)

    elif mode == "global_search":
        navigator.global_search()

    elif mode == "global_vod_search":
        navigator.global_vod_search()

    elif mode == "global_series_search":
        navigator.global_series_search()

    elif mode == "global_live_search":
        navigator.global_live_search()

    elif mode == "recently_watched":
        navigator.recently_watched()

    elif mode == "clear_history":
        clear_history()
        control.notification(
            ADDON.getAddonInfo("name"), "Recently Watched Reset Done", icon="INFO"
        )
        xbmc.executebuiltin("Container.Refresh")

    elif mode == "list_categories":
        # This handles navigation AFTER clicking a root menu item (Live TV, Movies, Series).
        # Determine the content type (defaulting to LIVE_TYPE if not specified in the URL).
        stream_type = url_params.get("stream_type", [xtream_api.LIVE_TYPE])[0]

        # Pass the search_query for filtering the top-level categories.
        navigator.list_categories(stream_type, search_query)

    else:
        # Failsafe for any unrecognized mode.
        control.okDialog(ADDON.getAddonInfo("name"), f"Unknown mode: {mode}")

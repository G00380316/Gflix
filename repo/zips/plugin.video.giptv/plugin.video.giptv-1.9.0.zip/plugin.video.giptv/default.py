from io import SEEK_CUR
import sys, os

# Python 2/3 compatibility for URL parsing
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

# Add resources path to ensure modules can be imported
sys.path.insert(0, os.getcwd())
import xbmc

# Import the main router logic
import resources.lib.router as router
import resources.utils.kodi_utils as utils
import resources.lib.navigator as navigator

# --- Main Execution ---

if __name__ == "__main__":
    # sys.argv[2] contains the URL parameters (the query string)
    # [1:] is used to remove the leading '?'
    params = urlparse.parse_qs(sys.argv[2][1:])

    # Extract action safely as a string
    action = params.get("action", [None])[0]

    if action == "close_settings":
        utils.close_setting()
    elif action == "clear_cache":
        utils.clear_cache()
    elif action == "build_search_index":
        utils.notification("Building Search Index may take ~2 minutes Initially")
        navigator.build_search_index()
    elif action == "global_search":
        url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_search"})
        xbmc.executebuiltin("Container.Update({}, replace)".format(url))
    else:
        router.handle_routing(params)

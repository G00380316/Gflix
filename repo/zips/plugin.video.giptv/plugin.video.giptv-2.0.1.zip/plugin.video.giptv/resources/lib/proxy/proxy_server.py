# -*- coding: utf-8 -*-
import time
import threading
import urllib.parse
import urllib.request

import xbmc

try:
    # Py3
    from http.server import BaseHTTPRequestHandler
    from socketserver import ThreadingMixIn
    from http.server import HTTPServer
except ImportError:
    # Kodi nowadays is Py3, but keep fallback
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn


class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class StreamProxyHandler(BaseHTTPRequestHandler):
    """
    GET /stream?u=<url-encoded-upstream-url>
    Streams bytes from upstream to Kodi and reconnects on stall/failure.
    """

    # Tunables (good defaults for IPTV TS)
    # CHUNK_SIZE = 64 * 1024  # 64KB
    # UPSTREAM_TIMEOUT = 10  # seconds for urlopen timeout
    # STALL_SECONDS = 15  # if no bytes for this long -> reconnect
    CHUNK_SIZE = 256 * 1024  # 64KB
    UPSTREAM_TIMEOUT = 20  # seconds for urlopen timeout
    STALL_SECONDS = 6  # if no bytes for this long -> reconnect
    RECONNECT_DELAY = 0.5  # seconds between reconnect attempts

    # Optional upstream headers
    DEFAULT_HEADERS = {
        "User-Agent": "Mozilla/5.0 (Kodi IPTV Proxy)",
        "Connection": "keep-alive",
    }

    server_version = "KodiIPTVProxy/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Route HTTP server logs to Kodi log
        xbmc.log("[IPTV-PROXY] " + (fmt % args), xbmc.LOGINFO)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path != "/stream":
            self.send_response(404)
            self.end_headers()
            return

        qs = urllib.parse.parse_qs(parsed.query)
        upstream_list = qs.get("u") or []
        if not upstream_list:
            self.send_response(400)
            self.end_headers()
            return

        upstream_url = urllib.parse.unquote(upstream_list[0])
        xbmc.log(f"[IPTV-PROXY] Start stream -> {upstream_url}", xbmc.LOGINFO)

        self.send_response(200)
        self.send_header("Content-Type", "video/MP2T")
        self.send_header("Connection", "close")
        self.end_headers()

        monitor = xbmc.Monitor()
        last_data = time.monotonic()
        reconnect_attempts = 0
        MAX_RECONNECTS = 3

        while not monitor.abortRequested() and reconnect_attempts < MAX_RECONNECTS:
            try:
                req = urllib.request.Request(upstream_url, headers=self.DEFAULT_HEADERS)
                with urllib.request.urlopen(req, timeout=self.UPSTREAM_TIMEOUT) as resp:
                    while not monitor.abortRequested():
                        chunk = resp.read(self.CHUNK_SIZE)
                        if chunk:
                            try:
                                self.wfile.write(chunk)
                                self.wfile.flush()
                            except Exception:
                                xbmc.log(
                                    "[IPTV-PROXY] Client disconnected", xbmc.LOGINFO
                                )
                                return

                            last_data = time.monotonic()
                            continue

                        # If no data for STALL_SECONDS, reconnect
                        if (time.monotonic() - last_data) >= self.STALL_SECONDS:
                            xbmc.log(
                                "[IPTV-PROXY] Stall detected. Reconnecting...",
                                xbmc.LOGINFO,
                            )
                            reconnect_attempts += 1
                            break

                        time.sleep(0.05)

            except Exception as e:
                xbmc.log(
                    f"[IPTV-PROXY] Upstream error: {e}. Reconnecting...", xbmc.LOGINFO
                )
                reconnect_attempts += 1

            # Reconnect delay, exit early if Kodi is shutting down
            for _ in range(int(self.RECONNECT_DELAY * 20)):
                if monitor.abortRequested():
                    return
                time.sleep(0.05)

        xbmc.log(
            f"[IPTV-PROXY] Exiting stream thread after {reconnect_attempts} attempts",
            xbmc.LOGINFO,
        )


class IPTVStreamProxy(object):
    def __init__(self, host="127.0.0.1", port=0):
        self.host = host
        self.port = port
        self._httpd = None
        self._thread = None

    def start(self):
        if self._httpd:
            return self.port

        self._httpd = _ThreadingHTTPServer((self.host, self.port), StreamProxyHandler)
        self.port = self._httpd.server_address[1]

        self._thread = threading.Thread(
            target=self._httpd.serve_forever, name="IPTVStreamProxy"
        )
        self._thread.daemon = True
        self._thread.start()

        xbmc.log(
            f"[IPTV-PROXY] Listening on http://{self.host}:{self.port}", xbmc.LOGINFO
        )
        return self.port

    def stop(self):
        if not self._httpd:
            return
        try:
            self._httpd.shutdown()
            self._httpd.server_close()
        except Exception:
            pass
        self._httpd = None
        xbmc.log("[IPTV-PROXY] Stopped", xbmc.LOGINFO)

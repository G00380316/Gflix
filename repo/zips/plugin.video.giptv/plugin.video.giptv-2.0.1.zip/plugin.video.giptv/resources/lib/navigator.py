import sys
import threading

# Python 2/3 compatibility for handling URL encoding/decoding.
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse
import datetime
import time
import os

import xbmc  # Necessary for functions like xbmc.sleep() and xbmc.Keyboard().
import xbmcaddon
import xbmcgui
import xbmcplugin

# Import external modules
import resources.apis.tmdb_helper as TMDbHelper
import resources.apis.xtream_api as xtream_api
import resources.utils.giptv as giptv
from resources.utils import settings
import resources.lib.manager.index_manager as index_manager
from resources.lib.manager.fetch_manager import cache_handler
from resources.lib.manager.epg_manager import (
    get_now_next,
    get_xmltv_index,
    resolve_xmltv_channel_id,
)
from resources.lib.cache.picon_cache import get_picon
import resources.utils.config as config
from resources.utils.xtream import STATE

# Global constants for the Kodi API.
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
# This points directly to fanart.jpg in your addon's root folder
GLOBAL_FANART = os.path.join(ADDON_PATH, 'fanart.png')
LIVE_ICON   = os.path.join(ADDON_PATH, 'resources', 'media', 'thumb', 'tv.png')
SERIES_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'thumb', 'series.png')
MOVIE_ICON  = os.path.join(ADDON_PATH, 'resources', 'media', 'thumb', 'movies.png')
SEARCH_ICON  = os.path.join(ADDON_PATH, 'resources', 'media', 'thumb', 'search.png')
WATCHED_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'thumb', 'watched.png') 

# PLUGIN_HANDLE: The unique identifier Kodi gives to this running addon instance.
# We use this to tell Kodi where to put our list items.
# SAFE plugin handle assignment (service.py will not crash)
if len(sys.argv) > 1 and sys.argv[1].isdigit():
    PLUGIN_HANDLE = int(sys.argv[1])
else:
    PLUGIN_HANDLE = -1  # special value meaning "not in plugin mode"
ADDON_ID = ADDON.getAddonInfo("id")

# --- CONTEXT MENU SETUP ---
# Defines the Kodi built-in command URL that will call our router with the 'open_settings' mode.
SETTINGS_ACTION_URL = "RunPlugin(plugin://{}/?mode=open_settings)".format(ADDON_ID)
INDEX_ACTION_URL = "RunPlugin(plugin://{}/?action=build_search_index)".format(ADDON_ID)

# SETTINGS_CONTEXT_MENU: The list item we attach to every folder/stream for the
# right-click/long-press menu.
SETTINGS_CONTEXT_MENU = [
    ("Global Search", f"Container.Update(plugin://{ADDON_ID}/?mode=global_search)"),
    ("Open Settings", SETTINGS_ACTION_URL),
    ("Refresh", "Container.Refresh"),
    ("Rebuild list", f"Container.Update({sys.argv[0]})"),
    ("Build Search Index", INDEX_ACTION_URL),
    ("Reset Recently Watched", f"RunPlugin(plugin://{ADDON_ID}/?mode=clear_history)"),
]

# Initialize helpers
tmdb_helper = TMDbHelper.TMDbHelper()


def root_menu():
    LIVE_TYPE = "live"
    VOD_TYPE = "vod"
    SERIES_TYPE = "series"

    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    global_search_url = (
        sys.argv[0] + "?" + urlparse.urlencode({"mode": "global_search"})
    )

    global_search_item = xbmcgui.ListItem(
        label="[COLOR yellow]\ue836[/COLOR] [B]Global Search (All Content)[/B]"
    )
    global_search_item.setArt(
        {"icon": "DefaultAddonSearch.png", "thumb": "DefaultAddonSearch.png", "fanart": SEARCH_ICON}
    )

    # Added "Rebuild Index" in context menu for power users
    global_search_item.addContextMenuItems(
        [
            (
                "Rebuild Search Index",
                f"RunPlugin(plugin://{ADDON_ID}/?action=build_search_index)",
            )
        ]
    )

    xbmcplugin.addDirectoryItem(
        PLUGIN_HANDLE, global_search_url, global_search_item, isFolder=True
    )

    # Recently watched
    recent_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    recent_item = xbmcgui.ListItem("[B][COLOR orange]Recently Watched[/COLOR][/B]")
    recent_item.setArt({"fanart": WATCHED_ICON})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, recent_url, recent_item, isFolder=True)

    menu_items = [
        ("[B]Live TV[/B]", "live", LIVE_ICON),
        ("[B]Movies[/B]", "vod", MOVIE_ICON),
        ("[B]TV Series[/B]", "series", SERIES_ICON),
    ]

    for label, stream_type, thumb in menu_items:
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {"mode": "list_categories", "stream_type": stream_type}
            )
        )

        item = xbmcgui.ListItem(label=label)
        item.setArt({ "thumb": thumb,"icon": thumb, "fanart": thumb})
        item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, item, isFolder=True)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Xtream Content Streams")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def epg_progress(start_ts, end_ts):
    now = int(time.time())
    if end_ts <= start_ts:
        return 0
    return max(0, min(100, int((now - start_ts) * 100 / (end_ts - start_ts))))


def progress_bar(percent, width=10):
    filled = int(width * percent / 100)
    return "●" * filled + "○" * (width - filled)


def fmt_time(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M")


_current_items = {}


def store_current_items(stream_type, category_id, items):
    key = f"{stream_type}_{category_id}"
    _current_items[key] = items


def get_current_items(stream_type, category_id):
    key = f"{stream_type}_{category_id}"
    return _current_items.get(key, [])


def extract_tmdb_id(data):
    return (
        data.get("tmdb")
        or data.get("tmdb_id")
        or data.get("tmdbId")
        or data.get("tmdbID")
        or data.get("imdb_id")
        or (data.get("info", {}) or {}).get("tmdb")
        or (data.get("info", {}) or {}).get("tmdb_id")
        or None
    )


def list_categories(stream_type, search_query=None):
    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    # Parse search trigger from URL parameters if not passed
    if search_query is None:
        params = dict(urlparse.parse_qsl(sys.argv[2]))
        search_query = params.get("search")

    # Add "Search All" shortcut
    if stream_type == "vod":
        search_all_mode = "global_vod_search"
        search_label = "[COLOR yellow]Search ALL Movies[/COLOR]"
    elif stream_type == "series":
        search_all_mode = "global_series_search"
        search_label = "[COLOR yellow]Search ALL TV Series[/COLOR]"
    else:
        search_all_mode = "global_live_search"
        search_label = "[COLOR yellow]Search ALL Live TV[/COLOR]"

    search_all_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": search_all_mode})
    search_all_item = xbmcgui.ListItem(label=search_label)
    search_all_item.setArt({"icon": "DefaultAddonSearch.png"})
    xbmcplugin.addDirectoryItem(
        PLUGIN_HANDLE, search_all_url, search_all_item, isFolder=True
    )

    # Add Recently Watched shortcut
    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    # Fetch categories from cache or API
    category_list = cache_handler.get("categories", f"{STATE.username}_{stream_type}")
    if not category_list:
        category_list = xtream_api.categories(stream_type)

    if not category_list:
        giptv.notification(
            ADDON.getAddonInfo("name"), "No categories found.", icon="INFO"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    if search_query == "__clear__":
        search_query = None
    if search_query is None:
        filter_item = xbmcgui.ListItem(
            label=f"[COLOR yellow]\ue836[/COLOR] Filter {stream_type.capitalize()} Category"
        )
        filter_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_categories",
                    "stream_type": stream_type,
                    "search": "trigger",
                }
            )
        )
        filter_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, filter_url, filter_item, isFolder=True
        )

    # Open keyboard only if triggered
    if search_query == "trigger":
        keyboard = xbmc.Keyboard("", f"Filter {stream_type.upper()} Categories")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

        search_query = keyboard.getText().strip().lower()

        if not search_query:
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # Filter categories if search query exists
    if search_query and search_query != "trigger":
        category_list = [
            c
            for c in category_list
            if search_query in c.get("category_name", "").lower()
        ]
        if not category_list:
            clear_item = xbmcgui.ListItem(
                label="[COLOR red]\u2716[/COLOR] Clear Filter"
            )
            giptv.return_action()
            giptv.notification(
                ADDON.getAddonInfo("name"),
                f"No categories found matching '{search_query}'.",
                icon="INFO",
            )
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    if search_query and search_query not in ("trigger", "__clear__"):
        clear_item = xbmcgui.ListItem(label="[COLOR red]\u2716[/COLOR] Clear Filter")
        clear_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_categories",
                    "stream_type": stream_type,
                    "search_query": "__clear__",
                }
            )
        )
        clear_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, clear_url, clear_item, isFolder=True)

    # Add category items
    for category in category_list:
        name = category.get("category_name", "Unknown Category")
        category_id = category.get("category_id")
        next_mode = "list_series_streams" if stream_type == "series" else "list_streams"

        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": next_mode,
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                }
            )
        )

        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the individual playable streams (channels, movies) within a selected category,
    now using TMDbHelper to fetch rich metadata for VOD streams.
    """
    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    # Fetch all streams for the given category ID from the API.
    stream_list = cache_handler.get(
        stream_type, f"{STATE.username}_{stream_type}_{category_id}"
    )
    if not stream_list:
        if settings.get_cache_on_off(ADDON):
            giptv.notification("Stream not Cached", icon="INFO")
        stream_list = xtream_api.streams_by_category(stream_type, category_id)

    if not stream_list:
        giptv.notification(
            ADDON.getAddonInfo("name"), f"No streams found in {name}.", icon="INFO"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    if search_query == "__clear__":
        search_query = None
    if search_query is None:
        filter_item = xbmcgui.ListItem(
            label=f"[COLOR yellow]\ue836[/COLOR] Filter {stream_type.capitalize()} Streams"
        )
        filter_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_streams",
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                    "search_query": "trigger",
                }
            )
        )
        filter_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, filter_url, filter_item, isFolder=True
        )

    # Open keyboard only if triggered
    if search_query == "trigger":
        keyboard = xbmc.Keyboard("", f"Filter {stream_type.upper()} Streams")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

        search_query = keyboard.getText().strip().lower()

        if not search_query:
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # Filter streams if a query exists
    if search_query and search_query != "trigger":
        q = search_query.lower()

        def matches(stream):
            return (
                q in (stream.get("name") or "").lower()
                or q in (stream.get("title") or "").lower()
                or q in (stream.get("stream_display_name") or "").lower()
            )

        stream_list = [s for s in stream_list if matches(s)]

        if not stream_list:
            clear_item = xbmcgui.ListItem(
                label="[COLOR red]\u2716[/COLOR] Clear Filter"
            )
            giptv.return_action()
            giptv.notification(
                ADDON.getAddonInfo("name"),
                f"No streams found matching '{search_query}'.",
                icon="INFO",
            )
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    if search_query and search_query not in ("trigger", "__clear__"):
        clear_item = xbmcgui.ListItem(label="[COLOR red]\u2716[/COLOR] Clear Filter")
        clear_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_streams",
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                    "search_query": "__clear__",
                }
            )
        )
        clear_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, clear_url, clear_item, isFolder=True)

    for stream in stream_list:
        # --- INITIALIZE COMMON VARIABLES ---
        stream_id = str(
            stream.get("stream_id")
            or stream.get("movie_id")
            or stream.get("vod_id")
            or ""
        )
        if not stream_id:
            continue

        stream_name = (
            stream.get("name")
            or stream.get("title")
            or stream.get("stream_display_name")
            or "Unknown Stream"
        )

        stream_icon = get_picon(
            stream_id, stream.get("stream_icon"), stream.get("category_id")
        )

        list_item = xbmcgui.ListItem(label=stream_name)

        tmdb_id = None
        mediatype = "video"
        info_label = {}
        art_dict = {}

        # --- VOD/MOVIE STREAM HANDLING ---
        if stream_type == "vod":
            stream_type_for_api = "vod"
            ext = stream.get("container_extension", "mp4")
            info_data = stream.get("info", {})
            mediatype = "movie"

            # Extract TMDb ID
            tmdb_id_raw = stream.get("tmdb") or stream.get("tmdb_id")
            if tmdb_id_raw:
                tmdb_id = str(tmdb_id_raw)

            # --- TMDb Lookup and Overwrite ---
            tmdb_details = None
            if tmdb_id:
                # CRITICAL: Call the TMDb helper to get rich metadata
                tmdb_details = tmdb_helper.get_movie_details(tmdb_id)
                xbmcplugin.setContent(PLUGIN_HANDLE, "movies")  # Set content type

            if tmdb_details:
                # Use rich TMDb data
                # Get cast as list of Actor objects
                cast_list = []
                if tmdb_details.get("cast"):
                    for actor in tmdb_details.get("cast", []):
                        if actor.get("name"):
                            cast_list.append(
                                xbmc.Actor(actor.get("name"), actor.get("role"))
                            )

                # Get directors as list
                directors = []
                if tmdb_details.get("director"):
                    if isinstance(tmdb_details["director"], list):
                        directors = tmdb_details["director"]
                    else:
                        directors = [tmdb_details["director"]]
                elif info_data.get("director"):
                    directors = [info_data["director"]]

                # Get genres as list
                genres = []
                if tmdb_details.get("genre"):
                    if isinstance(tmdb_details["genre"], list):
                        genres = tmdb_details["genre"]
                    else:
                        genres = [tmdb_details["genre"]]
                elif info_data.get("genre"):
                    genres = [info_data["genre"]]

                # Set Art
                art_dict = tmdb_details.get("art", {})
                if not art_dict.get("poster") and stream_icon:
                    art_dict["poster"] = stream_icon
                    art_dict["thumb"] = stream_icon
                if not art_dict.get("thumb") and art_dict.get("poster"):
                    art_dict["thumb"] = art_dict.get("poster")

                # Set TMDb/IMDb properties
                if tmdb_id:
                    list_item.setProperty("tmdbnumber", tmdb_id)
                    list_item.setProperty("imdbnumber", tmdb_id)

                # Use VideoInfoTag
                tag = list_item.getVideoInfoTag()
                tag.setTitle(tmdb_details.get("title") or stream_name)
                tag.setPlot(tmdb_details.get("plot") or "")

                if tmdb_details.get("year") and tmdb_details["year"].isdigit():
                    tag.setYear(int(tmdb_details["year"]))

                if tmdb_details.get("rating"):
                    try:
                        tag.setRating(float(tmdb_details["rating"]), 10)
                    except (ValueError, TypeError):
                        pass

                if tmdb_details.get("duration"):
                    try:
                        tag.setDuration(int(tmdb_details["duration"]))
                    except (ValueError, TypeError):
                        pass
                elif info_data.get("duration_secs"):
                    try:
                        tag.setDuration(int(info_data["duration_secs"]))
                    except (ValueError, TypeError):
                        pass

                tag.setMediaType("movie")
                if genres:
                    tag.setGenres(genres)
                if directors:
                    tag.setDirectors(directors)
                if cast_list:
                    tag.setCast(cast_list)

                # Set unique ID for TMDb
                if tmdb_id:
                    tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")

            else:
                # If TMDb lookup failed, fall back to basic source data
                movie_plot = (
                    stream.get("plot")
                    or info_data.get("plot")
                    or "No description available."
                )

                # Get duration if available
                duration = 0
                if info_data.get("duration_secs"):
                    try:
                        duration = int(info_data["duration_secs"])
                    except (ValueError, TypeError):
                        pass

                # Get year if available
                year = 0
                if stream.get("release_date"):
                    year_str = stream["release_date"].split("-")[0]
                    if year_str.isdigit():
                        year = int(year_str)

                # Use VideoInfoTag
                tag = list_item.getVideoInfoTag()
                tag.setTitle(stream_name)
                tag.setPlot(movie_plot)
                tag.setMediaType("movie")
                if duration > 0:
                    tag.setDuration(duration)
                if year > 0:
                    tag.setYear(year)

                if stream_icon:
                    art_dict["thumb"] = stream_icon
                    art_dict["icon"] = stream_icon
                    art_dict["poster"] = stream_icon

        # --- LIVE TV STREAM HANDLING (EPG Logic) ---
        else:
            stream_type_for_api = "live"
            ext = stream.get("container_extension", "ts")
            mediatype = "video"

            stream_id = str(stream.get("stream_id"))

            # --- Base info (always available) ---
            info_label = {
                "title": stream_name,
                "plot": stream_name,
                "mediatype": mediatype,
                "tvshowtitle": stream_name,
            }

            # --- ART (independent) ---
            art_dict = {}
            if stream_icon:
                art_dict["thumb"] = stream_icon
                art_dict["icon"] = stream_icon
            else:
                art_dict["icon"] = "DefaultVideo.png"
                art_dict["thumb"] = "DefaultVideo.png"

            # --- EPG (ALWAYS RUNS) ---
            xmltv_index = get_xmltv_index()
            channel_id = resolve_xmltv_channel_id(stream)

            xbmc.log(
                f"[giptv][epg] Stream '{stream_name}' epg_id='{channel_id}'",
                xbmc.LOGDEBUG,
            )

            # now = get_now(xmltv_index, channel_id)
            data = get_now_next(xmltv_index, channel_id)
            if data:
                now = data.get("now")
                next_ = data.get("next")

                if now:
                    title, desc, start_ts, end_ts = now
                    duration = end_ts - start_ts

                    pct = epg_progress(start_ts, end_ts)
                    bar = progress_bar(pct)

                    plot_lines = [
                        f"[COLOR yellow][B]Now: {title}[/B][/COLOR] "
                        f"[COLOR grey][I]from {fmt_time(start_ts)} – {fmt_time(end_ts)}[/I][/COLOR]",
                        f"[COLOR green]{bar}  {pct}%[/COLOR]",
                        f"[COLOR white]{desc}[/COLOR]",
                    ]

                    if next_:
                        next_title, next_desc, next_start, next_end = next_
                        plot_lines += [
                            f"[COLOR yellow][B]Next: {next_title}[/B][/COLOR] "
                            f"[COLOR grey][I]from {fmt_time(next_start)} – {fmt_time(next_end)}[/I][/COLOR]",
                            f"[COLOR white]{next_desc}[/COLOR]",
                        ]

                    plot = "\n".join(plot_lines)

                    list_item.setLabel(
                        f"[COLOR green][LIVE][/COLOR] {stream_name} "
                        # f"[COLOR yellow]- {title}[/COLOR]"
                    )

                    # Use VideoInfoTag for live TV
                    tag = list_item.getVideoInfoTag()
                    tag.setTitle(title)
                    tag.setPlot(plot)
                    tag.setDuration(duration)
                    tag.setMediaType("video")

                    # Set live properties
                    list_item.setProperty("IsLive", "true")
            else:
                # Basic VideoInfoTag for streams without EPG
                tag = list_item.getVideoInfoTag()
                tag.setTitle(stream_name)
                tag.setPlot(stream_name)
                tag.setMediaType("video")

            list_item.setArt(art_dict)

        # --- BUILD PLAY URL AND FINALIZE LIST ITEM ---

        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type=stream_type_for_api,
            container_extension=ext,
        )

        if play_url:
            url = (
                sys.argv[0]
                + "?"
                + urlparse.urlencode(
                    {"mode": "play_stream", "url": play_url, "name": stream_name}
                )
            )

            list_item.setProperty("IsPlayable", "true")
            list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

            # Set collected art
            list_item.setArt(art_dict)

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=False
            )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# --- SERIES NAVIGATION FUNCTIONS ---
def list_series_streams(stream_type, category_id, name, search_query=None):
    """
    Displays the list of TV Series titles within a selected category.
    Now prioritizes setting the TMDb ID to allow Kodi's scrapers to fetch
    rich metadata (fanart, plot, cast, trailer, etc.) automatically.
    """
    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    # Fetch all series titles for the given category ID.
    series_list = cache_handler.get(
        stream_type, f"{STATE.username}_{stream_type}_{category_id}"
    )
    if not series_list:
        if settings.get_cache_on_off(ADDON):
            giptv.notification("Series not Cached", icon="INFO")
        series_list = xtream_api.streams_by_category(stream_type, category_id)

    if not series_list:
        giptv.notification(
            ADDON.getAddonInfo("name"), f"No streams found in {name}.", icon="INFO"
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    rw_url = sys.argv[0] + "?" + urlparse.urlencode({"mode": "recently_watched"})
    rw_item = xbmcgui.ListItem(label="[COLOR cyan]Recently Watched[/COLOR]")
    rw_item.setArt({"icon": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, rw_url, rw_item, isFolder=True)

    # --- CLEAR FILTER HANDLER ---
    if search_query == "__clear__":
        search_query = None
    if search_query is None:
        filter_item = xbmcgui.ListItem(
            label=f"[COLOR yellow]\ue836[/COLOR] Filter {stream_type.capitalize()} Series"
        )
        filter_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_series_streams",
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                    "search_query": "trigger",
                }
            )
        )
        filter_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, filter_url, filter_item, isFolder=True
        )

    # Open keyboard only if triggered
    if search_query == "trigger":
        keyboard = xbmc.Keyboard("", f"Filter {stream_type.upper()} Series")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

        search_query = keyboard.getText().strip().lower()

        if not search_query:
            giptv.return_action()
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # Filter streams if a query exists
    if search_query and search_query != "trigger":
        q = search_query.lower()

        def matches(series):
            return (
                q in (series.get("name") or "").lower()
                or q in (series.get("title") or "").lower()
                or q in (series.get("stream_display_name") or "").lower()
            )

        series_list = [s for s in series_list if matches(s)]

        if not series_list:
            clear_item = xbmcgui.ListItem(
                label="[COLOR red]\u2716[/COLOR] Clear Filter"
            )
            giptv.return_action()
            giptv.notification(
                ADDON.getAddonInfo("name"),
                f"No series found matching '{search_query}'.",
                icon="INFO",
            )
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    if search_query and search_query not in ("trigger", "__clear__"):
        clear_item = xbmcgui.ListItem(label="[COLOR red]\u2716[/COLOR] Clear Filter")
        clear_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_series_streams",
                    "stream_type": stream_type,
                    "category_id": category_id,
                    "name": name,
                    "search_query": "__clear__",
                }
            )
        )

        clear_item.setArt({"icon": "DefaultAddonSearch.png"})
        xbmcplugin.addDirectoryItem(
            PLUGIN_HANDLE, clear_url, clear_item, isFolder=False
        )

    for series in series_list:
        series_name = series.get("name", "Unknown Series")
        series_id = series.get("series_id")

        # --- CORE INFO EXTRACTION ---
        # We extract this core data to ensure *something* shows up,
        # but the TMDb ID will override it.
        plot = series.get("plot", "No description available.")
        rating_str = series.get("rating", "0")
        genre = series.get("genre", "")
        cast_str = series.get("cast", "")
        series_icon = series.get("cover", "")

        year_str = series.get("release_date", "").split("-")[0]
        year = int(year_str) if year_str.isdigit() else 0

        try:
            rating = float(rating_str)
        except (ValueError, TypeError):
            rating = 0.0

        cast_list = [c.strip() for c in cast_str.split(",")] if cast_str else []

        # Get the TMDb ID, which is the key to rich metadata fetching.
        tmdb_id = extract_tmdb_id(series)

        # Get the first backdrop path if available (used as a fallback or initial fanart)
        backdrop_list = series.get("backdrop_path", [])
        fanart_url = backdrop_list[0] if backdrop_list else ""

        # --- BUILD URL AND LIST ITEM ---
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "list_series_seasons",
                    "series_id": series_id,
                    "series_name": series_name,
                }
            )
        )

        list_item = xbmcgui.ListItem(label=series_name)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # 1. Set Art (Poster and Fanart)
        art_dict = {"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png"}

        if series_icon:
            art_dict["thumb"] = series_icon
            art_dict["icon"] = series_icon
            art_dict["poster"] = series_icon  # Use the cover image as the poster

        if fanart_url:
            art_dict["fanart"] = (
                fanart_url  # Use the direct URL for fanart (backup/initial)
            )

        list_item.setArt(art_dict)

        # 2. Set VideoInfoTag using the newer method (Kodi v19+)
        tag = list_item.getVideoInfoTag()
        tag.setTitle(series_name)
        tag.setPlot(plot)
        if genre:
            tag.setGenres([genre])
        tag.setYear(year)
        tag.setMediaType("tvshow")
        tag.setRating(rating, 10)  # rating out of 10
        tag.setCast([xbmc.Actor(actor) for actor in cast_list if actor])

        # 3. CRITICAL: Set the TMDb ID property for Kodi Scrapers
        if tmdb_id:
            # Set the TMDb ID using the 'uniqueid' property (preferred method for Kodi v19+)
            tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")

            # Also set the imdbnumber for backward compatibility
            list_item.setProperty("imdbnumber", str(tmdb_id))

            # If the user has a preferred external scraper set, you can ensure
            # it is enabled for this directory:
            xbmcplugin.setContent(PLUGIN_HANDLE, "tvshows")

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_series_seasons(series_id, series_name):
    """
    Displays the season folders for a selected TV Series.
    Ensures series-level poster and fanart are applied to the season folders.
    Uses TV show InfoTags so Kodi treats items as seasons.
    """
    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    # Set the directory title
    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, series_name)
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    # Fetch detailed information for the series
    series_info_response = cache_handler.get(
        "series_info", f"{STATE.username}_{series_id}"
    )
    if not series_info_response:
        if settings.get_cache_on_off(ADDON):
            giptv.notification("Series info not Cached", icon="INFO")
        series_info_response = xtream_api.series_info_by_id(series_id)

    if not series_info_response or "episodes" not in series_info_response:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"Could not retrieve details or episodes for {series_name}.",
            icon="ERROR",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    episodes_by_season = series_info_response.get("episodes", {})
    if not episodes_by_season:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"No seasons or episodes found for {series_name}.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # Extract series-level info/artwork
    series_info = series_info_response.get(
        "info", series_info_response.get("series_info", {})
    )
    series_poster = series_info_response.get("cover", series_info.get("cover", ""))
    backdrop_paths = series_info_response.get("backdrop_path", [])
    series_fanart = backdrop_paths[0] if backdrop_paths else ""
    tmdb_id = extract_tmdb_id(series_info_response)

    # Loop through seasons
    for season_num in sorted(episodes_by_season.keys(), key=int):
        season_title = f"Season {season_num}"

        # Build internal URL for episodes
        url_params = {
            "mode": "list_series_episodes",
            "series_id": series_id,
            "season_num": season_num,
            "series_name": series_name,
            "series_poster": series_poster,
            "series_fanart": series_fanart,
            "tmdb_id": tmdb_id,
        }
        url = sys.argv[0] + "?" + urlparse.urlencode(url_params)

        # Create list item
        list_item = xbmcgui.ListItem(label=season_title)
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # Artwork dictionary
        art_dict = {"icon": "DefaultSeason.png", "thumb": "DefaultSeason.png"}
        if series_poster:
            art_dict["poster"] = series_poster
            art_dict["thumb"] = series_poster
        if series_fanart:
            art_dict["fanart"] = series_fanart
        list_item.setArt(art_dict)

        # TV Show InfoTag
        tag = list_item.getVideoInfoTag()
        tag.setMediaType("season")
        tag.setTitle(season_title)
        tag.setTvShowTitle(series_name)
        tag.setSeason(int(season_num))
        if series_info.get("plot"):
            tag.setPlot(series_info.get("plot"))
        if series_info.get("releaseDate"):
            try:
                tag.setYear(int(series_info.get("releaseDate")[:4]))
            except Exception:
                pass
        if tmdb_id:
            tag.setUniqueIDs({"tmdb": str(tmdb_id)})
            # If you want to set a specific rating value from series_info
            if series_info.get("rating"):
                try:
                    rating_value = float(series_info.get("rating"))
                    tag.setRating("tmdb", rating_value, 0, True)  # last True makes it default
                except (ValueError, TypeError):
                    pass
            else:
                # Just set TMDB as default without a specific value
                tag.setRating("tmdb", 0, 0, True)
        # Properties for skins and scrapers
        list_item.setProperty("tvshow.tmdb_id", str(tmdb_id or ""))
        list_item.setProperty("season", str(season_num))
        list_item.setProperty("mediatype", "season")

        # Add directory item
        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def list_series_episodes(
    series_id, season_num, series_name, series_poster="", series_fanart="", tmdb_id=""
):
    if not config.ensure_api_ready():
        return
    if not index_manager.index_exists_and_valid():
        threading.Thread(target=index_manager.build_index, daemon=True).start()

    # Parse URL params in case some are missing
    params = dict(urlparse.parse_qsl(sys.argv[2]))
    series_poster = params.get("series_poster", series_poster)
    series_fanart = params.get("series_fanart", series_fanart)
    tmdb_id = params.get("tmdb_id") or tmdb_id

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"{series_name} - Season {season_num}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "episodes")

    # Fetch series info (cached or API)
    series_info = cache_handler.get("series_info", f"{STATE.username}_{series_id}")
    if not series_info:
        if settings.get_cache_on_off(ADDON):
            giptv.notification("Series info not cached", icon="INFO")
        series_info = xtream_api.series_info_by_id(series_id)

    if not series_info:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"Could not retrieve series info for {series_name}.",
            icon="ERROR",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    episodes = series_info.get("episodes", {}).get(season_num, [])
    if not episodes:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"No episodes found for Season {season_num}.",
            icon="INFO",
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    # TMDb integration for high-quality fanart
    tmdb_series_details = None
    series_fanart_hd = None
    if tmdb_id:
        tmdb_series_details = tmdb_helper.get_series_details(tmdb_id)
        series_fanart_hd = (
            tmdb_series_details["art"].get("fanart") if tmdb_series_details else None
        )

    for episode in episodes:
        # Safe handling of episode data (list or dict)
        episode_data = episode.get("info")
        if isinstance(episode_data, list):
            episode_data = episode_data[0] if episode_data else {}
        if not isinstance(episode_data, dict):
            episode_data = {}

        episode_num_str = str(episode.get("episode_num", "1"))
        base_title = episode.get("title", f"Episode {episode_num_str}")
        episode_title = (
            f"S{int(season_num):02d}E{int(episode_num_str):02d} - {base_title}"
        )

        stream_id = episode.get("id")
        ext = episode.get("container_extension", "mp4")
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id, stream_type="series", container_extension=ext
        )
        if not play_url:
            continue

        # Build plugin URL
        url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {"mode": "play_stream", "url": play_url, "name": episode_title}
            )
        )

        # ListItem
        list_item = xbmcgui.ListItem(label=episode_title)
        list_item.setProperty("IsPlayable", "true")
        list_item.addContextMenuItems(SETTINGS_CONTEXT_MENU)

        # Artwork selection
        episode_icon = episode_data.get("movie_image", "") or episode.get(
            "thumbnail", ""
        )
        art_dict = {"icon": "DefaultVideo.png"}
        episode_still = None
        episode_fanart = series_fanart_hd or series_fanart

        # TMDb episode image
        tmdb_ep_details = None
        if tmdb_id:
            tmdb_ep_details = tmdb_helper.get_episode_details(
                tmdb_id, int(season_num), int(episode_num_str)
            )
            if tmdb_ep_details:
                stills = tmdb_ep_details.get("images", {}).get("stills", [])
                if stills:
                    file_path = stills[0].get("file_path")
                    if file_path:
                        episode_still = (
                            f"https://image.tmdb.org/t/p/original{file_path}"
                        )

        # Set art dict
        art_dict["thumb"] = episode_still or episode_icon or series_poster
        art_dict["poster"] = series_poster or art_dict["thumb"]
        art_dict["fanart"] = episode_fanart or art_dict["thumb"]
        list_item.setArt(art_dict)

        # VideoInfoTag for Kodi
        tag = list_item.getVideoInfoTag()
        tag.setTitle(base_title)
        tag.setTvShowTitle(series_name)
        tag.setSeason(int(season_num))
        tag.setEpisode(int(episode_num_str))
        tag.setMediaType("episode")

        if tmdb_ep_details:
            tag.setPlot(tmdb_ep_details.get("overview") or "")
            tag.setRating(tmdb_ep_details.get("vote_average") or 0.0, 10)
            tag.setFirstAired(tmdb_ep_details.get("air_date"))
            tag.setDuration(tmdb_ep_details.get("runtime") or 0)
        else:
            tag.setPlot(episode_data.get("plot", ""))

        # Unique IDs for scraper
        if tmdb_id:
            tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
            list_item.setProperty("tmdbnumber", str(tmdb_id))
            list_item.setProperty("season", str(season_num))
            list_item.setProperty("episode", str(episode_num_str))

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE, url=url, listitem=list_item, isFolder=False
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

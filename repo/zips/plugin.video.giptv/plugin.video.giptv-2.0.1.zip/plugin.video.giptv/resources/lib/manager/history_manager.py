try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import sys

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time


# Global constants for the Kodi API.
ADDON = xbmcaddon.Addon()
# PLUGIN_HANDLE: The unique identifier Kodi gives to this running addon instance.
# We use this to tell Kodi where to put our list items.
# SAFE plugin handle assignment (service.py will not crash)
if len(sys.argv) > 1 and sys.argv[1].isdigit():
    PLUGIN_HANDLE = int(sys.argv[1])
else:
    PLUGIN_HANDLE = -1  # special value meaning "not in plugin mode"
ADDON_ID = ADDON.getAddonInfo("id")

HISTORY_PATH = xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}/watch_history.json"
)


# ------------------------------
# Helpers
# ------------------------------
def _read():
    if not xbmcvfs.exists(HISTORY_PATH):
        return []

    try:
        f = xbmcvfs.File(HISTORY_PATH, "r")
        data = json.loads(f.read())
        f.close()
    except Exception:
        return []

    # --- AUTO CLEAN ON READ ---
    cleaned = _autoclean(data)

    if cleaned != data:
        _write(cleaned)

    return cleaned


def _write(data):
    try:
        f = xbmcvfs.File(HISTORY_PATH, "w")
        f.write(json.dumps(data))
        f.close()
    except Exception:
        pass


# ------------------------------
# PUBLIC API
# ------------------------------
def add_item(
    item_id, title, stream_type, thumb="", fanart="", resume_time=0, play_url=""
):
    """
    Adds or updates a watched item.
    """
    data = _read()

    # Remove duplicates by id
    data = [i for i in data if i.get("id") != item_id]

    payload = {
        "id": item_id,
        "title": title,
        "type": stream_type,
        "thumb": thumb,
        "fanart": fanart,
        "resume": resume_time,
        "timestamp": time.time(),
        "played_at": int(time.time()),
        "play_url": play_url,
    }

    data.insert(0, payload)  # Most recent first

    # Limit list length
    if len(data) > 10:
        data = data[:10]

    _write(data)


def load_history():
    return sorted(_read(), key=lambda x: x.get("timestamp", 0), reverse=True)


def clear_history():
    _write([])


def store_watch_event(play_url, title, stream_id=None, thumb="", fanart=""):
    try:
        if stream_id:
            item_id = str(stream_id)
        else:
            item_id = play_url.split("/")[-1].split(".")[0]

        if "/live/" in play_url:
            stream_type = "live"
        elif "/movie/" in play_url:
            stream_type = "vod"
        elif "/series/" in play_url:
            stream_type = "series"
        else:
            stream_type = "unknown"

        add_item(
            item_id=item_id,
            title=title,
            stream_type=stream_type,
            thumb=thumb or "",
            fanart=fanart or "",
            play_url=play_url,
            resume_time=0,
        )
    except Exception:
        pass


def _autoclean(data):
    """
    Remove entries with missing/invalid play URLs or IDs.
    Does NOT remove valid streams even if the API is down.
    """

    cleaned = []

    for item in data:
        item_id = item.get("id")
        play_url = item.get("play_url")

        # Must have an ID
        if not item_id or item_id == "":
            continue

        # Must have a proper plugin:// or http(s):// URL
        if not play_url or "." not in play_url:
            continue

        # The URL must not be empty or contain malformed paths
        if "None" in play_url or play_url.endswith("/") or play_url.endswith(".."):
            continue

        cleaned.append(item)

    return cleaned


def recently_watched():
    history = load_history()

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Recently Watched")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    if not history:
        item = xbmcgui.ListItem("No recently watched items.")
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, "", item, isFolder=False)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for entry in history:
        title = entry.get("title", "Unknown")
        thumb = entry.get("thumb", "")
        fanart = entry.get("fanart", "")
        play_url = entry.get("play_url")
        stream_type = entry.get("type", "vod")
        stream_id = entry.get("id", "")

        plugin_url = (
            sys.argv[0]
            + "?"
            + urlparse.urlencode(
                {
                    "mode": "play_stream",
                    "url": play_url,
                    "id": stream_id,
                    "type": stream_type,
                    "name": title,
                }
            )
        )

        li = xbmcgui.ListItem(label=title)

        if thumb or fanart:
            li.setArt({
                "thumb": thumb,
                "icon": thumb,
                "poster": thumb,
                "fanart": fanart or thumb,
            })

        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        li.addContextMenuItems(
            [("Clear Recently Watched", f"RunPlugin({sys.argv[0]}?mode=clear_history)")]
        )

        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

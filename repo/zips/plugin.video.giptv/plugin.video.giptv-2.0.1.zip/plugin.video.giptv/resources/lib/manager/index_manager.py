# -*- coding: utf-8 -*-
import json
import os
import unicodedata
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

from resources.utils.config import ensure_api_ready
from resources.utils.xtream import STATE
import resources.apis.xtream_api as xtream_api
import resources.utils.giptv as giptv

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

_INDEX_LOCK = threading.Lock()
_INDEX_BUILDING = False
# ============================================================
#  PATH HELPERS
# ============================================================


def _index_path(name):
    """Return the full path to the index file for the current STATE.user."""
    return os.path.join(_index_dir(), f"{STATE.username}_{name}_index.json")

def _index_dir():
    """Always dynamically return index folder (username agnostic)."""
    path = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/index")
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path

def _index_lock_path():
    return os.path.join(_index_dir(), ".index.lock")

def _acquire_index_lock():
    lock_path = _index_lock_path()

    if xbmcvfs.exists(lock_path):
        xbmc.log("[giptv][index] Lock exists — build already running", xbmc.LOGINFO)
        return False

    f = xbmcvfs.File(lock_path, "w")
    try:
        f.write(str(time.time()))
    finally:
        f.close()

    return True


def _release_index_lock():
    lock_path = _index_lock_path()
    if xbmcvfs.exists(lock_path):
        xbmcvfs.delete(lock_path)

# ============================================================
#  UTIL
# ============================================================


def _normalize_title(s):
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower().strip()


def _write_index(name, data):
    path = _index_path(name)
    payload = json.dumps(data, ensure_ascii=False)

    f = xbmcvfs.File(path, "w")
    try:
        f.write(payload)
    finally:
        f.close()


def _read_index(name):
    """
    Reads an index file (vod_index.json, series_index.json, live_index.json)
    and returns a list of entries.
    """
    if not ensure_api_ready():
        return

    index_dir = _index_dir()
    path = os.path.join(index_dir, f"{STATE.username}_{name}_index.json")
    if not xbmcvfs.exists(path):
        return []

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.read()
    finally:
        f.close()

    if not raw:
        return []

    try:
        return json.loads(raw)
    except Exception:
        return []


def index_exists_and_valid():
    if not ensure_api_ready():
        return False

    for name in ("vod", "series", "live"):
        path = _index_path(name)
        if not xbmcvfs.exists(path):
            return False
        stat = xbmcvfs.Stat(path)
        if stat.st_size() < 16:
            return False

    return True


# ============================================================
#  CORE BUILDER
# ============================================================


def build_index(monitor=None, notify=True):
    """
    Unified index builder.
    Safe for:
      - service
      - navigator
      - manual rebuild
    """
    if not _acquire_index_lock():
        return False

    try:
        if not ensure_api_ready():
            xbmc.log("[giptv][index] API not configured", xbmc.LOGERROR)
            return False

        xbmc.log(f"[giptv][index] Building index for {STATE.username} /{STATE.server}", xbmc.LOGINFO)

        # ------------------ VOD ------------------
        vod_index = {}
        vod_cats = xtream_api.categories(xtream_api.VOD_TYPE) or []

        for cat in vod_cats:
            if monitor and monitor.abortRequested():
                return False

            if not isinstance(cat, dict):
                continue

            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            if not cat_id:
                continue

            movies = xtream_api.streams_by_category(xtream_api.VOD_TYPE, cat_id) or []

            for m in movies:
                if monitor and monitor.abortRequested():
                    return False

                if not isinstance(m, dict):
                    continue

                sid = m.get("stream_id")
                if not sid:
                    continue

                title = m.get("name") or m.get("title") or "Unknown"
                vod_index[str(sid)] = {
                    "id": str(sid),
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": m.get("stream_icon") or m.get("cover") or "",
                    "tmdb": m.get("tmdb") or m.get("tmdb_id"),
                    "ext": m.get("container_extension", "mp4"),
                }

        _write_index("vod", list(vod_index.values()))

        # ------------------ SERIES ------------------
        series_index = {}
        series_cats = xtream_api.categories(xtream_api.SERIES_TYPE) or []

        for cat in series_cats:
            if monitor and monitor.abortRequested():
                return False

            if not isinstance(cat, dict):
                continue

            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            if not cat_id:
                continue

            shows = xtream_api.streams_by_category(xtream_api.SERIES_TYPE, cat_id) or []

            for s in shows:
                if monitor and monitor.abortRequested():
                    return False

                if not isinstance(s, dict):
                    continue

                sid = s.get("series_id")
                if not sid:
                    continue

                title = s.get("name") or "Unknown"
                series_index[str(sid)] = {
                    "id": str(sid),
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": s.get("cover") or "",
                    "tmdb": s.get("tmdb") or s.get("tmdb_id"),
                }

        _write_index("series", list(series_index.values()))

        # ------------------ LIVE ------------------
        live_index = {}
        live_cats = xtream_api.categories(xtream_api.LIVE_TYPE) or []

        for cat in live_cats:
            if monitor and monitor.abortRequested():
                return False

            if not isinstance(cat, dict):
                continue

            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "")
            if not cat_id:
                continue

            chans = xtream_api.streams_by_category(xtream_api.LIVE_TYPE, cat_id) or []

            for c in chans:
                if monitor and monitor.abortRequested():
                    return False

                if not isinstance(c, dict):
                    continue

                sid = c.get("stream_id")
                if not sid:
                    continue

                title = c.get("name") or c.get("stream_display_name") or "Unknown Channel"

                live_index[str(sid)] = {
                    "id": str(sid),
                    "title": title,
                    "lower": _normalize_title(title),
                    "category_id": cat_id,
                    "category_name": cat_name,
                    "thumb": c.get("stream_icon") or c.get("tv_logo") or "",
                    "ext": c.get("container_extension", "ts"),
                }

        _write_index("live", list(live_index.values()))

        xbmc.log("[giptv][index] Index build complete", xbmc.LOGINFO)

        if notify:
            giptv.notification(
                ADDON.getAddonInfo("name"),
                "Search index rebuilt",
                icon="INFO",
            )

        return True

    finally:
        _release_index_lock()

# ============================================================
#  AUTO / SAFE ENTRY
# ============================================================


def ensure_index(monitor=None):
    """
    Called by service.
    Rebuilds only if missing or invalid.
    """
    if not index_exists_and_valid():
        xbmc.log("[giptv][index] Index missing or invalid — rebuilding", xbmc.LOGINFO)
        return build_index(monitor, notify=False)

    return True

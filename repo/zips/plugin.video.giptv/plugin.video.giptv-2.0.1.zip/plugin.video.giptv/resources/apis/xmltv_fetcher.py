import io
import gzip
import json
import urllib.request
import xml.etree.ElementTree as ET

from resources.utils.xtream import STATE
import xbmc
import xbmcvfs

ADDON_ID = "plugin.video.giptv"


# ============================================================
# PATH HELPERS
# ============================================================


def profile_path(sub=""):
    base = f"special://profile/addon_data/{ADDON_ID}/"
    return xbmcvfs.translatePath(base + sub)


def ensure_cache_dir():
    path = profile_path("cache")
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


# ============================================================
# LOGGING
# ============================================================


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[giptv][epg] {msg}", level)


# ============================================================
# HTTP FETCH (gzip + UA fallback)
# ============================================================

KODI_UA = "Kodi-GIPTV/1.0"

BROWSER_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/44.0.2403.89 Safari/537.36"
)


def fetch_url(url, timeout=30, use_browser_ua=False):
    headers = {
        "Accept-Encoding": "gzip",
        "User-Agent": BROWSER_UA if use_browser_ua else KODI_UA,
    }

    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()

        if r.headers.get("Content-Encoding") == "gzip" or url.endswith(".gz"):
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()

        return raw.decode("utf-8", errors="ignore")


# ============================================================
# XTREAM URL BUILDERS
# ============================================================


def candidate_xmltv_urls():
    base = STATE.server.rstrip("/")
    u = STATE.username
    p = STATE.password

    return [
        f"{base}/xmltv.php?username={u}&password={p}",
        f"{base}/xmltv.php?u={u}&p={p}",
        f"{base}/epg.xml",
        f"{base}/epg.xml.gz",
        f"{base}/xmltv.xml",
        f"{base}/xmltv.xml.gz",
    ]


def build_player_api_epg_url():
    base = STATE.server.rstrip("/")
    u = STATE.username
    p = STATE.password

    return f"{base}/player_api.php?username={u}&password={p}&action=get_epg"


# ============================================================
# VALIDATION
# ============================================================


def is_html_block(data):
    snippet = data[:500].lower()
    return "<html" in snippet or "<!doctype html" in snippet


def validate_xmltv(data):
    if "<tv" not in data[:1000].lower():
        return False, 0

    try:
        root = ET.fromstring(data)
        programmes = root.findall("programme")
        return True, len(programmes)
    except Exception:
        return False, 0


# ============================================================
# PROVIDER FETCHERS
# ============================================================


def fetch_xmltv():
    cache_dir = ensure_cache_dir()
    xmltv_path = f"{cache_dir}/{STATE.username}_xmltv.xml"

    # --- PRIMARY: XMLTV ENDPOINTS ---
    for url in candidate_xmltv_urls():
        for ua_mode in (False, True):
            try:
                log(f"Trying XMLTV: {url} | UA={'browser' if ua_mode else 'kodi'}")
                data = fetch_url(url, use_browser_ua=ua_mode)

                if is_html_block(data):
                    log("HTML response detected (blocked)", xbmc.LOGWARNING)
                    continue

                valid, count = validate_xmltv(data)
                if not valid:
                    log("Invalid XMLTV structure", xbmc.LOGWARNING)
                    continue

                with xbmcvfs.File(xmltv_path, "w") as f:
                    f.write(data)

                log(f"XMLTV stored successfully ({count} programmes)")
                return xmltv_path

            except Exception as e:
                log(f"XMLTV error: {e}", xbmc.LOGWARNING)

    # --- FALLBACK: PLAYER_API JSON EPG ---
    try:
        url = build_player_api_epg_url()
        log("Falling back to Xtream player_api EPG")
        data = fetch_url(url, use_browser_ua=True)
        epg_json = json.loads(data)

        log(f"player_api EPG fetched ({len(epg_json)} entries)")
        # NOTE: Conversion to XMLTV would go here
        # Keeping JSON fetch logged for now

    except Exception as e:
        log(f"player_api fallback failed: {e}", xbmc.LOGERROR)

    log("XMLTV unavailable from provider", xbmc.LOGERROR)
    return None


def fetch_provider_data():
    fetch_xmltv()

# screensaver.bingie

Screensaver for Bingie skin.

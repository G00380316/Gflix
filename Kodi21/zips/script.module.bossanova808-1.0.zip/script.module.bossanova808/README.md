
Bossanova808 Common Code for Kodi Addons
===================================

_script.module.bossanova808_

[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/bossanova808)


Common code for all bossanova808 Kodi addons, including:

**Available from the Kodi Official Repository:**

* OzWeather 
* Unpause Jumpback
* Playback Resumer
* Check Previous Episode
* Caber Toss


**Available from the [Bossanova808 Repository](https://github.com/bossanova808/repository.bossanova808):**

* OzWeather Skin Patcher
* YoctoDisplay









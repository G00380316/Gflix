# script.texturemaker
A helper script for Kodi skinners to construct gradient textures
